import { PartyLink, type PlatformClient } from '@partylink/game-sdk';
import './style.css';

type Player = ReturnType<PlatformClient['host']['getPlayers']>[number];
const status = document.querySelector<HTMLElement>('#status')!;
const errorBox = document.querySelector<HTMLElement>('#error')!;
const roster = document.querySelector<HTMLUListElement>('#players')!;
const start = document.querySelector<HTMLButtonElement>('#start')!;
const reset = document.querySelector<HTMLButtonElement>('#reset')!;
const exit = document.querySelector<HTMLButtonElement>('#exit')!;
const controller = document.querySelector<HTMLSelectElement>('#controller')!;
const players = new Map<string, Player>();
const scores = new Map<string, number>();
const pressed = new Set<string>();
const configured = new Map<string, string>();
const unsubscribe: Array<() => void> = [];
let pl: PlatformClient | undefined;
let running = false;
let paused = false;
let closed = false;
let enabledQueue = Promise.resolve();

function fail(error: unknown) {
  errorBox.hidden = false;
  errorBox.textContent = `PartyLink 操作失败：${error instanceof Error ? error.message : String(error)}`;
}
function active() {
  return running && !paused && !closed;
}
function render() {
  roster.replaceChildren();
  for (const player of players.values()) {
    const row = document.createElement('li');
    const name = document.createElement('span');
    name.textContent = `${player.nickname} · ${player.state === 'connected' ? '已连接' : '已断开 / 连接中'}`;
    const score = document.createElement('strong');
    score.textContent = `${scores.get(player.id) ?? 0} 分`;
    row.append(name, score);
    roster.append(row);
  }
  if (!players.size) roster.textContent = '等待玩家扫码加入…';
  if (closed) return;
  status.textContent = paused
    ? 'Host 已暂停，等待恢复。'
    : running
      ? '比赛进行中，按 A 得分！'
      : '等待开始。';
  start.disabled = running || paused || ![...players.values()].some((p) => p.state === 'connected');
}
// Serialize global enable/disable calls so rapid start/reset cannot apply stale state last.
function syncEnabled() {
  enabledQueue = enabledQueue
    .then(async () => {
      if (!pl || closed) return;
      await pl.app.setControllersEnabled(active());
    })
    .catch(fail);
  return enabledQueue;
}
async function configure(player: Player) {
  if (!pl || closed || player.state !== 'connected') return;
  const name = controller.value;
  if (configured.get(player.id) === name) return;
  configured.set(player.id, name); // setController itself can emit player:update.
  try {
    if (name === 'tap') await pl.app.setController('tap', player.id);
    else
      await pl.app.setController('custom-buttons', player.id, {
        orientation: 'portrait',
        components: [
          {
            type: 'custom-buttons',
            buttons: [{ controlId: 'a', label: 'A · +1', gridX: 1, gridY: 1, spanX: 2, spanY: 2 }],
          },
        ],
      });
    // Re-read current phase after the asynchronous controller assignment.
    await syncEnabled();
  } catch (error) {
    if (configured.get(player.id) === name) configured.delete(player.id);
    fail(error);
  }
}
function update(player: Player) {
  players.set(player.id, player);
  if (!scores.has(player.id)) scores.set(player.id, 0);
  if (player.state !== 'connected') {
    pressed.delete(player.id);
    configured.delete(player.id);
  } else void configure(player);
  render();
}
function button(playerId: string, action: 'down' | 'up' | 'click', synthetic = false) {
  if (action === 'up') {
    pressed.delete(playerId);
    return;
  }
  // Built-in controllers emit down/up/click. Count down only, once per press.
  if (action !== 'down' || synthetic || !active() || players.get(playerId)?.state !== 'connected')
    return;
  if (pressed.has(playerId)) return;
  pressed.add(playerId);
  scores.set(playerId, (scores.get(playerId) ?? 0) + 1);
  render();
}
function cleanup() {
  if (closed) return;
  closed = true;
  running = false;
  pressed.clear();
  configured.clear();
  unsubscribe.splice(0).forEach((off) => off());
  start.disabled = reset.disabled = exit.disabled = controller.disabled = true;
  status.textContent = '游戏已关闭。';
}
window.addEventListener(
  'pagehide',
  () => {
    cleanup();
    pl?.dispose();
  },
  { once: true },
);

start.onclick = () => {
  running = true;
  pressed.clear();
  render();
  void syncEnabled();
};
reset.onclick = () => {
  running = false;
  pressed.clear();
  for (const id of scores.keys()) scores.set(id, 0);
  render();
  void syncEnabled();
};
exit.onclick = async () => {
  if (!pl || closed) return;
  try {
    running = false;
    pressed.clear();
    await syncEnabled();
    await pl.game.requestClose();
    cleanup();
    pl.dispose();
  } catch (error) {
    fail(error);
  }
};
controller.onchange = () => {
  pressed.clear();
  for (const player of players.values()) void configure(player);
};

const mode = new URL(location.href).searchParams.get('plMode');
if (mode !== 'iframe' && mode !== 'popup') {
  status.textContent = '页面预览：请通过 PartyLink Library 启动完整游戏。';
  document.querySelector<HTMLElement>('#preview')!.hidden = false;
} else {
  try {
    pl = await PartyLink.init({ mode });
    if (closed) pl.dispose();
    else {
      unsubscribe.push(
        pl.host.on('player:join', update),
        pl.host.on('player:update', update),
        pl.host.on('player:leave', (player) => {
          players.delete(player.id);
          scores.delete(player.id);
          pressed.delete(player.id);
          configured.delete(player.id);
          render();
        }),
        pl.app.on('input', (input) => {
          if (input.type === 'button' && input.controlId === 'a' && controller.value === 'buttons')
            button(input.playerId, input.action, input.synthetic);
        }),
        pl.app.on('message', ({ playerId, payload }) => {
          if (controller.value !== 'tap' || !payload || typeof payload !== 'object') return;
          const message = payload as { type?: unknown; action?: unknown };
          if (
            message.type === 'tap:button' &&
            (message.action === 'down' || message.action === 'up')
          )
            button(playerId, message.action);
        }),
        pl.game.on('game:control', ({ action }) => {
          paused = action === 'pause';
          pressed.clear();
          render();
          void syncEnabled();
        }),
        pl.on('close', ({ code }) => {
          cleanup();
          status.textContent = `游戏已关闭：${code}`;
        }),
        pl.onDispose(cleanup),
      );
      await pl.host.setLobbyMode(false);
      await syncEnabled();
      // Snapshot plus events: includes players already connected before initialization.
      for (const player of pl.host.getPlayers()) update(player);
      reset.disabled = exit.disabled = controller.disabled = false;
      render();
    }
  } catch (error) {
    cleanup();
    pl?.dispose();
    status.textContent = '游戏初始化失败。';
    fail(error);
  }
}
