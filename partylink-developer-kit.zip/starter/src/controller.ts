import { PartyLink } from '@partylink/game-sdk';
import './style.css';

const tap = document.querySelector<HTMLButtonElement>('#tap')!;
const status = document.querySelector<HTMLElement>('#controller-status')!;
try {
  // Custom controller pages always opt into controller mode explicitly.
  const pl = await PartyLink.init({ mode: 'controller' });
  let held = false;
  const send = (action: 'down' | 'up') => {
    if (pl.state !== 'ready' || !pl.app.isEnabled()) return;
    void pl.game.sendMessage({ type: 'tap:button', action }).catch((error: unknown) => {
      status.textContent = `发送失败：${error instanceof Error ? error.message : String(error)}`;
    });
  };
  tap.disabled = false;
  status.textContent = '等待 PC 开始比赛。比赛中每次按下 A 得 1 分。';
  tap.onpointerdown = (event) => {
    if (held || !pl.app.isEnabled()) return;
    held = true;
    tap.setPointerCapture(event.pointerId);
    send('down');
  };
  const release = () => {
    if (held) {
      held = false;
      send('up');
    }
  };
  tap.onpointerup = release;
  tap.onpointercancel = release;
  tap.onlostpointercapture = release;
  window.addEventListener('blur', release);
  window.addEventListener(
    'pagehide',
    () => {
      release();
      pl.dispose();
    },
    { once: true },
  );
} catch (error) {
  status.textContent = `控制器连接失败：${error instanceof Error ? error.message : String(error)}。请从 PartyLink 启动游戏。`;
}
