# PartyLink game starter

A small multiplayer Tap Race game: a shared screen shows scores and phones provide the controls. Use this optional template when starting a new game from a working example. To adapt an existing game, use the English integration prompt with your own project instead. Requires Node.js 22+.

```sh
npm install
npm run dev
npm run typecheck
npm run package
```

The starter installs `@partylink/game-sdk@0.1.1` from npm. Give your AI the English PartyLink prompt, which links to the latest official API reference, to turn this sample into your game.

Import `release/game.zip` in PartyLink Library, launch it, and scan the QR code with phones. Start the round on the shared screen and press A on each phone to score. The menu also lets you try a custom phone controller. Test joining, reconnecting, pausing and starting another round.

- `src/main.ts`: game logic and built-in phone controls.
- `src/controller.ts` and `controller.html`: custom phone controller.
- `public/manifest.json`: game identity, player count, entry page and controller configuration.
- `public/assets/cover.webp`: game cover.
- `scripts/pack.mjs`: builds `release/game.zip` with the manifest at the ZIP root.

Update the name, ID, version, player count and cover for your game. Keep packaged asset paths relative. Plan for up to 12 connected phones.
