import { readdir, readFile, mkdir, writeFile, lstat } from 'node:fs/promises';
import { dirname, resolve, relative, posix } from 'node:path';
import { fileURLToPath } from 'node:url';
import { zipSync } from 'fflate';

const project = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const dist = resolve(project, 'dist');
const files = {};
const ignored = (name) => name.startsWith('.') || name === '__MACOSX' || name === 'Thumbs.db';
async function collect(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (ignored(entry.name)) continue;
    const path = resolve(directory, entry.name);
    const info = await lstat(path);
    if (info.isSymbolicLink()) throw new Error(`不允许符号链接：${path}`);
    if (info.isDirectory()) await collect(path);
    else if (info.isFile())
      files[relative(dist, path).split('\\').join('/')] = new Uint8Array(await readFile(path));
  }
}
function resource(path, label) {
  if (
    typeof path !== 'string' ||
    !path ||
    path.startsWith('/') ||
    /[\\%?#:]/.test(path) ||
    path.split('/').some((part) => !part || part === '.' || part === '..')
  ) {
    throw new Error(`${label} 必须是 ZIP 内相对资源路径：${String(path)}`);
  }
  if (!(path in files)) throw new Error(`${label} 文件不存在：${path}`);
  return path;
}
try {
  await collect(dist);
  if (!files['manifest.json']) throw new Error('dist 根目录缺少 manifest.json');
  const manifest = JSON.parse(new TextDecoder().decode(files['manifest.json']));
  if (manifest.schemaVersion !== 1 || manifest.sdkProtocolVersion !== 1)
    throw new Error('Manifest schemaVersion / sdkProtocolVersion 必须为 1');
  for (const key of ['id', 'name', 'version', 'description']) {
    if (typeof manifest[key] !== 'string' || !manifest[key].trim())
      throw new Error(`Manifest 缺少 ${key}`);
  }
  if (!['iframe', 'popup'].includes(manifest.launch?.mode))
    throw new Error('launch.mode 必须为 iframe 或 popup');
  if (
    !Number.isInteger(manifest.players?.min) ||
    !Number.isInteger(manifest.players?.max) ||
    manifest.players.min < 1 ||
    manifest.players.max < manifest.players.min ||
    manifest.players.max > 1000
  )
    throw new Error('players 人数范围无效');
  resource(manifest.entry, 'entry');
  if (!manifest.entry.endsWith('.html')) throw new Error('entry 必须为 HTML');
  resource(manifest.cover, 'cover');
  for (const [name, path] of Object.entries(manifest.customControllers ?? {})) {
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(name)) throw new Error(`自定义控制器名称无效：${name}`);
    resource(path, `customControllers.${name}`);
    if (!path.endsWith('.html')) throw new Error(`控制器必须为 HTML：${path}`);
  }
  // Check generated HTML references as well as Manifest paths. Vite uses ./assets/*.
  for (const [path, bytes] of Object.entries(files)) {
    if (!path.endsWith('.html')) continue;
    const html = new TextDecoder().decode(bytes);
    for (const match of html.matchAll(/\b(?:src|href)\s*=\s*["']([^"']+)["']/gi)) {
      const reference = match[1];
      if (reference.startsWith('#')) continue;
      if (/^[a-z]+:/i.test(reference) || reference.startsWith('/') || reference.includes('\\'))
        throw new Error(`HTML 资源必须为相对路径：${path} → ${reference}`);
      const clean = reference.split(/[?#]/)[0];
      if (!clean) continue;
      const normalized = posix.normalize(posix.join(posix.dirname(path), clean));
      resource(normalized, `HTML ${path}`);
    }
  }
  const output = resolve(project, 'release/game.zip');
  const zip = zipSync(files, { level: 6 });
  await mkdir(dirname(output), { recursive: true });
  await writeFile(output, zip);
  console.log(`已打包 ${Object.keys(files).length} 个文件 → ${output} (${zip.length} bytes)`);
} catch (error) {
  console.error(`打包失败：${error instanceof Error ? error.message : String(error)}`);
  process.exitCode = 1;
}
