# API pública y funciones disponibles

Versión de la SDK: `@partylink/game-sdk@0.1.2`. Versión del protocolo: `1`. Esta referencia contiene el contrato necesario para que una IA implemente y empaquete un juego.

## Instalación e inicialización

```sh
npm install --save-exact @partylink/game-sdk@0.1.2
```

```ts
import {
  PartyLink, createAudioAPI, getVolumeSettings, subscribeVolumeSettings,
  bindMediaVolume, renderDrawPath, AUDIO_THEMES, SFX_KINDS,
} from '@partylink/game-sdk';
import type { PlatformClient, Player, DrawPath } from '@partylink/game-sdk';
```

`PartyLink` y las funciones auxiliares anteriores se exportan para su uso en ejecución. `PlatformClient` y las demás interfaces son tipos. Obtén los clientes mediante `PartyLink.init`.

### PartyLink.init(options)

Conecta un juego iniciado desde PartyLink Library o un controlador móvil personalizado abierto por PartyLink.

Parámetros para un juego: `{ mode: 'iframe' | 'popup'; timeoutMs?: number; allowedHostOrigins?: readonly string[]; allowInsecureDevelopment?: boolean }`. El modo debe coincidir con el contexto de inicio. `timeoutMs` vale 10000 por defecto; `allowedHostOrigins` permite limitar los orígenes aceptados a coincidencias exactas; `allowInsecureDevelopment` es una opción de desarrollo que sigue necesitando un contexto de inicio válido. En una página móvil, utiliza únicamente `{ mode: 'controller' }`.

Devuelve `Promise<PlatformClient>` para un juego y `Promise<CustomControllerClient>` para un móvil. Se rechaza si falta el contexto de inicio, es inválido o se agota el tiempo de espera. Si se abre directamente la página del juego, muestra un mensaje que explique cómo iniciarlo.

```ts
const mode = new URLSearchParams(location.search).get('plMode');
if (mode !== 'iframe' && mode !== 'popup') {
  document.body.textContent = 'Launch this game from PartyLink Library.';
  throw new Error('Launch context required');
}
const pl = await PartyLink.init({ mode });
console.log(pl.state); // 'ready'
// In a custom controller page instead:
// const phone = await PartyLink.init({ mode: 'controller' });
```

Al inicializar el juego, la interfaz para unirse se abre una vez si no hay jugadores conectados, se permite entrar y la interfaz está disponible. No vuelve a abrirse automáticamente después de cada desconexión.

## Datos y comportamiento comunes

Todos los métodos `on` y de suscripción devuelven `Unsubscribe`, una función `() => void`. Llámala para dejar de recibir callbacks. Las suscripciones observan cambios futuros; consulta también el estado inicial cuando exista un método para ello. Captura los errores asíncronos. `Promise<void>` se resuelve sin valor cuando termina la operación solicitada; no confirma que la lógica de otro dispositivo haya procesado un mensaje del juego. Las llamadas a clientes liberados pueden fallar.

`playerId` siempre corresponde a `Player.id`; los apodos y las posiciones en arrays no son identificadores estables. Las sesiones admiten hasta 12 jugadores. Las instantáneas de jugadores pueden incluir personas desconectadas.

```ts
const player: Player = {
  id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '',
  gender: 'none', state: 'connected', joinedAt: 1730000000000,
  controllerType: 'dpad-abxy', isPrimary: true, controlMode: 'game',
};
```

Campos de Player obligatorios: `id`, `sessionId`, `nickname` (1..64 caracteres), `avatar` (vacío, URL de datos JPEG o URL blob temporal), `gender` (`none`, `male`, `female`), `state` (`connecting`, `connected`, `disconnected`) y `joinedAt` (número). El campo opcional `controllerType` es un ID de preajuste integrado o `custom`; `isPrimary` es booleano; `controlMode` puede ser `game`, `remote` o `waiting`. No guardes las URL blob temporales de avatar para sesiones posteriores.

`ConnectionOverlayState` contiene los booleanos obligatorios `available`, `visible`, `canJoin` y las cadenas opcionales `qrPayload`, `overlayUrl`. Los datos para unirse son específicos de la sesión actual.

## Jugadores y acceso: pl.host

### pl.host.getPlayers()

Parámetros: ninguno. Devuelve `Player[]`, una copia del estado local.

```ts
const players = pl.host.getPlayers();
// [{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '',
//    gender: 'none', state: 'connected', joinedAt: 1730000000000 }]
```

### pl.host.getPlayer(id)

Parámetro: `id: string`. Devuelve una copia de `Player`, o `undefined` si no existe.

```ts
const player = pl.host.getPlayer('p1'); // Player or undefined
```

### pl.host.removePlayer(id?)

Desconecta y elimina a un jugador. Parámetro opcional: `id: string`; si se omite, elimina a todos. Devuelve `Promise<void>`.

```ts
await pl.host.removePlayer('p1'); // undefined
```

### pl.host.getLobbyState()

Parámetros: ninguno. Devuelve `Promise<{ enabled: boolean; primaryPlayerId?: string }>`.

```ts
const lobby = await pl.host.getLobbyState();
// { enabled: true, primaryPlayerId: 'p1' }
```

### pl.host.setPrimaryPlayer(id)

Elige al jugador principal para navegar por la sala. Parámetro: `id: string`. Devuelve `Promise<void>`.

```ts
await pl.host.setPrimaryPlayer('p1'); // undefined
```

### pl.host.setLobbyMode(enabled)

Alterna entre la navegación remota de la sala (`true`) y los controles del juego (`false`). No inicia ni pausa la lógica del juego. Parámetro: `enabled: boolean`. Devuelve `Promise<void>`.

```ts
await pl.host.setLobbyMode(false); // undefined
```

### pl.host.getConnectionOverlay()

Parámetros: ninguno. Devuelve `Promise<ConnectionOverlayState>`.

```ts
const overlay = await pl.host.getConnectionOverlay();
// { available: true, visible: false, canJoin: true, qrPayload: 'session-join-data' }
```

### pl.host.setConnectionOverlay(visible)

Muestra u oculta la interfaz de PartyLink para unirse. Parámetro: `visible: boolean`. Devuelve `Promise<void>`. Mostrarla no pausa una partida en curso.

```ts
await pl.host.setConnectionOverlay(true); // undefined
```

### pl.host.on(event, callback)

Parámetros: uno de los eventos siguientes y un callback que recibe sus datos. Devuelve `Unsubscribe`.

```ts
const off = pl.host.on('player:join', async (player) => {
  await pl.app.setController('dpad-abxy', player.id);
});
off(); // undefined; stop this listener
```

Cada evento de jugador entrega directamente el objeto Player, sin envolverlo en una propiedad `player`:

```ts
// 'player:join'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'connected', joinedAt: 1730000000000 }
// 'player:update'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'connected', joinedAt: 1730000000000, isPrimary: true }
// 'player:leave'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'disconnected', joinedAt: 1730000000000 }
// 'connection:overlay'
{ available: true, visible: true, canJoin: true, qrPayload: 'session-join-data' }
```

Configura a los jugadores existentes mediante `getPlayers()` y a quienes se incorporen o regresen mediante join/update, según la ronda actual. Borra el estado de los controles mantenidos cuando alguien se desconecte.

## Ajustes del juego: pl.game

### pl.game.getLocale()

Parámetros: ninguno. Devuelve la cadena del idioma actual. Utiliza este valor para traducir los textos del juego.

```ts
const locale = pl.game.getLocale(); // 'en-US'
```

### pl.game.getVolumeSettings()

Parámetros: ninguno. Devuelve `VolumeSettings`: `{ music: number; effects: number }`, ambos entre 0 y 1.

```ts
const settings = pl.game.getVolumeSettings(); // { music: 0.5, effects: 0.5 }
```

### pl.game.subscribeVolumeSettings(callback)

Parámetro: callback `(settings: VolumeSettings) => void`. Devuelve `Unsubscribe`; no emite el valor inicial inmediatamente.

```ts
const initial = pl.game.getVolumeSettings();
const off = pl.game.subscribeVolumeSettings((settings) => {
  console.log(settings.effects); // 0.7 after a matching change
});
```

### pl.game.requestClose()

Solicita a PartyLink que cierre el juego. Parámetros: ninguno. Devuelve `Promise<void>`.

```ts
await pl.game.requestClose(); // undefined
```

### pl.game.on(event, callback)

Parámetros: `event: 'locale:change' | 'game:control'` y el callback correspondiente. Devuelve `Unsubscribe`.

```ts
const off = pl.game.on('locale:change', ({ locale }) => {
  document.documentElement.lang = locale;
});
// 'locale:change' payload: { locale: 'en-US' }
// 'game:control' payload: { playerId: 'p1', action: 'pause' }
// Resume payload: { playerId: 'p1', action: 'resume' }
```

`game:control` solicita pausar o reanudar. Aplica la acción a la simulación, los temporizadores y el audio; borra los controles mantenidos al pausar.

### pl.game.audio

Instancia de `AudioAPI` que reproduce sonido en la página del juego del ordenador. Sus métodos se detallan más abajo. Sigue el canal de efectos de la plataforma y se libera con el cliente de la SDK.

```ts
const played = pl.game.audio.confirm(); // true if a sound was created
```

## Controles y respuestas en el móvil: pl.app

### pl.app.setController(name, playerId?, layout?)

Configura un mando móvil. Parámetros: `name: string` (preajuste, composición o clave de controlador personalizado del manifest), `playerId: string` opcional y `layout: ControllerLayoutInput` opcional. Devuelve `Promise<void>`. Sin playerId, solo afecta a los jugadores actuales; configura por separado a quienes entren después. Para aplicar un diseño a todos, pasa `undefined` como segundo argumento.

```ts
await pl.app.setController('joystick-action', 'p1'); // undefined
await pl.app.setController('custom-buttons', undefined, {
  orientation: 'landscape',
  components: [{ type: 'custom-buttons', buttons: [
    { controlId: 'jump', label: 'Jump', gridX: 0, gridY: 0, spanX: 2 },
  ] }],
}); // undefined
```

### pl.app.setControllersEnabled(enabled, playerId?)

Activa o bloquea los controles sin cambiar el diseño. Parámetros: `enabled: boolean`, `playerId: string` opcional. Devuelve `Promise<void>`. Si se omite el ID, establece un permiso global persistente, también para nuevas entradas y reconexiones, y restablece los permisos individuales. El permiso de un jugador se combina con el global: ambos deben permitir la entrada. Los controladores personalizados desactivados no pueden enviar mensajes del juego. Borra el estado local de los controles mantenidos al desactivar la entrada.

```ts
await pl.app.setControllersEnabled(false); // undefined; pause all input
await pl.app.setControllersEnabled(true); // undefined; allow all input again
await pl.app.setControllersEnabled(false, 'p1'); // undefined; block this player
```

### pl.app.showToast(options, playerId?)

Muestra un aviso de texto en el móvil y sustituye al actual. Parámetros: `{ text: string; type?: 'text' | 'success' | 'error'; position?: 'top' | 'center' | 'bottom'; duration?: number }`, ID de destino opcional. Devuelve `Promise<void>`. Sin ID, afecta a los jugadores actuales. Texto tras recortar espacios: 1..200 caracteres UTF-16; duración: entero de 1000..10000 milisegundos. Valores por defecto: `text`, `center`, 3000. Utiliza la interfaz del juego para contenido enriquecido o diálogos.

```ts
await pl.app.showToast({ text: 'Your turn!', type: 'success', duration: 2000 }, 'p1');
// undefined
```

### pl.app.sendMessage(payload, playerId?)

Envía datos del juego a páginas móviles personalizadas. Parámetros: `payload: unknown` serializable como JSON, ID de jugador opcional. Devuelve `Promise<void>`. Sin ID, se dirige a los jugadores actuales. Si necesitas confirmar el procesamiento, implementa un mensaje de respuesta propio.

```ts
await pl.app.sendMessage({ type: 'round', roundId: 'r1', score: 3 }, 'p1');
// undefined; phone.game.on('message') receives that payload directly
```

### pl.app.audio.play(kind, playerId?, options?)

Reproduce un sonido en el móvil. Parámetros: `kind: SfxKind`, ID opcional y `{ theme?: AudioTheme }` opcional en la tercera posición. Devuelve `Promise<AudioPlaybackResult[]>`, también como array cuando solo hay un jugador. Sin ID, se dirige a los jugadores actuales. Revisa los resultados, ya que el navegador puede seguir bloqueando el audio.

```ts
const results = await pl.app.audio.play('success', 'p1', { theme: 'arcade' });
// [{ playerId: 'p1', played: true, state: 'running' }]
// A failure might be [{ playerId: 'p1', played: false, state: 'suspended',
//   reason: 'AUDIO_USER_GESTURE_REQUIRED' }]
```

Campos del resultado: `playerId: string`, `played: boolean`, `state: AudioState`, `reason: string` opcional. AudioState puede ser `idle`, `running`, `suspended`, `closed`, `error` o `unsupported`.

### pl.app.on(event, callback)

Parámetros: `input`, `remote:action`, `message`, `selector:submit`, `draw:path` o `draw:frame`, y el callback correspondiente. Devuelve `Unsubscribe`. Todos los datos de evento incluyen el `playerId` del remitente.

```ts
const off = pl.app.on('input', (input) => {
  if (input.type === 'button' && input.action === 'click' && !input.synthetic) {
    console.log(input.playerId, input.controlId); // 'p1', 'a'
  }
});
```

Ejemplos de datos de entrada:

```ts
// Button: type 'button', action 'down' | 'up' | 'click'
{ protocolVersion: 1, sessionId: 's1', playerId: 'p1', sequence: 1,
  timestamp: 1730000000000, controlId: 'a', synthetic: false,
  type: 'button', action: 'down' }
// Axis: x and y in -1..1
{ protocolVersion: 1, sessionId: 's1', playerId: 'p1', sequence: 2,
  timestamp: 1730000000001, controlId: 'left_stick', synthetic: false,
  type: 'axis', x: 0.5, y: -0.2 }
```

Campos comunes: `protocolVersion: 1`; cadenas `sessionId`, `playerId`; `sequence`, entero seguro no negativo; `timestamp`, entero no negativo; `controlId`, 1..64 letras, dígitos, guiones bajos o guiones; `synthetic`, booleano. Un toque puede producir down/up/click: elige una sola fase para puntuar una acción. Sigue down/up para acciones mantenidas. Los eventos sintéticos restablecen un estado seguro: procesa las liberaciones y los ejes neutros, sin puntuarlos como acciones nuevas.

Ejemplos de datos de otros eventos:

```ts
// 'remote:action': action is up/down/left/right/confirm/cancel/back
{ playerId: 'p1', action: 'confirm' }
// 'message': custom phone data; validate shape, ranges, round, and frequency
{ playerId: 'p1', payload: { type: 'jump', roundId: 'r1' } }
// 'selector:submit'
{ playerId: 'p1', controlId: 'vote', requestId: 'r1', values: ['cat'] }
// 'draw:path'
{ playerId: 'p1', kind: 'path', action: 'move', controlId: 'sketch',
  requestId: 'r1', width: 1024, height: 768, backgroundColor: '#FFFFFF',
  strokeId: 'stroke-1', tool: 'pen', color: '#111111', strokeWidth: 0.01,
  points: [{ x: 0.2, y: 0.3 }, { x: 0.25, y: 0.35 }] }
// 'draw:frame': dataUrl contains a complete reassembled WebP image
{ playerId: 'p1', kind: 'frame', action: 'submit', controlId: 'sketch',
  requestId: 'r1', width: 1024, height: 768, backgroundColor: '#FFFFFF',
  frameId: 'frame-1', dataUrl: 'data:image/webp;base64,UklGR...' }
```

La URL de datos abreviada anterior ilustra el campo, pero no es una imagen utilizable. Comprueba que requestId corresponde a la ronda actual e ignora los envíos duplicados.

## Nombres de controladores y campos de diseño

Preajustes integrados: `dpad-abxy`, `joystick-action`, `custom-buttons`, `multi-row-buttons`, `remote`, `selector`, `draw`. También puedes combinar componentes por nombre y en orden, por ejemplo `joystick+dual-buttons`. Nombres disponibles: `joystick`, `dual-buttons`, `quad-buttons`, `dpad`, `menu-keys`, `custom-buttons`, `multi-row-buttons`, `selector`, `draw`.

`ControllerLayoutInput` tiene `orientation: 'auto' | 'portrait' | 'landscape'` opcional y `components` obligatorio (1..4). Los tipos deben coincidir con el nombre y el orden de la composición. La orientación predeterminada es `auto`, salvo un selector aislado, que usa `portrait`. Los ID de control deben ser únicos en todo el diseño. Draw funciona solo. Remote usa un diseño horizontal fijo de dpad + menu-keys.

- Joystick: `{ type: 'joystick', controlId?: string, deadZone?: number }`; valores por defecto: `left_stick`, 0.12; deadZone entre 0 y 0.9.
- Dos botones: `{ type: 'dual-buttons' }`; ID `a`, `b`.
- Cuatro botones: `{ type: 'quad-buttons' }`; ID `a`, `b`, `x`, `y`.
- Cruceta: `{ type: 'dpad' }`; ID `up`, `down`, `left`, `right`.
- Teclas de menú: `{ type: 'menu-keys' }`; ID `menu_back`, `menu_cancel`, `menu_confirm`.
- Botones personalizados: `{ type: 'custom-buttons', buttons: ButtonDefinition[] }`, 1..12 botones. Cada uno tiene `controlId`, `label`, `gridX/gridY` enteros de 0..3, `spanX/spanY` enteros opcionales de 1..2 (por defecto 1), `backgroundColor/textColor` opcionales. Ocupan una cuadrícula de 4 por 4, sin solapamientos ni desbordamientos.
- Botones en filas: `{ type: 'multi-row-buttons', buttons: [{ code, label, backgroundColor?, textColor? }] }`, 1..4 botones. `code` es el ID de control.

ID: 1..64 letras, dígitos, guiones bajos o guiones. Etiquetas de botones: 1..16 caracteres. Colores: `#RGB` o `#RRGGBB`. Proporciona diseños explícitos en los preajustes de botones personalizados para elegir ID con sentido.

### Configuración del selector

```ts
await pl.app.setController('selector', 'p1', {
  components: [{ type: 'selector', controlId: 'vote', requestId: 'r1',
    title: 'Choose an animal', mode: 'single',
    options: [{ id: 'cat', label: 'Cat' }, { id: 'dog', label: 'Dog' }],
  }],
}); // undefined
```

Campos: `type: 'selector'`; `controlId` opcional (por defecto `selector`); `requestId` opcional (1..128 caracteres, UUID aleatorio por defecto; utiliza un valor propio de la ronda); `title` opcional (máximo 120, vacío por defecto); `mode` opcional (`single` por defecto o `multiple`); `options` obligatorio (1..100 ID únicos). El ID de opción sigue el formato de los ID de control; la etiqueta admite 1..120 caracteres. `submittedValues: string[]` opcional restaura una elección enviada: lista no vacía de ID de opción únicos; uno en modo single, hasta 100 en multiple. Las respuestas llegan mediante `selector:submit`.

### Configuración del dibujo

```ts
await pl.app.setController('draw', 'p1', {
  components: [{ type: 'draw', controlId: 'sketch', requestId: 'r1',
    title: 'Draw a cat', width: 1024, height: 768,
    backgroundColor: '#FFFFFF', output: 'path', fps: 5, showSubmit: true,
  }],
}); // undefined
```

Campos opcionales y valores por defecto: `controlId: 'draw'`; `requestId`: UUID aleatorio, 1..128 caracteres; `title`: máximo 120; `width: 1024`, `height: 768`, ambos enteros de 64..2048; `backgroundColor: '#FFFFFF'` (hexadecimal de seis dígitos); `output: 'path'` o `frame`; `fps: 5` (1..10); `showSubmit: true`; `initialImage`: URL de datos WebP base64, máximo 48000 caracteres. No se aceptan URL de imágenes arbitrarias.

`DrawPath`: `kind: 'path'`; action: `start`, `move`, `end`, `clear` o `submit`; campos del lienzo: `controlId`, `requestId`, `width`, `height`, `backgroundColor`; `strokeId` (1..128 caracteres); `tool: 'pen' | 'eraser'`; `color` hexadecimal de seis dígitos; `strokeWidth` de 0.0001..1 respecto al tamaño del lienzo; `points: { x: number; y: number }[]` con hasta 64 puntos normalizados entre 0 y 1. El evento añade `playerId`.

`DrawFrame` incluye esos campos del lienzo, `playerId`, `kind: 'frame'`, action `frame`, `submit` o `clear`, la cadena `frameId` y el `dataUrl` WebP completo. Los fotogramas se reconstruyen antes del evento. Longitud máxima de imagen: 524288 caracteres; hasta 32 fragmentos de 16384 caracteres, completados en 5 segundos. Utiliza una frecuencia de actualización moderada.

El tipo exportado `DrawPacket` describe un trazado o un fragmento de fotograma; los fragmentos contienen `index`, `length` y `data` en lugar de `dataUrl`. Los listeners normales del juego reciben el `DrawFrame` reconstruido.

### renderDrawPath(context, path)

Dibuja operaciones normalizadas en un Canvas. Parámetros: `CanvasRenderingContext2D`, `DrawPath`. Devuelve `void`. Ajusta las dimensiones del lienzo a la configuración; utiliza uno por jugador y gestiona el envío en la lógica del juego.

```ts
const canvases = new Map<string, HTMLCanvasElement>();
pl.app.on('draw:path', (path) => {
  let canvas = canvases.get(path.playerId);
  if (!canvas) {
    canvas = document.createElement('canvas');
    canvas.width = path.width; canvas.height = path.height;
    canvases.set(path.playerId, canvas);
    document.body.append(canvas);
  }
  renderDrawPath(canvas.getContext('2d')!, path); // undefined
});
```

## AudioAPI

`pl.game.audio`, `phone.app.audio` y `createAudioAPI()` comparten estos métodos. Temas: `default`, `retro8bit`, `arcade`, `glass`, `cyber`. Sonidos: `click`, `focus`, `back`, `confirm`, `cancel`, `success`, `error`, `unlock`, `coin`, `notify`, `join`, `leave`, `countdown`. `AUDIO_THEMES` y `SFX_KINDS` exportan arrays de solo lectura con estas cadenas.

El navegador puede exigir un gesto local del usuario antes de reproducir sonido. Un gesto en el móvil no desbloquea el audio del ordenador. Ofrece un botón de sonido en el ordenador si hace falta. Los ejemplos usan `const audio = pl.game.audio`.

### audio.play(kind, options?)

Parámetros: `kind: SfxKind`, `{ theme?: AudioTheme }` opcional para cambiar el tema solo en este sonido. Devuelve un booleano que indica si se creó un sonido; no garantiza que se haya oído. False puede indicar silencio, suspensión, liberación, falta de compatibilidad, sonido inválido o límite de voces alcanzado. Consulta el estado o el error cuando corresponda.

```ts
const played = audio.play('coin', { theme: 'retro8bit' }); // true or false
```

### audio.click()

Reproduce el sonido `click` con el tema actual. Parámetros: ninguno. Devuelve un booleano con el mismo significado que `play`.

```ts
const played = audio.click(); // true or false
```

### audio.focus()

Reproduce el sonido `focus` con el tema actual. Parámetros: ninguno. Devuelve un booleano con el mismo significado que `play`.

```ts
const played = audio.focus(); // true or false
```

### audio.back()

Reproduce el sonido `back` con el tema actual. Parámetros: ninguno. Devuelve un booleano con el mismo significado que `play`.

```ts
const played = audio.back(); // true or false
```

### audio.confirm()

Reproduce el sonido `confirm` con el tema actual. Parámetros: ninguno. Devuelve un booleano con el mismo significado que `play`.

```ts
const played = audio.confirm(); // true or false
```

### audio.cancel()

Reproduce el sonido `cancel` con el tema actual. Parámetros: ninguno. Devuelve un booleano con el mismo significado que `play`.

```ts
const played = audio.cancel(); // true or false
```

### audio.success()

Reproduce el sonido `success` con el tema actual. Parámetros: ninguno. Devuelve un booleano con el mismo significado que `play`.

```ts
const played = audio.success(); // true or false
```

### audio.error()

Reproduce el sonido `error` con el tema actual. Parámetros: ninguno. Devuelve un booleano con el mismo significado que `play`.

```ts
const played = audio.error(); // true or false
```

### audio.unlock()

Reproduce el sonido `unlock` con el tema actual. Parámetros: ninguno. Devuelve un booleano con el mismo significado que `play`.

```ts
const played = audio.unlock(); // true or false
```

### audio.coin()

Reproduce el sonido `coin` con el tema actual. Parámetros: ninguno. Devuelve un booleano con el mismo significado que `play`.

```ts
const played = audio.coin(); // true or false
```

### audio.notify()

Reproduce el sonido `notify` con el tema actual. Parámetros: ninguno. Devuelve un booleano con el mismo significado que `play`.

```ts
const played = audio.notify(); // true or false
```

### audio.join()

Reproduce el sonido `join` con el tema actual. Parámetros: ninguno. Devuelve un booleano con el mismo significado que `play`.

```ts
const played = audio.join(); // true or false
```

### audio.leave()

Reproduce el sonido `leave` con el tema actual. Parámetros: ninguno. Devuelve un booleano con el mismo significado que `play`.

```ts
const played = audio.leave(); // true or false
```

### audio.countdown()

Reproduce el sonido `countdown` con el tema actual. Parámetros: ninguno. Devuelve un booleano con el mismo significado que `play`.

```ts
const played = audio.countdown(); // true or false
```

### audio.resume()

Inicializa o reanuda el audio. Parámetros: ninguno. Devuelve `Promise<void>`; puede rechazarse si hace falta un gesto local o el audio no está disponible. `unlock()` es un atajo de sonido, no esta operación de reanudación.

```ts
soundButton.addEventListener('click', async () => {
  try { await audio.resume(); audio.confirm(); }
  catch (error) { console.error(error); }
}); // resume resolves to undefined
```

### audio.isSupported()

Parámetros: ninguno. Devuelve un booleano que indica si AudioContext está disponible.

```ts
const supported = audio.isSupported(); // true or false
```

### audio.getState()

Parámetros: ninguno. Devuelve `AudioState`: idle/running/suspended/closed/error/unsupported.

```ts
const state = audio.getState(); // 'running'
```

### audio.getLastError()

Parámetros: ninguno. Devuelve `string | undefined`, el último error registrado de reproducción o reanudación.

```ts
const error = audio.getLastError(); // undefined or 'AUDIO_USER_GESTURE_REQUIRED'
```

### audio.setTheme(theme)

Parámetro: `theme: AudioTheme`. Devuelve `void`. Establece el tema predeterminado para los sonidos siguientes.

```ts
audio.setTheme('glass'); // undefined
```

### audio.getTheme()

Parámetros: ninguno. Devuelve `AudioTheme`; inicialmente `default`.

```ts
const theme = audio.getTheme(); // 'glass'
```

### audio.setVolume(volume)

Parámetro: mezcla local `volume: number`, limitada a 0..1. Devuelve `void`. Se combina con el canal de efectos de la plataforma cuando está activado.

```ts
audio.setVolume(0.8); // undefined
```

### audio.getVolume()

Parámetros: ninguno. Devuelve el volumen de la mezcla local (inicialmente 1), no el nivel combinado con la plataforma.

```ts
const volume = audio.getVolume(); // 0.8
```

### audio.mute()

Parámetros: ninguno. Devuelve `void`. Silencia y detiene las voces activas.

```ts
audio.mute(); // undefined
```

### audio.unmute()

Parámetros: ninguno. Devuelve `void`. Restaura la mezcla local para los sonidos siguientes.

```ts
audio.unmute(); // undefined
```

### audio.isMuted()

Parámetros: ninguno. Devuelve un booleano con el estado de silencio local.

```ts
const muted = audio.isMuted(); // false
```

### audio.dispose()

Parámetros: ninguno. Devuelve `void`. Libera voces, suscripciones y el contexto de audio; puede llamarse varias veces sin efectos adicionales. El audio de la SDK se libera con su cliente; libera tú las instancias creadas por separado.

```ts
audio.dispose(); // undefined
audio.getState(); // 'closed'
```

### createAudioAPI(options?)

Crea una AudioAPI independiente. Parámetros opcionales: `{ AudioContextImpl?: typeof AudioContext; autoUnlock?: boolean; followPlatformVolume?: boolean }`. Por defecto usa el AudioContext del navegador, desbloqueo automático con un gesto válido y el ajuste de efectos de la página actual. Devuelve `AudioAPI`.

```ts
const extraAudio = createAudioAPI({ autoUnlock: true, followPlatformVolume: true });
extraAudio.getTheme(); // 'default'
extraAudio.dispose();
```

### getVolumeSettings()

Equivalente global de `pl.game.getVolumeSettings()`. Parámetros: ninguno. Devuelve una copia de `VolumeSettings` de la página actual.

```ts
const settings = getVolumeSettings(); // { music: 0.5, effects: 0.5 }
```

### subscribeVolumeSettings(callback)

Equivalente global de la suscripción del juego. Parámetro: `(settings: VolumeSettings) => void`. Devuelve `Unsubscribe`; lee el valor inicial por separado.

```ts
const off = subscribeVolumeSettings((settings) => console.log(settings.music));
// A later callback might receive { music: 0.7, effects: 0.5 }
off(); // undefined
```

### bindMediaVolume(media, channel)

Vincula la mezcla de un medio al volumen de música o efectos de la plataforma. Parámetros: `media: { volume: number }` (normalmente HTMLAudioElement), `channel: 'music' | 'effects'`. Devuelve `Unsubscribe`, que restaura el comportamiento original del volumen. El volumen efectivo es la mezcla base multiplicada por el canal elegido; escribir `media.volume` durante la vinculación actualiza esa mezcla base.

```ts
const music = new Audio('./assets/music.ogg');
music.volume = 0.8;
const off = bindMediaVolume(music, 'music');
// At platform music 0.5, effective playback volume is 0.4.
pl.onDispose(() => { off(); music.pause(); });
```

En tu propio grafo WebAudio, lee los ajustes y suscríbete a sus cambios; actualiza un GainNode desde un nivel base fijo, sin multiplicar repetidamente su último valor.

## Páginas móviles personalizadas

Declara `customControllers: { steering: 'controllers/steering.html' }` en el manifest y actívalo con `pl.app.setController('steering', 'p1')`, sin diseño. Claves: 1..64 letras, dígitos, guiones bajos o guiones; distintas de los nombres integrados de preajustes y componentes (incluido `custom`). Incluye el HTML del controlador como entrada de compilación y empaqueta sus recursos.

```ts
const phone = await PartyLink.init({ mode: 'controller' });
```

Estas páginas reciben su propio cliente de controlador. `phone.state` es `ready` o `disposed`.

### phone.app.isEnabled()

Parámetros: ninguno. Devuelve un booleano que indica si se permite la entrada. Compruébalo antes de enviar y borra el estado de controles mantenidos al desactivar u ocultar la página.

```ts
if (phone.app.isEnabled()) await phone.game.sendMessage({ type: 'jump' });
// true allows sending; false means input is blocked
```

### phone.app.requestOrientation(orientation)

Parámetro: `orientation: 'auto' | 'portrait' | 'landscape'`. Devuelve `void`. Solicita la orientación de la pantalla; no garantiza bloquear la orientación física del sistema operativo.

```ts
phone.app.requestOrientation('landscape'); // undefined
```

### phone.app.audio

AudioAPI local con todos los métodos anteriores. Esta página tiene su propio estado de volumen; su audio y sus funciones de volumen no reciben automáticamente los cambios de volumen de la plataforma. Para respuestas sonoras que sigan ese volumen, envía un mensaje del juego y deja que el juego llame a `pl.app.audio.play`.

```ts
phone.app.audio.getState(); // 'idle', for example
```

### phone.game.sendMessage(payload)

Parámetro: `payload: unknown` serializable como JSON, sin envolverlo en playerId. Devuelve `Promise<void>` cuando el móvil acepta el envío; no confirma que el juego lo haya procesado. El tiempo de espera es de 5 segundos. Se rechaza con `INPUT_BLOCKED` si está desactivado. El juego recibe el ID autenticado del remitente junto con los datos.

```ts
await phone.game.sendMessage({ type: 'jump', roundId: 'r1' }); // undefined
// Game 'message' payload: { playerId: 'p1', payload: { type: 'jump', roundId: 'r1' } }
```

### phone.game.on('message', callback)

Parámetros: literal `message` y callback `(payload: unknown) => void`. Devuelve `Unsubscribe`. Recibe directamente los datos enviados por el juego.

```ts
const off = phone.game.on('message', (payload) => console.log(payload));
// Example callback payload: { type: 'round', roundId: 'r1', score: 3 }
off(); // undefined
```

### phone.dispose()

Parámetros: ninguno. Devuelve `void`. Libera el cliente del controlador y su audio de forma idempotente; los envíos pendientes se rechazan. También se libera al ocurrir pagehide. Limpia tus listeners DOM, temporizadores y animaciones.

```ts
phone.dispose(); // undefined
console.log(phone.state); // 'disposed'
```

## Ciclo de vida del juego

### pl.state

Propiedad de solo lectura: `ready` o `disposed`.

```ts
console.log(pl.state); // 'ready'
```

### pl.on('close', callback)

Parámetros: literal `close` y callback `(payload: { code: string }) => void`. Devuelve `Unsubscribe`.

```ts
const off = pl.on('close', ({ code }) => console.log(code));
// Example callback payload: { code: 'HOST_CLOSED' }
```

### pl.onDispose(callback)

Parámetro: `callback: () => void`. Devuelve `Unsubscribe`. Se ejecuta al liberar el cliente, o inmediatamente si ya estaba liberado. Úsalo para tus recursos del juego.

```ts
const timer = window.setInterval(() => {}, 1000);
const off = pl.onDispose(() => window.clearInterval(timer));
// Callback receives no arguments; off() returns undefined.
```

### pl.dispose()

Parámetros: ninguno. Devuelve `void`. Libera el cliente de la SDK de forma idempotente. Limpia también tus bucles RAF, manejadores de eventos, temporizadores, suscripciones y medios.

```ts
pl.dispose(); // undefined
console.log(pl.state); // 'disposed'
```

## Compilación y formato ZIP

Configura Vite con `base: './'` y `build: { target: 'es2022' }` para recursos empaquetados con rutas relativas y await de nivel superior. Incluye scripts, estilos, fuentes, imágenes y audio en el paquete con rutas relativas. El juego debe funcionar sin CDN en ejecución ni rutas que necesiten un servidor. Proporciona `npm run package` para compilar y generar `release/game.zip`; el proyecto inicial del paquete ya incluye este proceso.

La raíz del ZIP debe contener directamente `manifest.json`, el HTML de entrada y la portada y los recursos referenciados. Comprime el contenido de la carpeta de salida, sin envolverlo en esa carpeta.

```json
{
  "schemaVersion": 1,
  "id": "living-room-quiz",
  "name": "Living Room Quiz",
  "version": "1.0.0",
  "description": "A quick quiz for friends and family using phone controls.",
  "players": { "min": 2, "max": 8 },
  "categories": ["party", "trivia"],
  "entry": "index.html",
  "cover": "cover.png",
  "sdkProtocolVersion": 1,
  "launch": { "mode": "iframe" }
}
```

Campos obligatorios: exactamente los del ejemplo. `id` cumple `[a-z0-9][a-z0-9-]{0,63}`; name: 1..100 caracteres; description: 1..500; version: tres partes numéricas; players min/max: enteros de 1..1000 con min <= max (las conexiones simultáneas siguen limitadas a 12); categories: 1..5 valores únicos. Categorías: party, puzzle, action, arcade, strategy, sports, racing, trivia, music, casual, developer-tools. Entry debe ser HTML dentro del paquete. Cover debe ser una imagen webp/png/jpg/jpeg/gif real. Modo de inicio: iframe o popup.

`locales` opcional asocia etiquetas BCP47 con `{ name?: string; description?: string }`; usa inglés en los valores predeterminados. Para cada campo, la búsqueda pasa del idioma exacto al idioma base y después al valor predeterminado. `customControllers` opcional asocia claves con rutas HTML, como se explica arriba. Se rechazan los campos adicionales del manifest. Publica las actualizaciones con una versión nueva. Durante el desarrollo local, importar un ZIP con el mismo ID de juego sustituye la copia local, aunque la versión no cambie.

Las rutas de recursos son relativas a la raíz del ZIP y distinguen mayúsculas. No admiten rutas absolutas, URL, segmentos vacíos, segmentos `.`/`..`, barras inversas, `%`, `?`, `#`, `:` ni caracteres de control. Límites: 50 MiB comprimidos, 200 MiB extraídos, 50 MiB por archivo, 2000 entradas, 240 caracteres por ruta y proporción de compresión máxima de 100:1. Usa un ZIP normal sin cifrar, con archivos regulares, rutas distintas y CRC válidos.

## Límites de mensajes y errores

Los mensajes ordinarios del juego admiten 4096 bytes UTF-8 en total, incluidos los campos del protocolo: mantén los datos bastante por debajo de ese tamaño. Utiliza datos compatibles con JSON; no se pueden enviar funciones, nodos DOM, objetos circulares ni BigInt. Las configuraciones de controladores y respuestas de selectores admiten 65536 bytes; el dibujo tiene límites propios. Para dibujos, usa esa función en lugar de enviar imágenes grandes en mensajes ordinarios.

Captura los errores y ofrece reintentar o instrucciones de inicio según corresponda. Códigos habituales: `HOST_NOT_FOUND` o errores del contexto de inicio; `HOST_BRIDGE_TIMEOUT`, `APP_BRIDGE_TIMEOUT`; `GAME_DISPOSED`, `CONTROLLER_DISPOSED`; `MESSAGE_TIMEOUT`, `MESSAGE_TOO_LARGE`; `INPUT_BLOCKED`; `CUSTOM_CONTROLLER_NOT_FOUND`, `CONTROLLER_COMPONENT_UNKNOWN`, `CONTROLLER_LAYOUT_CONFLICT`. Los códigos exactos pueden depender del paso que falló. Evita inicializar repetidamente en un bucle de reintentos sin límite.
