# Crear un juego de PartyLink desde cero

Convierte tu idea en un minijuego para jugar en familia o con amigos. La pantalla del ordenador o la televisión muestra la acción y los móviles funcionan como mandos.

## 1. Describe tu idea

Dile a la IA cómo se juega, cuántas personas participan y cómo se gana. Explica qué debería aparecer en la pantalla grande y qué acciones hará cada jugador desde su móvil. Una idea sencilla basta para empezar; por ejemplo, una carrera en la que cada persona pulsa un botón para avanzar.

## 2. Copia las instrucciones para la IA

Pulsa **«Copiar instrucciones en inglés para la IA»** y pega el texto en tu asistente, junto con tu idea. El texto está en inglés para que todos los asistentes reciban la misma referencia técnica; puedes seguir conversando con la IA en español. Las instrucciones incluyen un enlace a la API oficial para que la IA consulte la documentación actualizada antes de empezar.

## 3. Recibe el ZIP del juego

Pide a la IA que entregue `release/game.zip`, listo para importar, y un breve resumen de los controles. El archivo debe incluir `manifest.json` directamente en la raíz, sin una carpeta `dist` que lo envuelva. Si quieres cambiar las reglas o el aspecto, descríbeselo a la IA y pídele una nueva versión.

## 4. Importa y juega

Abre **Library** en PartyLink, importa el ZIP e inicia el juego. Escanea el código QR desde los móviles para unirte. Prueba los controles y una partida completa con otras personas; comparte con la IA cualquier problema para que lo corrija.
