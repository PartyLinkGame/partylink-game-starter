# Introducción

PartyLink convierte una reunión en una partida: el juego se ve en el ordenador o en la televisión y cada persona utiliza su móvil como mando. Está pensado para minijuegos casuales, actividades familiares y juegos multijugador para disfrutar juntos.

Puedes crear un juego a partir de una idea o adaptar uno que ya tengas. Cuenta a una IA qué quieres hacer, entrégale las instrucciones en inglés y deja que prepare el juego y su archivo ZIP. Después, impórtalo en Library y escanea el código QR con los móviles para probarlo.

## Elige por dónde empezar

- **[Crear un juego de PartyLink desde cero](quickstart.md):** transforma una idea en un juego listo para compartir en la pantalla grande.
- **[Conectar mi juego existente](integration.md):** conserva tu juego y añade los mandos móviles de PartyLink con ayuda de la IA.
- **[API pública y funciones disponibles](api.md):** consulta las funciones, eventos y ejemplos que la IA puede utilizar para implementar tu juego.

La SDK `@partylink/game-sdk@0.1.2` está publicada en npm. Las instrucciones para la IA incluyen los detalles de integración y empaquetado; tú puedes concentrarte en la experiencia que quieres crear y en probarla con otras personas.
