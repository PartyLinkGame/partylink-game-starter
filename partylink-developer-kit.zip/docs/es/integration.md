# Conectar mi juego existente

Adapta tu juego para jugar juntos en una pantalla grande, con móviles como mandos. La IA puede encargarse de la integración mientras tú decides cómo debe sentirse la partida.

## 1. Comparte tu juego con la IA

Entrega los archivos de tu proyecto y explica cómo se inicia, cómo se controla y cuántas personas pueden jugar. Indica qué quieres conservar y qué acciones deberían pasar al móvil: moverse, saltar, elegir respuestas o votar, por ejemplo. Si tu juego es individual, describe cómo imaginas la experiencia multijugador.

## 2. Copia las instrucciones para la IA

Pulsa **«Copiar instrucciones en inglés para la IA»** y pega el texto en tu asistente junto con el proyecto. Estas instrucciones proporcionan una referencia común para la integración. Puedes comentar los cambios y resolver dudas en español. Las instrucciones incluyen un enlace a la API oficial para que la IA consulte la documentación actualizada antes de empezar.

## 3. Recibe el juego adaptado

Pide a la IA que entregue `release/game.zip` y explique los cambios y los nuevos controles. El ZIP debe contener `manifest.json` directamente en la raíz, sin una carpeta `dist` exterior. Revisa con la IA que se mantengan las reglas, el aspecto y el ritmo que quieres conservar.

## 4. Importa y prueba con móviles

En PartyLink, abre **Library**, importa el ZIP e inicia el juego. Escanea el código QR con los móviles y juega una partida completa. Comprueba que cada móvil controla al jugador correcto y prueba salir y volver a entrar. Describe cualquier fallo a la IA para que prepare una versión corregida.
