# 공개 API와 지원 기능

SDK 버전: `@partylink/game-sdk@0.1.2`. 프로토콜 버전: `1`. AI가 아래 명세를 참고해 게임을 구현하고 패키징할 수 있도록 필요한 정보를 모았습니다.

## 설치 및 초기화

```sh
npm install --save-exact @partylink/game-sdk@0.1.2
```

```ts
import {
  PartyLink, createAudioAPI, getVolumeSettings, subscribeVolumeSettings,
  bindMediaVolume, renderDrawPath, AUDIO_THEMES, SFX_KINDS,
} from '@partylink/game-sdk';
import type { PlatformClient, Player, DrawPath } from '@partylink/game-sdk';
```

`PartyLink`와 위의 도우미 함수는 런타임에 사용하는 내보내기입니다. `PlatformClient` 등 인터페이스는 타입입니다. 클라이언트는 `PartyLink.init`으로 얻습니다.

### PartyLink.init(options)

PartyLink Library에서 시작한 게임이나 PartyLink가 연 사용자 지정 스마트폰 컨트롤러를 연결합니다.

게임의 매개변수: `{ mode: 'iframe' | 'popup'; timeoutMs?: number; allowedHostOrigins?: readonly string[]; allowInsecureDevelopment?: boolean }`. mode는 실행 환경과 일치해야 합니다. `timeoutMs` 기본값은 10000입니다. `allowedHostOrigins`를 지정하면 정확히 일치하는 출처만 허용합니다. `allowInsecureDevelopment`는 선택적인 개발 설정이며, 이 경우에도 유효한 실행 환경이 필요합니다. 스마트폰 페이지에서는 `{ mode: 'controller' }`만 사용합니다.

반환값: 게임은 `Promise<PlatformClient>`, 스마트폰은 `Promise<CustomControllerClient>`. 실행 환경이 없거나 유효하지 않거나 시간이 초과되면 거부됩니다. 게임 페이지를 직접 열었을 때는 올바른 실행 방법을 안내하세요.

```ts
const mode = new URLSearchParams(location.search).get('plMode');
if (mode !== 'iframe' && mode !== 'popup') {
  document.body.textContent = 'Launch this game from PartyLink Library.';
  throw new Error('Launch context required');
}
const pl = await PartyLink.init({ mode });
console.log(pl.state); // 'ready'
// In a custom controller page instead:
// const phone = await PartyLink.init({ mode: 'controller' });
```

게임 초기화 시 연결된 플레이어가 없고 참가가 허용되며 참가 화면을 사용할 수 있으면 참가 화면이 한 번 열립니다. 연결이 끊어질 때마다 자동으로 다시 열리지는 않습니다.

## 공통 데이터 및 동작

모든 `on` 및 구독 메서드는 `() => void` 함수인 `Unsubscribe`를 반환합니다. 이 함수를 호출하면 콜백 수신이 중단됩니다. 구독은 이후 변경을 관찰하므로 초기 상태를 제공하는 메서드가 있다면 별도로 조회하세요. 비동기 오류도 처리하세요. `Promise<void>`는 요청한 작업이 끝나면 값 없이 완료되며, 다른 기기의 게임 로직이 메시지를 처리했다는 확인은 아닙니다. 해제한 클라이언트를 호출하면 실패할 수 있습니다.

`playerId`는 항상 `Player.id`를 뜻합니다. 닉네임이나 배열 위치는 안정적인 식별자가 아닙니다. 현재 세션은 최대 12명의 플레이어를 지원합니다. 플레이어 스냅샷에는 연결이 끊긴 사람도 포함될 수 있습니다.

```ts
const player: Player = {
  id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '',
  gender: 'none', state: 'connected', joinedAt: 1730000000000,
  controllerType: 'dpad-abxy', isPrimary: true, controlMode: 'game',
};
```

Player 필수 필드: `id`, `sessionId`, `nickname`(1..64자), `avatar`(빈 문자열, JPEG 데이터 URL 또는 임시 blob URL), `gender`(`none`, `male`, `female`), `state`(`connecting`, `connected`, `disconnected`), `joinedAt`(숫자). 선택 필드 `controllerType`은 기본 프리셋 ID 또는 `custom`이며, `isPrimary`는 boolean, `controlMode`는 `game`, `remote`, `waiting` 중 하나입니다. 임시 아바타 blob URL을 다음 세션에 사용하도록 저장하지 마세요.

`ConnectionOverlayState`에는 필수 boolean 필드 `available`, `visible`, `canJoin`과 선택 문자열 필드 `qrPayload`, `overlayUrl`이 있습니다. 참가 데이터는 현재 세션에서만 유효합니다.

## 플레이어 및 참가: pl.host

### pl.host.getPlayers()

매개변수: 없음. 반환값: 로컬 상태를 복사한 `Player[]`.

```ts
const players = pl.host.getPlayers();
// [{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '',
//    gender: 'none', state: 'connected', joinedAt: 1730000000000 }]
```

### pl.host.getPlayer(id)

매개변수: `id: string`. 반환값: 복사한 `Player`; 해당 플레이어가 없으면 `undefined`.

```ts
const player = pl.host.getPlayer('p1'); // Player or undefined
```

### pl.host.removePlayer(id?)

플레이어의 연결을 끊고 제거합니다. 선택 매개변수: `id: string`. 생략하면 모든 플레이어를 제거합니다. 반환값: `Promise<void>`.

```ts
await pl.host.removePlayer('p1'); // undefined
```

### pl.host.getLobbyState()

매개변수: 없음. 반환값: `Promise<{ enabled: boolean; primaryPlayerId?: string }>`.

```ts
const lobby = await pl.host.getLobbyState();
// { enabled: true, primaryPlayerId: 'p1' }
```

### pl.host.setPrimaryPlayer(id)

대기실을 조작할 대표 플레이어를 정합니다. 매개변수: `id: string`. 반환값: `Promise<void>`.

```ts
await pl.host.setPrimaryPlayer('p1'); // undefined
```

### pl.host.setLobbyMode(enabled)

대기실 리모컨 조작(`true`)과 게임 입력(`false`) 사이를 전환합니다. 게임 로직을 시작하거나 일시 정지하지는 않습니다. 매개변수: `enabled: boolean`. 반환값: `Promise<void>`.

```ts
await pl.host.setLobbyMode(false); // undefined
```

### pl.host.getConnectionOverlay()

매개변수: 없음. 반환값: `Promise<ConnectionOverlayState>`.

```ts
const overlay = await pl.host.getConnectionOverlay();
// { available: true, visible: false, canJoin: true, qrPayload: 'session-join-data' }
```

### pl.host.setConnectionOverlay(visible)

플랫폼 참가 화면을 표시하거나 숨깁니다. 매개변수: `visible: boolean`. 반환값: `Promise<void>`. 화면을 표시해도 진행 중인 게임은 일시 정지되지 않습니다.

```ts
await pl.host.setConnectionOverlay(true); // undefined
```

### pl.host.on(event, callback)

매개변수: 아래 이벤트 중 하나와 해당 데이터를 받는 콜백. 반환값: `Unsubscribe`.

```ts
const off = pl.host.on('player:join', async (player) => {
  await pl.app.setController('dpad-abxy', player.id);
});
off(); // undefined; stop this listener
```

각 플레이어 이벤트는 `player` 속성으로 감싸지 않은 Player 객체를 직접 전달합니다.

```ts
// 'player:join'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'connected', joinedAt: 1730000000000 }
// 'player:update'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'connected', joinedAt: 1730000000000, isPrimary: true }
// 'player:leave'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'disconnected', joinedAt: 1730000000000 }
// 'connection:overlay'
{ available: true, visible: true, canJoin: true, qrPayload: 'session-join-data' }
```

`getPlayers()`로 기존 플레이어를 설정하고, 새로 참가하거나 돌아오는 플레이어는 현재 라운드에 맞게 join/update에서 설정하세요. 연결이 끊기면 누르고 있던 입력 상태를 초기화하세요.

## 게임 설정: pl.game

### pl.game.getLocale()

매개변수: 없음. 현재 언어 문자열을 반환합니다. 게임 자체의 문구를 번역할 때 이 값을 사용하세요.

```ts
const locale = pl.game.getLocale(); // 'en-US'
```

### pl.game.getVolumeSettings()

매개변수: 없음. 반환값: `VolumeSettings`, 즉 `{ music: number; effects: number }`. 각 값의 범위는 0..1입니다.

```ts
const settings = pl.game.getVolumeSettings(); // { music: 0.5, effects: 0.5 }
```

### pl.game.subscribeVolumeSettings(callback)

매개변수: 콜백 `(settings: VolumeSettings) => void`. 반환값: `Unsubscribe`. 초기값을 즉시 전달하지는 않습니다.

```ts
const initial = pl.game.getVolumeSettings();
const off = pl.game.subscribeVolumeSettings((settings) => {
  console.log(settings.effects); // 0.7 after a matching change
});
```

### pl.game.requestClose()

PartyLink에 게임 종료를 요청합니다. 매개변수: 없음. 반환값: `Promise<void>`.

```ts
await pl.game.requestClose(); // undefined
```

### pl.game.on(event, callback)

매개변수: `event: 'locale:change' | 'game:control'` 및 해당 데이터를 받는 콜백. 반환값: `Unsubscribe`.

```ts
const off = pl.game.on('locale:change', ({ locale }) => {
  document.documentElement.lang = locale;
});
// 'locale:change' payload: { locale: 'en-US' }
// 'game:control' payload: { playerId: 'p1', action: 'pause' }
// Resume payload: { playerId: 'p1', action: 'resume' }
```

`game:control`은 일시 정지와 재개를 요청합니다. 게임 시뮬레이션, 타이머, 오디오에 반영하고, 일시 정지 시 누르고 있던 입력을 초기화하세요.

### pl.game.audio

컴퓨터 게임 페이지에서 소리를 재생하는 `AudioAPI` 인스턴스입니다. 아래에 모든 메서드가 설명되어 있습니다. 플랫폼 효과음 채널을 따르며 SDK 클라이언트와 함께 해제됩니다.

```ts
const played = pl.game.audio.confirm(); // true if a sound was created
```

## 스마트폰 조작 및 피드백: pl.app

### pl.app.setController(name, playerId?, layout?)

스마트폰 컨트롤러를 설정합니다. 매개변수: `name: string`(프리셋, 조합 또는 manifest의 사용자 지정 컨트롤러 키), 선택 `playerId: string`, 선택 `layout: ControllerLayoutInput`. 반환값: `Promise<void>`. playerId를 생략하면 현재 플레이어에게만 적용되므로 나중에 참가한 플레이어는 별도로 설정하세요. 모두에게 레이아웃을 전달하려면 두 번째 인수에 `undefined`를 넣으세요.

```ts
await pl.app.setController('joystick-action', 'p1'); // undefined
await pl.app.setController('custom-buttons', undefined, {
  orientation: 'landscape',
  components: [{ type: 'custom-buttons', buttons: [
    { controlId: 'jump', label: 'Jump', gridX: 0, gridY: 0, spanX: 2 },
  ] }],
}); // undefined
```

### pl.app.setControllersEnabled(enabled, playerId?)

레이아웃을 바꾸지 않고 게임 입력을 허용하거나 차단합니다. 매개변수: `enabled: boolean`, 선택 `playerId: string`. 반환값: `Promise<void>`. ID를 생략하면 지속적인 전체 입력 허용 상태를 설정하고 개별 상태를 초기화합니다. 이후 참가와 재연결에도 적용됩니다. 특정 플레이어의 설정은 전체 설정과 함께 적용되므로 둘 다 허용해야 입력할 수 있습니다. 비활성화된 사용자 지정 컨트롤러는 게임 메시지를 보낼 수 없습니다. 입력을 차단할 때 로컬의 누름 상태도 초기화하세요.

```ts
await pl.app.setControllersEnabled(false); // undefined; pause all input
await pl.app.setControllersEnabled(true); // undefined; allow all input again
await pl.app.setControllersEnabled(false, 'p1'); // undefined; block this player
```

### pl.app.showToast(options, playerId?)

스마트폰에 일반 텍스트 토스트를 표시하고 기존 토스트를 교체합니다. 매개변수: `{ text: string; type?: 'text' | 'success' | 'error'; position?: 'top' | 'center' | 'bottom'; duration?: number }`, 선택 대상 ID. 반환값: `Promise<void>`. ID를 생략하면 현재 플레이어에게 적용됩니다. 앞뒤 공백을 제거한 텍스트는 UTF-16 기준 1..200자, duration은 1000..10000밀리초의 정수입니다. 기본값: `text`, `center`, 3000. 풍부한 콘텐츠나 대화상자는 게임 UI로 구현하세요.

```ts
await pl.app.showToast({ text: 'Your turn!', type: 'success', duration: 2000 }, 'p1');
// undefined
```

### pl.app.sendMessage(payload, playerId?)

사용자 지정 스마트폰 페이지에 게임 데이터를 보냅니다. 매개변수: JSON으로 직렬화할 수 있는 `payload: unknown`, 선택 플레이어 ID. 반환값: `Promise<void>`. ID를 생략하면 현재 플레이어에게 보냅니다. 처리 완료 확인이 필요하면 별도의 응답 메시지를 구현하세요.

```ts
await pl.app.sendMessage({ type: 'round', roundId: 'r1', score: 3 }, 'p1');
// undefined; phone.game.on('message') receives that payload directly
```

### pl.app.audio.play(kind, playerId?, options?)

스마트폰에서 소리를 재생합니다. 매개변수: `kind: SfxKind`, 선택 ID, 세 번째 위치의 선택 `{ theme?: AudioTheme }`. 반환값: `Promise<AudioPlaybackResult[]>`. 한 명에게 보내도 배열을 반환합니다. ID를 생략하면 현재 플레이어가 대상입니다. 브라우저가 오디오를 계속 차단할 수 있으므로 재생 결과를 확인하세요.

```ts
const results = await pl.app.audio.play('success', 'p1', { theme: 'arcade' });
// [{ playerId: 'p1', played: true, state: 'running' }]
// A failure might be [{ playerId: 'p1', played: false, state: 'suspended',
//   reason: 'AUDIO_USER_GESTURE_REQUIRED' }]
```

결과 필드: `playerId: string`, `played: boolean`, `state: AudioState`, 선택 `reason: string`. AudioState 값: `idle`, `running`, `suspended`, `closed`, `error`, `unsupported`.

### pl.app.on(event, callback)

매개변수: `input`, `remote:action`, `message`, `selector:submit`, `draw:path`, `draw:frame` 중 하나와 해당 콜백. 반환값: `Unsubscribe`. 모든 이벤트 데이터에는 보낸 사람의 `playerId`가 포함됩니다.

```ts
const off = pl.app.on('input', (input) => {
  if (input.type === 'button' && input.action === 'click' && !input.synthetic) {
    console.log(input.playerId, input.controlId); // 'p1', 'a'
  }
});
```

입력 데이터 예:

```ts
// Button: type 'button', action 'down' | 'up' | 'click'
{ protocolVersion: 1, sessionId: 's1', playerId: 'p1', sequence: 1,
  timestamp: 1730000000000, controlId: 'a', synthetic: false,
  type: 'button', action: 'down' }
// Axis: x and y in -1..1
{ protocolVersion: 1, sessionId: 's1', playerId: 'p1', sequence: 2,
  timestamp: 1730000000001, controlId: 'left_stick', synthetic: false,
  type: 'axis', x: 0.5, y: -0.2 }
```

공통 필드: `protocolVersion: 1`; 문자열 `sessionId`, `playerId`; 음수가 아닌 안전한 정수 `sequence`; 음수가 아닌 정수 `timestamp`; 1..64자의 영문자, 숫자, 밑줄, 하이픈으로 된 `controlId`; boolean `synthetic`. 한 번 탭하면 down/up/click이 생길 수 있으므로 일회성 점수 처리는 한 단계에서만 하세요. 누르고 있는 동작은 down/up을 추적하세요. 합성 이벤트는 입력을 안전한 상태로 복원합니다. 해제와 중립 축은 반영하되 새 플레이어 동작으로 점수를 주지 마세요.

다른 이벤트의 데이터 예:

```ts
// 'remote:action': action is up/down/left/right/confirm/cancel/back
{ playerId: 'p1', action: 'confirm' }
// 'message': custom phone data; validate shape, ranges, round, and frequency
{ playerId: 'p1', payload: { type: 'jump', roundId: 'r1' } }
// 'selector:submit'
{ playerId: 'p1', controlId: 'vote', requestId: 'r1', values: ['cat'] }
// 'draw:path'
{ playerId: 'p1', kind: 'path', action: 'move', controlId: 'sketch',
  requestId: 'r1', width: 1024, height: 768, backgroundColor: '#FFFFFF',
  strokeId: 'stroke-1', tool: 'pen', color: '#111111', strokeWidth: 0.01,
  points: [{ x: 0.2, y: 0.3 }, { x: 0.25, y: 0.35 }] }
// 'draw:frame': dataUrl contains a complete reassembled WebP image
{ playerId: 'p1', kind: 'frame', action: 'submit', controlId: 'sketch',
  requestId: 'r1', width: 1024, height: 768, backgroundColor: '#FFFFFF',
  frameId: 'frame-1', dataUrl: 'data:image/webp;base64,UklGR...' }
```

위의 축약된 데이터 URL은 필드 형식을 보여 주는 예이며 실제 이미지가 아닙니다. requestId가 현재 라운드와 일치하는지 확인하고 중복 제출은 무시하세요.

## 컨트롤러 이름 및 레이아웃 필드

기본 프리셋: `dpad-abxy`, `joystick-action`, `custom-buttons`, `multi-row-buttons`, `remote`, `selector`, `draw`. 컴포넌트 이름을 순서대로 조합할 수도 있습니다. 예: `joystick+dual-buttons`. 사용 가능한 컴포넌트: `joystick`, `dual-buttons`, `quad-buttons`, `dpad`, `menu-keys`, `custom-buttons`, `multi-row-buttons`, `selector`, `draw`.

`ControllerLayoutInput`에는 선택 `orientation: 'auto' | 'portrait' | 'landscape'`와 필수 `components`(1..4개)가 있습니다. 타입은 조합 이름 및 순서와 일치해야 합니다. 기본 방향은 `auto`이며, selector 하나만 있으면 `portrait`입니다. control ID는 레이아웃 전체에서 고유해야 합니다. Draw는 단독으로 사용합니다. Remote는 고정된 가로 방향 dpad + menu-keys 레이아웃을 사용합니다.

- 조이스틱: `{ type: 'joystick', controlId?: string, deadZone?: number }`. 기본값: `left_stick`, 0.12. deadZone 범위: 0..0.9.
- 버튼 2개: `{ type: 'dual-buttons' }`. ID: `a`, `b`.
- 버튼 4개: `{ type: 'quad-buttons' }`. ID: `a`, `b`, `x`, `y`.
- 방향키: `{ type: 'dpad' }`. ID: `up`, `down`, `left`, `right`.
- 메뉴 키: `{ type: 'menu-keys' }`. ID: `menu_back`, `menu_cancel`, `menu_confirm`.
- 사용자 지정 버튼: `{ type: 'custom-buttons', buttons: ButtonDefinition[] }`. 버튼 1..12개. 각 버튼에는 `controlId`, `label`, 0..3의 정수 `gridX/gridY`, 선택적인 1..2의 정수 `spanX/spanY`(기본값 1), 선택 `backgroundColor/textColor`가 있습니다. 버튼은 4×4 격자에 겹치거나 밖으로 나가지 않게 배치합니다.
- 여러 행 버튼: `{ type: 'multi-row-buttons', buttons: [{ code, label, backgroundColor?, textColor? }] }`. 버튼 1..4개. `code`가 control ID입니다.

ID: 1..64자의 영문자, 숫자, 밑줄, 하이픈. 버튼 문구: 1..16자. 버튼 색상: `#RGB` 또는 `#RRGGBB`. 사용자 지정 버튼 프리셋에는 명시적인 레이아웃을 전달해 의미 있는 ID를 정하세요.

### Selector 설정

```ts
await pl.app.setController('selector', 'p1', {
  components: [{ type: 'selector', controlId: 'vote', requestId: 'r1',
    title: 'Choose an animal', mode: 'single',
    options: [{ id: 'cat', label: 'Cat' }, { id: 'dog', label: 'Dog' }],
  }],
}); // undefined
```

필드: `type: 'selector'`; 선택 `controlId`(기본값 `selector`); 선택 `requestId`(1..128자, 기본값 임의 UUID; 라운드마다 구분되는 값을 사용); 선택 `title`(최대 120자, 기본값 빈 문자열); 선택 `mode`(기본값 `single`, 또는 `multiple`); 필수 `options`(고유 ID 1..100개). 옵션 ID는 control ID 형식을 따르며 문구는 1..120자입니다. 선택 `submittedValues: string[]`는 제출한 선택을 복원합니다. 비어 있지 않은 고유 옵션 ID 목록이며 single은 1개, multiple은 최대 100개입니다. 제출은 `selector:submit`으로 도착합니다.

### Draw 설정

```ts
await pl.app.setController('draw', 'p1', {
  components: [{ type: 'draw', controlId: 'sketch', requestId: 'r1',
    title: 'Draw a cat', width: 1024, height: 768,
    backgroundColor: '#FFFFFF', output: 'path', fps: 5, showSubmit: true,
  }],
}); // undefined
```

선택 필드와 기본값: `controlId: 'draw'`; `requestId`: 임의 UUID, 1..128자; `title`: 최대 120자; `width: 1024`, `height: 768`, 각각 64..2048 정수; `backgroundColor: '#FFFFFF'`(6자리 16진수); `output: 'path'` 또는 `frame`; `fps: 5`(1..10); `showSubmit: true`; `initialImage`: WebP base64 데이터 URL, 최대 48000자. 임의의 이미지 URL은 받지 않습니다.

`DrawPath`: `kind: 'path'`; action은 `start`, `move`, `end`, `clear`, `submit`; 캔버스 필드 `controlId`, `requestId`, `width`, `height`, `backgroundColor`; `strokeId`(1..128자); `tool: 'pen' | 'eraser'`; 6자리 16진수 `color`; 캔버스 크기에 대한 상대값 `strokeWidth` 0.0001..1; 0..1로 정규화된 점 최대 64개의 `points: { x: number; y: number }[]`. 이벤트에는 `playerId`가 추가됩니다.

`DrawFrame`에는 위 캔버스 필드, `playerId`, `kind: 'frame'`, action `frame`, `submit`, `clear` 중 하나, 문자열 `frameId`, 완전한 WebP `dataUrl`이 포함됩니다. 이벤트 전에 프레임이 재조립됩니다. 이미지 문자열은 최대 524288자이며, 16384자씩 최대 32개 조각을 5초 안에 완성해야 합니다. 프레임 속도는 적당히 낮게 설정하세요.

내보내는 `DrawPacket` 타입은 경로 또는 프레임 조각을 나타냅니다. 프레임 조각에는 `dataUrl` 대신 `index`, `length`, `data`가 있습니다. 일반 게임 리스너는 조립된 `DrawFrame`을 사용합니다.

### renderDrawPath(context, path)

정규화된 그리기 동작을 Canvas에 렌더링합니다. 매개변수: `CanvasRenderingContext2D`, `DrawPath`. 반환값: `void`. 캔버스 크기는 Draw 설정과 맞추고, 플레이어마다 별도 캔버스를 사용하며, 제출은 게임 로직에서 처리하세요.

```ts
const canvases = new Map<string, HTMLCanvasElement>();
pl.app.on('draw:path', (path) => {
  let canvas = canvases.get(path.playerId);
  if (!canvas) {
    canvas = document.createElement('canvas');
    canvas.width = path.width; canvas.height = path.height;
    canvases.set(path.playerId, canvas);
    document.body.append(canvas);
  }
  renderDrawPath(canvas.getContext('2d')!, path); // undefined
});
```

## AudioAPI

`pl.game.audio`, `phone.app.audio`, `createAudioAPI()`는 아래 메서드를 공유합니다. 테마: `default`, `retro8bit`, `arcade`, `glass`, `cyber`. 소리 종류: `click`, `focus`, `back`, `confirm`, `cancel`, `success`, `error`, `unlock`, `coin`, `notify`, `join`, `leave`, `countdown`. `AUDIO_THEMES`와 `SFX_KINDS`는 이 문자열들의 읽기 전용 배열을 내보냅니다.

브라우저는 소리를 재생하기 전에 해당 기기의 실제 사용자 조작을 요구할 수 있습니다. 스마트폰 조작으로 컴퓨터 페이지의 오디오가 해제되지는 않습니다. 필요하면 컴퓨터에 소리 활성화 버튼을 제공하세요. 아래 예는 `const audio = pl.game.audio`를 사용합니다.

### audio.play(kind, options?)

매개변수: `kind: SfxKind`, 이 소리의 테마만 바꾸는 선택 `{ theme?: AudioTheme }`. 소리를 생성했는지 나타내는 boolean을 반환하며 실제로 들렸다는 보장은 아닙니다. False는 음소거, 일시 중단, 해제, 미지원, 잘못된 소리 또는 동시 재생 한도 도달을 뜻할 수 있습니다. 필요에 따라 상태와 오류를 확인하세요.

```ts
const played = audio.play('coin', { theme: 'retro8bit' }); // true or false
```

### audio.click()

현재 테마로 `click` 소리를 재생합니다. 매개변수: 없음. `play`와 같은 의미의 boolean을 반환합니다.

```ts
const played = audio.click(); // true or false
```

### audio.focus()

현재 테마로 `focus` 소리를 재생합니다. 매개변수: 없음. `play`와 같은 의미의 boolean을 반환합니다.

```ts
const played = audio.focus(); // true or false
```

### audio.back()

현재 테마로 `back` 소리를 재생합니다. 매개변수: 없음. `play`와 같은 의미의 boolean을 반환합니다.

```ts
const played = audio.back(); // true or false
```

### audio.confirm()

현재 테마로 `confirm` 소리를 재생합니다. 매개변수: 없음. `play`와 같은 의미의 boolean을 반환합니다.

```ts
const played = audio.confirm(); // true or false
```

### audio.cancel()

현재 테마로 `cancel` 소리를 재생합니다. 매개변수: 없음. `play`와 같은 의미의 boolean을 반환합니다.

```ts
const played = audio.cancel(); // true or false
```

### audio.success()

현재 테마로 `success` 소리를 재생합니다. 매개변수: 없음. `play`와 같은 의미의 boolean을 반환합니다.

```ts
const played = audio.success(); // true or false
```

### audio.error()

현재 테마로 `error` 소리를 재생합니다. 매개변수: 없음. `play`와 같은 의미의 boolean을 반환합니다.

```ts
const played = audio.error(); // true or false
```

### audio.unlock()

현재 테마로 `unlock` 소리를 재생합니다. 매개변수: 없음. `play`와 같은 의미의 boolean을 반환합니다.

```ts
const played = audio.unlock(); // true or false
```

### audio.coin()

현재 테마로 `coin` 소리를 재생합니다. 매개변수: 없음. `play`와 같은 의미의 boolean을 반환합니다.

```ts
const played = audio.coin(); // true or false
```

### audio.notify()

현재 테마로 `notify` 소리를 재생합니다. 매개변수: 없음. `play`와 같은 의미의 boolean을 반환합니다.

```ts
const played = audio.notify(); // true or false
```

### audio.join()

현재 테마로 `join` 소리를 재생합니다. 매개변수: 없음. `play`와 같은 의미의 boolean을 반환합니다.

```ts
const played = audio.join(); // true or false
```

### audio.leave()

현재 테마로 `leave` 소리를 재생합니다. 매개변수: 없음. `play`와 같은 의미의 boolean을 반환합니다.

```ts
const played = audio.leave(); // true or false
```

### audio.countdown()

현재 테마로 `countdown` 소리를 재생합니다. 매개변수: 없음. `play`와 같은 의미의 boolean을 반환합니다.

```ts
const played = audio.countdown(); // true or false
```

### audio.resume()

오디오를 초기화하거나 재개합니다. 매개변수: 없음. 반환값: `Promise<void>`. 로컬 사용자 조작이 필요하거나 오디오를 사용할 수 없으면 거부될 수 있습니다. `unlock()`은 소리 재생 단축 메서드이며 이 재개 동작과 다릅니다.

```ts
soundButton.addEventListener('click', async () => {
  try { await audio.resume(); audio.confirm(); }
  catch (error) { console.error(error); }
}); // resume resolves to undefined
```

### audio.isSupported()

매개변수: 없음. AudioContext 사용 가능 여부를 boolean으로 반환합니다.

```ts
const supported = audio.isSupported(); // true or false
```

### audio.getState()

매개변수: 없음. 반환값: `AudioState`, 즉 idle/running/suspended/closed/error/unsupported.

```ts
const state = audio.getState(); // 'running'
```

### audio.getLastError()

매개변수: 없음. 반환값: 마지막으로 기록한 재생 또는 재개 오류인 `string | undefined`.

```ts
const error = audio.getLastError(); // undefined or 'AUDIO_USER_GESTURE_REQUIRED'
```

### audio.setTheme(theme)

매개변수: `theme: AudioTheme`. 반환값: `void`. 이후 재생할 소리의 기본 테마를 설정합니다.

```ts
audio.setTheme('glass'); // undefined
```

### audio.getTheme()

매개변수: 없음. 반환값: `AudioTheme`. 초기값은 `default`입니다.

```ts
const theme = audio.getTheme(); // 'glass'
```

### audio.setVolume(volume)

매개변수: 0..1로 제한되는 로컬 믹스 `volume: number`. 반환값: `void`. 플랫폼 볼륨 연동이 활성화되어 있으면 효과음 채널과 결합됩니다.

```ts
audio.setVolume(0.8); // undefined
```

### audio.getVolume()

매개변수: 없음. 플랫폼과 결합된 음량이 아닌 로컬 믹스 음량을 반환합니다. 초기값은 1입니다.

```ts
const volume = audio.getVolume(); // 0.8
```

### audio.mute()

매개변수: 없음. 반환값: `void`. 음소거하고 현재 재생 중인 소리를 멈춥니다.

```ts
audio.mute(); // undefined
```

### audio.unmute()

매개변수: 없음. 반환값: `void`. 이후 소리에 사용할 로컬 믹스를 복원합니다.

```ts
audio.unmute(); // undefined
```

### audio.isMuted()

매개변수: 없음. 로컬 음소거 상태를 boolean으로 반환합니다.

```ts
const muted = audio.isMuted(); // false
```

### audio.dispose()

매개변수: 없음. 반환값: `void`. 소리, 구독, 오디오 컨텍스트를 해제하며 여러 번 호출해도 안전합니다. SDK 소유 오디오는 클라이언트와 함께 해제되며 별도로 만든 인스턴스는 직접 해제하세요.

```ts
audio.dispose(); // undefined
audio.getState(); // 'closed'
```

### createAudioAPI(options?)

독립적인 AudioAPI를 만듭니다. 선택 매개변수: `{ AudioContextImpl?: typeof AudioContext; autoUnlock?: boolean; followPlatformVolume?: boolean }`. 기본값은 브라우저 AudioContext, 실제 사용자 조작에 따른 자동 해제, 현재 페이지의 효과음 설정 연동입니다. 반환값: `AudioAPI`.

```ts
const extraAudio = createAudioAPI({ autoUnlock: true, followPlatformVolume: true });
extraAudio.getTheme(); // 'default'
extraAudio.dispose();
```

### getVolumeSettings()

`pl.game.getVolumeSettings()`에 해당하는 최상위 함수입니다. 매개변수: 없음. 현재 페이지의 `VolumeSettings` 복사본을 반환합니다.

```ts
const settings = getVolumeSettings(); // { music: 0.5, effects: 0.5 }
```

### subscribeVolumeSettings(callback)

게임 구독에 해당하는 최상위 함수입니다. 매개변수: `(settings: VolumeSettings) => void`. 반환값: `Unsubscribe`. 초기값은 별도로 읽으세요.

```ts
const off = subscribeVolumeSettings((settings) => console.log(settings.music));
// A later callback might receive { music: 0.7, effects: 0.5 }
off(); // undefined
```

### bindMediaVolume(media, channel)

기존 미디어의 믹스 음량을 플랫폼 음악 또는 효과음 음량에 연결합니다. 매개변수: `media: { volume: number }`(보통 HTMLAudioElement), `channel: 'music' | 'effects'`. 반환값: 원래 미디어 음량 동작을 복원하는 `Unsubscribe`. 실제 음량은 기본 믹스와 선택 채널을 곱한 값입니다. 연결 중 `media.volume`을 설정하면 기본 믹스가 갱신됩니다.

```ts
const music = new Audio('./assets/music.ogg');
music.volume = 0.8;
const off = bindMediaVolume(music, 'music');
// At platform music 0.5, effective playback volume is 0.4.
pl.onDispose(() => { off(); music.pause(); });
```

자체 WebAudio 그래프에서는 설정을 읽고 구독한 뒤 고정된 기본값을 기준으로 GainNode를 갱신하세요. 직전 값에 계속 곱하지 마세요.

## 사용자 지정 스마트폰 페이지

manifest에 `customControllers: { steering: 'controllers/steering.html' }`을 선언하고 레이아웃 없이 `pl.app.setController('steering', 'p1')`으로 활성화합니다. 키는 1..64자의 영문자, 숫자, 밑줄, 하이픈이며 기본 프리셋이나 컴포넌트 이름(`custom` 포함)과 달라야 합니다. 컨트롤러 HTML을 빌드 진입점으로 포함하고 리소스도 패키징하세요.

```ts
const phone = await PartyLink.init({ mode: 'controller' });
```

이 페이지에는 별도의 컨트롤러 클라이언트가 제공됩니다. `phone.state`는 `ready` 또는 `disposed`입니다.

### phone.app.isEnabled()

매개변수: 없음. 현재 입력이 허용되는지 boolean으로 반환합니다. 보내기 전에 확인하고, 비활성화되거나 숨겨지면 자체 누름 상태를 초기화하세요.

```ts
if (phone.app.isEnabled()) await phone.game.sendMessage({ type: 'jump' });
// true allows sending; false means input is blocked
```

### phone.app.requestOrientation(orientation)

매개변수: `orientation: 'auto' | 'portrait' | 'landscape'`. 반환값: `void`. 화면 표시 방향을 요청하며 운영체제의 물리적 방향 잠금을 보장하지는 않습니다.

```ts
phone.app.requestOrientation('landscape'); // undefined
```

### phone.app.audio

위의 모든 메서드를 갖춘 로컬 AudioAPI입니다. 이 컨트롤러 페이지는 독립적인 음량 상태를 사용하므로 로컬 오디오와 볼륨 도우미는 플랫폼 음량 변경을 자동으로 받지 않습니다. 플랫폼 음량을 따르는 스마트폰 효과음이 필요하면 게임 메시지를 보내고 게임에서 `pl.app.audio.play`를 호출하세요.

```ts
phone.app.audio.getState(); // 'idle', for example
```

### phone.game.sendMessage(payload)

매개변수: playerId로 감싸지 않은 JSON 직렬화 가능한 `payload: unknown`. 스마트폰이 전송을 수락하면 `Promise<void>`를 반환하며 게임의 처리 완료 확인은 아닙니다. 5초 후 시간 초과됩니다. 비활성 상태에서는 `INPUT_BLOCKED`로 거부됩니다. 게임은 데이터와 함께 인증된 발신자 ID를 받습니다.

```ts
await phone.game.sendMessage({ type: 'jump', roundId: 'r1' }); // undefined
// Game 'message' payload: { playerId: 'p1', payload: { type: 'jump', roundId: 'r1' } }
```

### phone.game.on('message', callback)

매개변수: 리터럴 `message`와 콜백 `(payload: unknown) => void`. 반환값: `Unsubscribe`. 게임이 보낸 데이터를 직접 받습니다.

```ts
const off = phone.game.on('message', (payload) => console.log(payload));
// Example callback payload: { type: 'round', roundId: 'r1', score: 3 }
off(); // undefined
```

### phone.dispose()

매개변수: 없음. 반환값: `void`. 컨트롤러 클라이언트와 오디오를 해제하며 반복 호출해도 안전합니다. 대기 중인 전송은 거부됩니다. pagehide 시에도 해제됩니다. 자체 DOM 리스너, 타이머, 애니메이션도 정리하세요.

```ts
phone.dispose(); // undefined
console.log(phone.state); // 'disposed'
```

## 게임 수명 주기

### pl.state

읽기 전용 속성입니다. 값은 `ready` 또는 `disposed`입니다.

```ts
console.log(pl.state); // 'ready'
```

### pl.on('close', callback)

매개변수: 리터럴 `close`와 콜백 `(payload: { code: string }) => void`. 반환값: `Unsubscribe`.

```ts
const off = pl.on('close', ({ code }) => console.log(code));
// Example callback payload: { code: 'HOST_CLOSED' }
```

### pl.onDispose(callback)

매개변수: `callback: () => void`. 반환값: `Unsubscribe`. 해제 시 호출되며 이미 해제되었다면 즉시 호출됩니다. 게임 리소스 정리에 사용하세요.

```ts
const timer = window.setInterval(() => {}, 1000);
const off = pl.onDispose(() => window.clearInterval(timer));
// Callback receives no arguments; off() returns undefined.
```

### pl.dispose()

매개변수: 없음. 반환값: `void`. SDK 클라이언트를 해제하며 반복 호출해도 안전합니다. 자체 RAF 루프, 이벤트 핸들러, 타이머, 구독, 미디어도 정리하세요.

```ts
pl.dispose(); // undefined
console.log(pl.state); // 'disposed'
```

## 빌드 및 ZIP 형식

상대 경로로 패키징한 리소스와 최상위 await를 지원하도록 Vite에 `base: './'`, `build: { target: 'es2022' }`를 설정하세요. 스크립트, 스타일, 글꼴, 이미지, 오디오를 상대 경로로 패키지 안에 포함하세요. 패키징한 게임은 실행 중 CDN이나 서버 전용 라우팅 없이 동작해야 합니다. 빌드 후 `release/game.zip`을 만드는 `npm run package` 스크립트를 제공하세요. 개발 패키지의 시작 프로젝트에는 이 과정이 준비되어 있습니다.

ZIP 최상위에는 `manifest.json`, 진입 HTML, 참조한 표지와 리소스가 직접 있어야 합니다. 출력 폴더 자체가 아닌 그 안의 내용을 압축하세요.

```json
{
  "schemaVersion": 1,
  "id": "living-room-quiz",
  "name": "Living Room Quiz",
  "version": "1.0.0",
  "description": "A quick quiz for friends and family using phone controls.",
  "players": { "min": 2, "max": 8 },
  "categories": ["party", "trivia"],
  "entry": "index.html",
  "cover": "cover.png",
  "sdkProtocolVersion": 1,
  "launch": { "mode": "iframe" }
}
```

필수 필드는 예제에 나온 항목들입니다. `id` 형식은 `[a-z0-9][a-z0-9-]{0,63}`; name은 1..100자; description은 1..500자; version은 숫자 세 부분입니다. players min/max는 1..1000의 정수이며 min <= max입니다(실제 동시 연결은 최대 12명). categories는 고유한 값 1..5개입니다. 카테고리 값: party, puzzle, action, arcade, strategy, sports, racing, trivia, music, casual, developer-tools. Entry는 패키지 안의 HTML이어야 합니다. Cover는 실제 webp/png/jpg/jpeg/gif 이미지여야 합니다. 실행 모드는 iframe 또는 popup입니다.

선택 `locales`는 BCP47 태그를 `{ name?: string; description?: string }`에 연결하며 기본 문구는 영어로 작성합니다. 각 필드는 정확한 언어 태그, 기본 언어, 기본 문구 순서로 찾습니다. 선택 `customControllers`는 위에서 설명한 것처럼 키와 HTML 경로를 연결합니다. 명세에 없는 manifest 필드는 거부됩니다. 공개 업데이트는 새 버전으로 배포하세요. 로컬 개발 중 같은 게임 ID의 ZIP을 가져오면 버전이 같아도 로컬 사본이 교체됩니다.

리소스 경로는 ZIP 최상위 기준 상대 경로이며 대소문자를 구분합니다. 절대 경로, URL, 빈 경로 구간, `.`/`..` 구간, 역슬래시, `%`, `?`, `#`, `:`, 제어 문자는 사용할 수 없습니다. ZIP 한도: 압축 50 MiB, 해제 200 MiB, 파일당 50 MiB, 항목 2000개, 경로당 240자, 최대 압축률 100:1. 경로가 서로 다르고 CRC가 유효한 일반 파일을 넣은 암호화되지 않은 일반 ZIP을 사용하세요.

## 메시지 크기 및 오류

일반 게임 메시지는 프로토콜 필드를 포함한 전체 크기가 UTF-8 기준 4096바이트 이하여야 하므로 데이터 크기에 여유를 두세요. JSON 호환 데이터를 사용하세요. 함수, DOM 노드, 순환 객체, BigInt는 보낼 수 없습니다. 컨트롤러 설정과 selector 제출의 한도는 65536바이트이며 그림에는 별도 한도가 적용됩니다. 그림은 일반 메시지에 큰 이미지로 보내기보다 그리기 기능을 사용하세요.

오류를 처리하고 상황에 맞게 재시도나 실행 방법을 안내하세요. 일반적인 코드: `HOST_NOT_FOUND` 또는 실행 환경 오류; `HOST_BRIDGE_TIMEOUT`, `APP_BRIDGE_TIMEOUT`; `GAME_DISPOSED`, `CONTROLLER_DISPOSED`; `MESSAGE_TIMEOUT`, `MESSAGE_TOO_LARGE`; `INPUT_BLOCKED`; `CUSTOM_CONTROLLER_NOT_FOUND`, `CONTROLLER_COMPONENT_UNKNOWN`, `CONTROLLER_LAYOUT_CONFLICT`. 정확한 코드는 실패한 단계에 따라 달라질 수 있습니다. 횟수 제한 없는 재시도 루프에서 초기화를 반복하지 마세요.
