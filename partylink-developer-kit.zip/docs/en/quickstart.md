# Create with AI

## 1. Describe the game

Tell your AI coding assistant the idea, player count, round length, and what players do on their phones. For example: "Make a drawing-and-guessing game for 3 to 8 people, with short rounds and clear TV-readable scores."

## 2. Copy the AI instructions

Copy the [English creation prompt](../prompts/create.md) into your assistant and fill in your game details. The prompt links to the official [English Public API](api.md) and asks the assistant to read the latest reference before implementing.

## 3. Let AI build and package it

Ask your assistant to install the SDK, create the game and phone interactions, and deliver `release/game.zip`. Let the assistant handle installation, build settings, the manifest, and packaging using the API reference.

## 4. Try it together

Open PartyLink Library, load the ZIP, and launch the game on your PC or TV. Scan the joining QR code with phones. Test joining, controls, a complete round, and restarting; send your observations back to the assistant for another version.
