# Integrate with AI

## 1. Give AI the existing game

Open the game's project in your AI coding assistant. Explain how it plays today, which actions should move to phones, and how many people should play together. Describe what should stay on the shared PC or TV screen.

## 2. Copy the AI instructions

Copy the [English integration prompt](../prompts/integrate.md) into your assistant and fill in your game details. The prompt links to the official [English Public API](api.md) and asks the assistant to read the latest reference before implementing.

## 3. Let AI connect and package it

Ask the assistant to install the SDK, map existing actions to phone controls, handle players and game lifecycle, and deliver `release/game.zip`. The API reference covers the technical configuration and package requirements.

## 4. Test in Library

Load the ZIP in PartyLink Library and launch it on your PC or TV. Scan the joining QR code with phones. Play a full round, reconnect a phone, and try pause, resume, and restart. Give the assistant the results so it can refine the integration.
