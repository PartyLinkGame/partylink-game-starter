# Public API

SDK version: `@partylink/game-sdk@0.1.2`. Protocol version: `1`. This reference is self-contained: an AI can implement and package a game using the contract below.

## Install and initialize

```sh
npm install --save-exact @partylink/game-sdk@0.1.2
```

```ts
import {
  PartyLink, createAudioAPI, getVolumeSettings, subscribeVolumeSettings,
  bindMediaVolume, renderDrawPath, AUDIO_THEMES, SFX_KINDS,
} from '@partylink/game-sdk';
import type { PlatformClient, Player, DrawPath } from '@partylink/game-sdk';
```

`PartyLink` and the helpers above are runtime exports. `PlatformClient` and other interfaces are types. Obtain clients through `PartyLink.init`.

### PartyLink.init(options)

Connect a game launched from PartyLink Library, or a custom phone controller opened by PartyLink.

Parameters: for a game, `{ mode: 'iframe' | 'popup'; timeoutMs?: number; allowedHostOrigins?: readonly string[]; allowInsecureDevelopment?: boolean }`. The mode must match the launch context. `timeoutMs` defaults to 10000; `allowedHostOrigins` optionally limits accepted exact origins; `allowInsecureDevelopment` is an optional development setting and still requires a valid launch context. For a phone page, use only `{ mode: 'controller' }`.

Returns: `Promise<PlatformClient>` for a game; `Promise<CustomControllerClient>` for a phone. Rejects if the launch context is absent, invalid, or times out. A directly opened game page should display a helpful launch message.

```ts
const mode = new URLSearchParams(location.search).get('plMode');
if (mode !== 'iframe' && mode !== 'popup') {
  document.body.textContent = 'Launch this game from PartyLink Library.';
  throw new Error('Launch context required');
}
const pl = await PartyLink.init({ mode });
console.log(pl.state); // 'ready'
// In a custom controller page instead:
// const phone = await PartyLink.init({ mode: 'controller' });
```

On game initialization, the join overlay opens once when no player is connected, joining is allowed, and the overlay is available. It does not reopen automatically after every disconnect.

## Shared data and behavior

All `on` and subscription methods return an `Unsubscribe`, a function `() => void`. Call it to stop receiving callbacks. Subscriptions observe future changes; read an initial snapshot where offered. Catch asynchronous failures. `Promise<void>` resolves without a value when the requested operation finishes; this is not an acknowledgment that game logic on another device processed a business message. Calls on disposed clients can fail.

`playerId` always means `Player.id`; nicknames and array positions are not stable identifiers. Current sessions support up to 12 players. Player snapshots may include disconnected players.

```ts
const player: Player = {
  id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '',
  gender: 'none', state: 'connected', joinedAt: 1730000000000,
  controllerType: 'dpad-abxy', isPrimary: true, controlMode: 'game',
};
```

Player fields: required `id`, `sessionId`, `nickname` (1..64 characters), `avatar` (empty, JPEG data URL, or temporary blob URL), `gender` (`none`, `male`, `female`), `state` (`connecting`, `connected`, `disconnected`), and `joinedAt` (number). Optional `controllerType` is a built-in preset ID or `custom`; optional `isPrimary` is boolean; optional `controlMode` is `game`, `remote`, or `waiting`. Temporary avatar blob URLs should not be saved for later sessions.

`ConnectionOverlayState` has required booleans `available`, `visible`, `canJoin`, and optional strings `qrPayload`, `overlayUrl`. Join data is specific to the current session.

## Players and joining: pl.host

### pl.host.getPlayers()

Parameters: none. Returns `Player[]`, a copied local snapshot.

```ts
const players = pl.host.getPlayers();
// [{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '',
//    gender: 'none', state: 'connected', joinedAt: 1730000000000 }]
```

### pl.host.getPlayer(id)

Parameters: `id: string`. Returns a copied `Player`, or `undefined` if absent.

```ts
const player = pl.host.getPlayer('p1'); // Player or undefined
```

### pl.host.removePlayer(id?)

Disconnect and remove a player. Parameters: optional `id: string`; omitting it removes all players. Returns `Promise<void>`.

```ts
await pl.host.removePlayer('p1'); // undefined
```

### pl.host.getLobbyState()

Parameters: none. Returns `Promise<{ enabled: boolean; primaryPlayerId?: string }>`.

```ts
const lobby = await pl.host.getLobbyState();
// { enabled: true, primaryPlayerId: 'p1' }
```

### pl.host.setPrimaryPlayer(id)

Choose the primary player for lobby navigation. Parameters: `id: string`. Returns `Promise<void>`.

```ts
await pl.host.setPrimaryPlayer('p1'); // undefined
```

### pl.host.setLobbyMode(enabled)

Switch between lobby remote navigation (`true`) and game input (`false`). This does not start or pause game logic. Parameters: `enabled: boolean`. Returns `Promise<void>`.

```ts
await pl.host.setLobbyMode(false); // undefined
```

### pl.host.getConnectionOverlay()

Parameters: none. Returns `Promise<ConnectionOverlayState>`.

```ts
const overlay = await pl.host.getConnectionOverlay();
// { available: true, visible: false, canJoin: true, qrPayload: 'session-join-data' }
```

### pl.host.setConnectionOverlay(visible)

Show or hide the platform join interface. Parameters: `visible: boolean`. Returns `Promise<void>`. Showing it does not pause a running game.

```ts
await pl.host.setConnectionOverlay(true); // undefined
```

### pl.host.on(event, callback)

Parameters: one of the events below and a callback receiving its payload. Returns `Unsubscribe`.

```ts
const off = pl.host.on('player:join', async (player) => {
  await pl.app.setController('dpad-abxy', player.id);
});
off(); // undefined; stop this listener
```

Each player event receives the Player object directly, without a surrounding `player` property:

```ts
// 'player:join'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'connected', joinedAt: 1730000000000 }
// 'player:update'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'connected', joinedAt: 1730000000000, isPrimary: true }
// 'player:leave'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'disconnected', joinedAt: 1730000000000 }
// 'connection:overlay'
{ available: true, visible: true, canJoin: true, qrPayload: 'session-join-data' }
```

Configure existing players from `getPlayers()`, then configure new or returning players on join/update as appropriate to the current round. Clear held input when a player disconnects.

## Game settings: pl.game

### pl.game.getLocale()

Parameters: none. Returns the current locale string. Translate the game's own text using this value.

```ts
const locale = pl.game.getLocale(); // 'en-US'
```

### pl.game.getVolumeSettings()

Parameters: none. Returns `VolumeSettings`: `{ music: number; effects: number }`, each in 0..1.

```ts
const settings = pl.game.getVolumeSettings(); // { music: 0.5, effects: 0.5 }
```

### pl.game.subscribeVolumeSettings(callback)

Parameters: callback `(settings: VolumeSettings) => void`. Returns `Unsubscribe`; does not immediately emit the initial value.

```ts
const initial = pl.game.getVolumeSettings();
const off = pl.game.subscribeVolumeSettings((settings) => {
  console.log(settings.effects); // 0.7 after a matching change
});
```

### pl.game.requestClose()

Request that PartyLink close this game. Parameters: none. Returns `Promise<void>`.

```ts
await pl.game.requestClose(); // undefined
```

### pl.game.on(event, callback)

Parameters: `event: 'locale:change' | 'game:control'` and the corresponding payload callback. Returns `Unsubscribe`.

```ts
const off = pl.game.on('locale:change', ({ locale }) => {
  document.documentElement.lang = locale;
});
// 'locale:change' payload: { locale: 'en-US' }
// 'game:control' payload: { playerId: 'p1', action: 'pause' }
// Resume payload: { playerId: 'p1', action: 'resume' }
```

`game:control` requests pause/resume. Implement it in game simulation, timers, and audio; clear held input on pause.

### pl.game.audio

An `AudioAPI` instance playing in the computer game page. See every AudioAPI method below. It follows the platform effects channel and is cleaned up with the SDK client.

```ts
const played = pl.game.audio.confirm(); // true if a sound was created
```

## Phone controls and feedback: pl.app

### pl.app.setController(name, playerId?, layout?)

Configure a phone controller. Parameters: `name: string` (preset, composition, or manifest custom controller key), optional `playerId: string`, optional `layout: ControllerLayoutInput`. Returns `Promise<void>`. Omitted playerId targets current players only; configure later joiners separately. To pass a layout for everyone, pass `undefined` as the second argument.

```ts
await pl.app.setController('joystick-action', 'p1'); // undefined
await pl.app.setController('custom-buttons', undefined, {
  orientation: 'landscape',
  components: [{ type: 'custom-buttons', buttons: [
    { controlId: 'jump', label: 'Jump', gridX: 0, gridY: 0, spanX: 2 },
  ] }],
}); // undefined
```

### pl.app.setControllersEnabled(enabled, playerId?)

Enable or block game input without replacing layouts. Parameters: `enabled: boolean`, optional `playerId: string`. Returns `Promise<void>`. Omitted ID sets a persistent global gate, applies to later joiners/reconnections, and resets individual gates. A specified player's gate combines with the global gate: both must allow input. Disabled custom controllers cannot send business messages. Reset local held state when disabling input.

```ts
await pl.app.setControllersEnabled(false); // undefined; pause all input
await pl.app.setControllersEnabled(true); // undefined; allow all input again
await pl.app.setControllersEnabled(false, 'p1'); // undefined; block this player
```

### pl.app.showToast(options, playerId?)

Display a plain text phone toast, replacing the currently displayed toast. Parameters: `{ text: string; type?: 'text' | 'success' | 'error'; position?: 'top' | 'center' | 'bottom'; duration?: number }`, optional target ID. Returns `Promise<void>`. Omitted ID targets current players. Trimmed text: 1..200 UTF-16 characters; duration: integer 1000..10000 milliseconds. Defaults: `text`, `center`, 3000. Use game UI for rich content or dialogs.

```ts
await pl.app.showToast({ text: 'Your turn!', type: 'success', duration: 2000 }, 'p1');
// undefined
```

### pl.app.sendMessage(payload, playerId?)

Send business data to custom phone pages. Parameters: JSON-serializable `payload: unknown`, optional player ID. Returns `Promise<void>`. Omitted ID targets current players. Use your own response message when business acknowledgment is needed.

```ts
await pl.app.sendMessage({ type: 'round', roundId: 'r1', score: 3 }, 'p1');
// undefined; phone.game.on('message') receives that payload directly
```

### pl.app.audio.play(kind, playerId?, options?)

Play a phone sound. Parameters: `kind: SfxKind`, optional ID, optional `{ theme?: AudioTheme }` in the third position. Returns `Promise<AudioPlaybackResult[]>`, including an array for one player. Omitted ID targets current players. Inspect playback results because browser audio may remain locked.

```ts
const results = await pl.app.audio.play('success', 'p1', { theme: 'arcade' });
// [{ playerId: 'p1', played: true, state: 'running' }]
// A failure might be [{ playerId: 'p1', played: false, state: 'suspended',
//   reason: 'AUDIO_USER_GESTURE_REQUIRED' }]
```

Result fields: `playerId: string`, `played: boolean`, `state: AudioState`, optional `reason: string`. AudioState is `idle`, `running`, `suspended`, `closed`, `error`, or `unsupported`.

### pl.app.on(event, callback)

Parameters: `input`, `remote:action`, `message`, `selector:submit`, `draw:path`, or `draw:frame`, and a matching payload callback. Returns `Unsubscribe`. Every payload includes the sender's `playerId`.

```ts
const off = pl.app.on('input', (input) => {
  if (input.type === 'button' && input.action === 'click' && !input.synthetic) {
    console.log(input.playerId, input.controlId); // 'p1', 'a'
  }
});
```

Input payload examples:

```ts
// Button: type 'button', action 'down' | 'up' | 'click'
{ protocolVersion: 1, sessionId: 's1', playerId: 'p1', sequence: 1,
  timestamp: 1730000000000, controlId: 'a', synthetic: false,
  type: 'button', action: 'down' }
// Axis: x and y in -1..1
{ protocolVersion: 1, sessionId: 's1', playerId: 'p1', sequence: 2,
  timestamp: 1730000000001, controlId: 'left_stick', synthetic: false,
  type: 'axis', x: 0.5, y: -0.2 }
```

Common fields: `protocolVersion: 1`; string `sessionId`, `playerId`; nonnegative safe-integer `sequence`; nonnegative integer `timestamp`; `controlId` of 1..64 letters, digits, underscores, or hyphens; boolean `synthetic`. A tap can produce down/up/click: choose one phase for one-shot scoring. Track down/up for held actions. Synthetic events restore safe input state; process releases and neutral axes, but do not score them as fresh player actions.

Other event payload examples:

```ts
// 'remote:action': action is up/down/left/right/confirm/cancel/back
{ playerId: 'p1', action: 'confirm' }
// 'message': custom phone data; validate shape, ranges, round, and frequency
{ playerId: 'p1', payload: { type: 'jump', roundId: 'r1' } }
// 'selector:submit'
{ playerId: 'p1', controlId: 'vote', requestId: 'r1', values: ['cat'] }
// 'draw:path'
{ playerId: 'p1', kind: 'path', action: 'move', controlId: 'sketch',
  requestId: 'r1', width: 1024, height: 768, backgroundColor: '#FFFFFF',
  strokeId: 'stroke-1', tool: 'pen', color: '#111111', strokeWidth: 0.01,
  points: [{ x: 0.2, y: 0.3 }, { x: 0.25, y: 0.35 }] }
// 'draw:frame': dataUrl contains a complete reassembled WebP image
{ playerId: 'p1', kind: 'frame', action: 'submit', controlId: 'sketch',
  requestId: 'r1', width: 1024, height: 768, backgroundColor: '#FFFFFF',
  frameId: 'frame-1', dataUrl: 'data:image/webp;base64,UklGR...' }
```

The shortened data URL above illustrates the field, not a usable image. Validate requestId against the current round and ignore duplicate submissions.

## Controller names and layout fields

Built-in presets: `dpad-abxy`, `joystick-action`, `custom-buttons`, `multi-row-buttons`, `remote`, `selector`, `draw`. Components can also compose by name in order: `joystick+dual-buttons`, for example. Available component names: `joystick`, `dual-buttons`, `quad-buttons`, `dpad`, `menu-keys`, `custom-buttons`, `multi-row-buttons`, `selector`, `draw`.

`ControllerLayoutInput` has optional `orientation: 'auto' | 'portrait' | 'landscape'` and required `components` (1..4). Types must match the composition name and order. Default orientation is `auto`, except a lone selector defaults to `portrait`. Control IDs must be unique across the layout. Draw works alone. Remote uses a fixed landscape dpad + menu-keys layout.

- Joystick: `{ type: 'joystick', controlId?: string, deadZone?: number }`; defaults `left_stick`, 0.12; deadZone 0..0.9.
- Dual buttons: `{ type: 'dual-buttons' }`; IDs `a`, `b`.
- Quad buttons: `{ type: 'quad-buttons' }`; IDs `a`, `b`, `x`, `y`.
- Dpad: `{ type: 'dpad' }`; IDs `up`, `down`, `left`, `right`.
- Menu keys: `{ type: 'menu-keys' }`; IDs `menu_back`, `menu_cancel`, `menu_confirm`.
- Custom buttons: `{ type: 'custom-buttons', buttons: ButtonDefinition[] }`, 1..12 buttons. Each has `controlId`, `label`, integer `gridX/gridY` 0..3, optional integer `spanX/spanY` 1..2 (default 1), optional `backgroundColor/textColor`. Buttons occupy a 4 by 4 grid, without overlaps or overflow.
- Multi-row buttons: `{ type: 'multi-row-buttons', buttons: [{ code, label, backgroundColor?, textColor? }] }`, 1..4 buttons. `code` is the control ID.

IDs: 1..64 letters, digits, underscores, hyphens. Button labels: 1..16 characters. Button colors: `#RGB` or `#RRGGBB`. Pass explicit layouts for custom button presets to choose meaningful IDs.

### Selector configuration

```ts
await pl.app.setController('selector', 'p1', {
  components: [{ type: 'selector', controlId: 'vote', requestId: 'r1',
    title: 'Choose an animal', mode: 'single',
    options: [{ id: 'cat', label: 'Cat' }, { id: 'dog', label: 'Dog' }],
  }],
}); // undefined
```

Fields: `type: 'selector'`; optional `controlId` (default `selector`); optional `requestId` (1..128 characters, default random UUID; use a round-specific value); optional `title` (maximum 120, default empty); optional `mode` (`single` default, or `multiple`); required `options` (1..100 unique IDs). Option ID follows the control ID format; label is 1..120 characters. Optional `submittedValues: string[]` restores a submitted choice: nonempty, unique option IDs; one for single mode, up to 100 for multiple. Submissions arrive through `selector:submit`.

### Draw configuration

```ts
await pl.app.setController('draw', 'p1', {
  components: [{ type: 'draw', controlId: 'sketch', requestId: 'r1',
    title: 'Draw a cat', width: 1024, height: 768,
    backgroundColor: '#FFFFFF', output: 'path', fps: 5, showSubmit: true,
  }],
}); // undefined
```

Optional fields and defaults: `controlId: 'draw'`; `requestId`: random UUID, 1..128 characters; `title`: at most 120; `width: 1024`, `height: 768`, each integer 64..2048; `backgroundColor: '#FFFFFF'` (six-digit hex); `output: 'path'` or `frame`; `fps: 5` (1..10); `showSubmit: true`; `initialImage`: WebP base64 data URL, maximum 48000 characters. Arbitrary image URLs are not accepted.

`DrawPath`: `kind: 'path'`; action `start`, `move`, `end`, `clear`, or `submit`; canvas fields `controlId`, `requestId`, `width`, `height`, `backgroundColor`; `strokeId` (1..128 characters); `tool: 'pen' | 'eraser'`; six-digit hex `color`; `strokeWidth` 0.0001..1 relative to canvas size; `points: { x: number; y: number }[]` of up to 64 normalized 0..1 points. The event adds `playerId`.

`DrawFrame` includes those canvas fields, `playerId`, `kind: 'frame'`, action `frame`, `submit`, or `clear`, string `frameId`, and complete WebP `dataUrl`. Frames are reassembled before the event. Maximum image string length: 524288 characters; up to 32 chunks of 16384 characters, completed within 5 seconds. Choose a modest frame rate.

The exported `DrawPacket` type describes a path or a frame chunk; frame chunks have `index`, `length`, and `data` instead of `dataUrl`. Normal game listeners use the assembled `DrawFrame`.

### renderDrawPath(context, path)

Render normalized drawing operations into your Canvas. Parameters: `CanvasRenderingContext2D`, `DrawPath`. Returns `void`. Match canvas dimensions to the draw configuration; use a separate canvas per player and handle submit in game logic.

```ts
const canvases = new Map<string, HTMLCanvasElement>();
pl.app.on('draw:path', (path) => {
  let canvas = canvases.get(path.playerId);
  if (!canvas) {
    canvas = document.createElement('canvas');
    canvas.width = path.width; canvas.height = path.height;
    canvases.set(path.playerId, canvas);
    document.body.append(canvas);
  }
  renderDrawPath(canvas.getContext('2d')!, path); // undefined
});
```

## AudioAPI

`pl.game.audio`, `phone.app.audio`, and `createAudioAPI()` share these methods. Themes: `default`, `retro8bit`, `arcade`, `glass`, `cyber`. Kinds: `click`, `focus`, `back`, `confirm`, `cancel`, `success`, `error`, `unlock`, `coin`, `notify`, `join`, `leave`, `countdown`. `AUDIO_THEMES` and `SFX_KINDS` export readonly arrays of these strings.

Browsers may require a trusted local gesture before sound plays. A phone gesture does not unlock the computer page. Offer a computer-side sound button if necessary. Examples below use `const audio = pl.game.audio`.

### audio.play(kind, options?)

Parameters: `kind: SfxKind`, optional `{ theme?: AudioTheme }` overriding the current theme for this sound. Returns boolean: whether a sound was created, not proof it was audible. False can mean muted, suspended, disposed, unsupported, invalid sound, or voice capacity reached. Inspect state/error where useful.

```ts
const played = audio.play('coin', { theme: 'retro8bit' }); // true or false
```

### audio.click()

Play the `click` sound with the current theme. Parameters: none. Returns boolean, with the same meaning as `play`.

```ts
const played = audio.click(); // true or false
```

### audio.focus()

Play the `focus` sound with the current theme. Parameters: none. Returns boolean, with the same meaning as `play`.

```ts
const played = audio.focus(); // true or false
```

### audio.back()

Play the `back` sound with the current theme. Parameters: none. Returns boolean, with the same meaning as `play`.

```ts
const played = audio.back(); // true or false
```

### audio.confirm()

Play the `confirm` sound with the current theme. Parameters: none. Returns boolean, with the same meaning as `play`.

```ts
const played = audio.confirm(); // true or false
```

### audio.cancel()

Play the `cancel` sound with the current theme. Parameters: none. Returns boolean, with the same meaning as `play`.

```ts
const played = audio.cancel(); // true or false
```

### audio.success()

Play the `success` sound with the current theme. Parameters: none. Returns boolean, with the same meaning as `play`.

```ts
const played = audio.success(); // true or false
```

### audio.error()

Play the `error` sound with the current theme. Parameters: none. Returns boolean, with the same meaning as `play`.

```ts
const played = audio.error(); // true or false
```

### audio.unlock()

Play the `unlock` sound with the current theme. Parameters: none. Returns boolean, with the same meaning as `play`.

```ts
const played = audio.unlock(); // true or false
```

### audio.coin()

Play the `coin` sound with the current theme. Parameters: none. Returns boolean, with the same meaning as `play`.

```ts
const played = audio.coin(); // true or false
```

### audio.notify()

Play the `notify` sound with the current theme. Parameters: none. Returns boolean, with the same meaning as `play`.

```ts
const played = audio.notify(); // true or false
```

### audio.join()

Play the `join` sound with the current theme. Parameters: none. Returns boolean, with the same meaning as `play`.

```ts
const played = audio.join(); // true or false
```

### audio.leave()

Play the `leave` sound with the current theme. Parameters: none. Returns boolean, with the same meaning as `play`.

```ts
const played = audio.leave(); // true or false
```

### audio.countdown()

Play the `countdown` sound with the current theme. Parameters: none. Returns boolean, with the same meaning as `play`.

```ts
const played = audio.countdown(); // true or false
```

### audio.resume()

Initialize/resume audio. Parameters: none. Returns `Promise<void>`; may reject if a local user gesture is required or audio is unavailable. `unlock()` is a sound shortcut, not this resume operation.

```ts
soundButton.addEventListener('click', async () => {
  try { await audio.resume(); audio.confirm(); }
  catch (error) { console.error(error); }
}); // resume resolves to undefined
```

### audio.isSupported()

Parameters: none. Returns boolean indicating AudioContext availability.

```ts
const supported = audio.isSupported(); // true or false
```

### audio.getState()

Parameters: none. Returns `AudioState`: idle/running/suspended/closed/error/unsupported.

```ts
const state = audio.getState(); // 'running'
```

### audio.getLastError()

Parameters: none. Returns `string | undefined`, the latest recorded playback/resume error.

```ts
const error = audio.getLastError(); // undefined or 'AUDIO_USER_GESTURE_REQUIRED'
```

### audio.setTheme(theme)

Parameters: `theme: AudioTheme`. Returns `void`. Sets the default theme for future sounds.

```ts
audio.setTheme('glass'); // undefined
```

### audio.getTheme()

Parameters: none. Returns `AudioTheme`; initially `default`.

```ts
const theme = audio.getTheme(); // 'glass'
```

### audio.setVolume(volume)

Parameters: local mix `volume: number`, clamped to 0..1. Returns `void`. Combined with the platform effects channel when enabled.

```ts
audio.setVolume(0.8); // undefined
```

### audio.getVolume()

Parameters: none. Returns the local mix volume (initially 1), rather than the combined platform level.

```ts
const volume = audio.getVolume(); // 0.8
```

### audio.mute()

Parameters: none. Returns `void`. Mutes and stops active voices.

```ts
audio.mute(); // undefined
```

### audio.unmute()

Parameters: none. Returns `void`. Restores the local mix for future sounds.

```ts
audio.unmute(); // undefined
```

### audio.isMuted()

Parameters: none. Returns boolean for the local mute flag.

```ts
const muted = audio.isMuted(); // false
```

### audio.dispose()

Parameters: none. Returns `void`. Idempotently releases voices, subscriptions, and the audio context. SDK-owned audio is released with its client; release separately created instances yourself.

```ts
audio.dispose(); // undefined
audio.getState(); // 'closed'
```

### createAudioAPI(options?)

Create an independent AudioAPI. Parameters: optional `{ AudioContextImpl?: typeof AudioContext; autoUnlock?: boolean; followPlatformVolume?: boolean }`. Defaults: browser AudioContext, automatic trusted-gesture unlock, and follow the current page's effects setting. Returns `AudioAPI`.

```ts
const extraAudio = createAudioAPI({ autoUnlock: true, followPlatformVolume: true });
extraAudio.getTheme(); // 'default'
extraAudio.dispose();
```

### getVolumeSettings()

Top-level equivalent of `pl.game.getVolumeSettings()`. Parameters: none. Returns a copied `VolumeSettings` for the current page.

```ts
const settings = getVolumeSettings(); // { music: 0.5, effects: 0.5 }
```

### subscribeVolumeSettings(callback)

Top-level equivalent of the game subscription. Parameters: `(settings: VolumeSettings) => void`. Returns `Unsubscribe`; read the initial value separately.

```ts
const off = subscribeVolumeSettings((settings) => console.log(settings.music));
// A later callback might receive { music: 0.7, effects: 0.5 }
off(); // undefined
```

### bindMediaVolume(media, channel)

Bind an existing media mix level to platform music/effects volume. Parameters: `media: { volume: number }` (typically HTMLAudioElement), `channel: 'music' | 'effects'`. Returns `Unsubscribe`, restoring the original media volume behavior. Effective playback volume is the base mix multiplied by the chosen channel; writing `media.volume` while bound updates that base mix.

```ts
const music = new Audio('./assets/music.ogg');
music.volume = 0.8;
const off = bindMediaVolume(music, 'music');
// At platform music 0.5, effective playback volume is 0.4.
pl.onDispose(() => { off(); music.pause(); });
```

For your own WebAudio graph, read and subscribe to settings and update a GainNode from a fixed base level, rather than repeatedly multiplying its last value.

## Custom phone pages

Declare `customControllers: { steering: 'controllers/steering.html' }` in the manifest and activate it with `pl.app.setController('steering', 'p1')` without a layout. Keys: 1..64 letters, digits, underscores, hyphens; distinct from built-in preset/component names (including `custom`). Include the controller HTML as a build entry and package its assets.

```ts
const phone = await PartyLink.init({ mode: 'controller' });
```

These pages receive their own controller client. `phone.state` is `ready` or `disposed`.

### phone.app.isEnabled()

Parameters: none. Returns boolean indicating whether input is currently allowed. Check before sending and reset custom held state when disabled or hidden.

```ts
if (phone.app.isEnabled()) await phone.game.sendMessage({ type: 'jump' });
// true allows sending; false means input is blocked
```

### phone.app.requestOrientation(orientation)

Parameters: `orientation: 'auto' | 'portrait' | 'landscape'`. Returns `void`. Requests display orientation; physical OS orientation locking is not guaranteed.

```ts
phone.app.requestOrientation('landscape'); // undefined
```

### phone.app.audio

Local AudioAPI with all methods listed above. This controller page has independent volume state; its local audio and volume helpers do not automatically receive platform volume changes. For phone feedback that follows platform volume, send a business message and let the game call `pl.app.audio.play`.

```ts
phone.app.audio.getState(); // 'idle', for example
```

### phone.game.sendMessage(payload)

Parameters: JSON-serializable `payload: unknown`, without a playerId wrapper. Returns `Promise<void>` when the phone accepts the send; not a game business acknowledgment. Times out after 5 seconds. Rejects with `INPUT_BLOCKED` while disabled. The game receives the authenticated sender ID alongside the payload.

```ts
await phone.game.sendMessage({ type: 'jump', roundId: 'r1' }); // undefined
// Game 'message' payload: { playerId: 'p1', payload: { type: 'jump', roundId: 'r1' } }
```

### phone.game.on('message', callback)

Parameters: literal `message` and callback `(payload: unknown) => void`. Returns `Unsubscribe`. Receives the game payload directly.

```ts
const off = phone.game.on('message', (payload) => console.log(payload));
// Example callback payload: { type: 'round', roundId: 'r1', score: 3 }
off(); // undefined
```

### phone.dispose()

Parameters: none. Returns `void`. Idempotently releases the controller client and its audio; pending sends reject. The client also disposes on pagehide. Clean up your own DOM listeners, timers, and animations.

```ts
phone.dispose(); // undefined
console.log(phone.state); // 'disposed'
```

## Game lifecycle

### pl.state

Readonly property, `ready` or `disposed`.

```ts
console.log(pl.state); // 'ready'
```

### pl.on('close', callback)

Parameters: literal `close` and callback `(payload: { code: string }) => void`. Returns `Unsubscribe`.

```ts
const off = pl.on('close', ({ code }) => console.log(code));
// Example callback payload: { code: 'HOST_CLOSED' }
```

### pl.onDispose(callback)

Parameters: `callback: () => void`. Returns `Unsubscribe`. Invoked on disposal, or immediately if already disposed. Use for your game resources.

```ts
const timer = window.setInterval(() => {}, 1000);
const off = pl.onDispose(() => window.clearInterval(timer));
// Callback receives no arguments; off() returns undefined.
```

### pl.dispose()

Parameters: none. Returns `void`. Idempotently releases the SDK client. Clean up your RAF loops, event handlers, timers, subscriptions, and media as well.

```ts
pl.dispose(); // undefined
console.log(pl.state); // 'disposed'
```

## Build and ZIP contract

Use Vite `base: './'` and `build: { target: 'es2022' }` to support relative packaged assets and top-level await. Include scripts, styles, fonts, images, and audio in the package with relative paths. Packaged games must work without runtime CDNs or server-only routing. Provide an `npm run package` script that builds and produces `release/game.zip`; the bundle starter already supplies this workflow.

The ZIP root must directly contain `manifest.json`, the entry HTML, and the referenced cover/assets. Zip the contents of the output folder rather than its containing folder.

```json
{
  "schemaVersion": 1,
  "id": "living-room-quiz",
  "name": "Living Room Quiz",
  "version": "1.0.0",
  "description": "A quick quiz for friends and family using phone controls.",
  "players": { "min": 2, "max": 8 },
  "categories": ["party", "trivia"],
  "entry": "index.html",
  "cover": "cover.png",
  "sdkProtocolVersion": 1,
  "launch": { "mode": "iframe" }
}
```

Required fields: exactly those shown. `id` matches `[a-z0-9][a-z0-9-]{0,63}`; name 1..100 characters; description 1..500; version three numeric parts; players min/max integers 1..1000 with min <= max (actual simultaneous connections are still capped at 12); categories 1..5 unique values. Category values: party, puzzle, action, arcade, strategy, sports, racing, trivia, music, casual, developer-tools. Entry must be package-local HTML. Cover must be an actual webp/png/jpg/jpeg/gif image. Launch mode: iframe or popup.

Optional `locales` maps BCP47 tags to `{ name?: string; description?: string }`; use English defaults. Lookup falls back from exact locale to base language to defaults, per field. Optional `customControllers` maps keys to HTML paths as described above. Extra manifest fields are rejected. Use a new version for published updates. During local development, importing a ZIP with the same game ID replaces the local copy, including when its version is unchanged.

Resource paths are relative to the ZIP root, case-sensitive, without absolute paths, URLs, empty segments, `.`/`..` segments, backslashes, `%`, `?`, `#`, `:`, or control characters. ZIP limits: 50 MiB compressed, 200 MiB expanded, 50 MiB per file, 2000 entries, 240 characters per path, compression ratio at most 100:1. Use an ordinary unencrypted ZIP containing regular files with distinct paths and valid CRCs.

## Payload limits and failures

Ordinary business messages have a 4096 UTF-8 byte limit for the complete message including protocol fields: keep payloads comfortably smaller. Use JSON-compatible data; functions, DOM nodes, circular objects, and BigInt cannot be sent. Controller configurations and selector submissions have a 65536-byte limit; drawing uses its dedicated limits. Use the drawing feature for drawing images rather than sending large images in business messages.

Catch failures and present a retry or launch instruction as appropriate. Typical codes: `HOST_NOT_FOUND` or launch-context errors; `HOST_BRIDGE_TIMEOUT`, `APP_BRIDGE_TIMEOUT`; `GAME_DISPOSED`, `CONTROLLER_DISPOSED`; `MESSAGE_TIMEOUT`, `MESSAGE_TOO_LARGE`; `INPUT_BLOCKED`; `CUSTOM_CONTROLLER_NOT_FOUND`, `CONTROLLER_COMPONENT_UNKNOWN`, `CONTROLLER_LAYOUT_CONFLICT`. Exact codes can depend on the failed step. Avoid repeatedly initializing in an unbounded retry loop.
