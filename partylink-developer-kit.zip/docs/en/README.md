# Intro

PartyLink is for easy multiplayer games with family and friends: a quick quiz after dinner, a drawing challenge at a party, or a playful race in the living room. The shared game runs on a PC or TV screen; players join by scanning a QR code and use their phones as controllers.

You bring the idea or an existing browser game. Your AI coding assistant builds the game, connects phone controls, and delivers a ZIP you can try in PartyLink Library. You do not need to write SDK integration code yourself.

- [Create with AI](quickstart.md): turn a game idea into a playable package.
- [Integrate with AI](integration.md): bring an existing game to PartyLink.
- [Public API](api.md): the complete SDK and package reference for your AI assistant.

The workflow is simple: describe the experience, copy the English AI instructions with the official API link, let your assistant deliver `release/game.zip`, then load it in Library and play together. Give your assistant feedback from real phone play to improve the next version.
