# 公開APIとプラットフォームの機能

SDK：`@partylink/game-sdk@0.1.2`、プロトコル：`1`。このページだけで仕様を確認でき、AI によるゲーム実装とパッケージ化にも利用できます。

## インストールと初期化

```sh
npm install --save-exact @partylink/game-sdk@0.1.2
```

```ts
import {
  PartyLink, createAudioAPI, getVolumeSettings, subscribeVolumeSettings,
  bindMediaVolume, renderDrawPath, AUDIO_THEMES, SFX_KINDS,
} from '@partylink/game-sdk';
import type { PlatformClient, Player, DrawPath } from '@partylink/game-sdk';
```

`PartyLink` と上記のヘルパーは実行時のエクスポートです。`PlatformClient` などのインターフェースは型です。クライアントは `PartyLink.init` で取得します。

### PartyLink.init(options)

PartyLink Library から起動されたゲーム、または PartyLink が開いたカスタムスマートフォンコントローラーに接続します。

引数：ゲームでは `{ mode: 'iframe' | 'popup'; timeoutMs?: number; allowedHostOrigins?: readonly string[]; allowInsecureDevelopment?: boolean }`。mode は実際の起動方式に合わせます。`timeoutMs` の既定値は 10000 ミリ秒。`allowedHostOrigins` は許可する正確な origin の指定、`allowInsecureDevelopment` は開発用の任意設定です。どちらの場合も有効な起動環境が必要です。スマホページには `{ mode: 'controller' }` のみを渡します。

戻り値：ゲームは `Promise<PlatformClient>`、スマホは `Promise<CustomControllerClient>`。起動環境の欠如、不正、タイムアウトで reject されます。ゲームを直接開いた場合は、Library から起動するよう案内してください。

```ts
const mode = new URLSearchParams(location.search).get('plMode');
if (mode !== 'iframe' && mode !== 'popup') {
  document.body.textContent = 'Launch this game from PartyLink Library.';
  throw new Error('Launch context required');
}
const pl = await PartyLink.init({ mode });
console.log(pl.state); // 'ready'
// In a custom controller page instead:
// const phone = await PartyLink.init({ mode: 'controller' });
```

ゲーム初期化時、接続中のプレイヤーがおらず、参加が許可され、参加画面が利用可能なら、その画面が一度開きます。その後の切断ごとに自動で開く動作はありません。

## 共通データと動作

すべての `on` と購読メソッドは `Unsubscribe`、つまり `() => void` を返します。呼び出すと購読を解除します。購読は以後の変更を受信するため、取得メソッドがあれば初期値を先に読みます。非同期処理の失敗を処理してください。`Promise<void>` は要求した操作の完了を表し、値を返しません。他の端末のゲーム処理が業務メッセージを処理したという確認ではありません。破棄済みクライアントの呼び出しは失敗することがあります。

`playerId` は常に `Player.id` です。ニックネームや配列の位置は固定の識別子として使えません。現在は 1 セッション最大 12 人で、スナップショットには切断済みの人も含まれます。

```ts
const player: Player = {
  id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '',
  gender: 'none', state: 'connected', joinedAt: 1730000000000,
  controllerType: 'dpad-abxy', isPrimary: true, controlMode: 'game',
};
```

Player の必須フィールドは `id`、`sessionId`、`nickname`（1..64 文字）、`avatar`（空文字、JPEG data URL、または一時的な blob URL）、`gender`（`none`、`male`、`female`）、`state`（`connecting`、`connected`、`disconnected`）、`joinedAt`（number）です。任意の `controllerType` は組み込み preset ID または `custom`、`isPrimary` は boolean、`controlMode` は `game`、`remote`、`waiting`。アバターの一時 blob URL は後のセッション用には保存できません。

`ConnectionOverlayState` は必須の boolean `available`、`visible`、`canJoin` と、任意の string `qrPayload`、`overlayUrl` を持ちます。参加データは現在のセッション専用です。

## プレイヤーと参加：pl.host

### pl.host.getPlayers()

引数なし。ローカルスナップショットのコピー `Player[]` を返します。

```ts
const players = pl.host.getPlayers();
// [{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '',
//    gender: 'none', state: 'connected', joinedAt: 1730000000000 }]
```

### pl.host.getPlayer(id)

引数：`id: string`。`Player` のコピーを返し、該当なしなら `undefined` です。

```ts
const player = pl.host.getPlayer('p1'); // Player or undefined
```

### pl.host.removePlayer(id?)

プレイヤーを切断して削除します。引数：任意の `id: string`。省略すると全員を削除します。戻り値：`Promise<void>`。

```ts
await pl.host.removePlayer('p1'); // undefined
```

### pl.host.getLobbyState()

引数なし。戻り値：`Promise<{ enabled: boolean; primaryPlayerId?: string }>`。

```ts
const lobby = await pl.host.getLobbyState();
// { enabled: true, primaryPlayerId: 'p1' }
```

### pl.host.setPrimaryPlayer(id)

ロビーを操作する代表プレイヤーを指定します。引数：`id: string`。戻り値：`Promise<void>`。

```ts
await pl.host.setPrimaryPlayer('p1'); // undefined
```

### pl.host.setLobbyMode(enabled)

ロビーのリモコン操作（`true`）とゲーム入力（`false`）を切り替えます。ゲーム処理の開始や一時停止は行いません。引数：`enabled: boolean`。戻り値：`Promise<void>`。

```ts
await pl.host.setLobbyMode(false); // undefined
```

### pl.host.getConnectionOverlay()

引数なし。戻り値：`Promise<ConnectionOverlayState>`。

```ts
const overlay = await pl.host.getConnectionOverlay();
// { available: true, visible: false, canJoin: true, qrPayload: 'session-join-data' }
```

### pl.host.setConnectionOverlay(visible)

プラットフォームの参加画面を表示・非表示にします。引数：`visible: boolean`。戻り値：`Promise<void>`。表示中も実行中のゲームは停止しません。

```ts
await pl.host.setConnectionOverlay(true); // undefined
```

### pl.host.on(event, callback)

引数：下記のイベント名と、その payload を受け取るコールバック。戻り値：`Unsubscribe`。

```ts
const off = pl.host.on('player:join', async (player) => {
  await pl.app.setController('dpad-abxy', player.id);
});
off(); // undefined; stop this listener
```

プレイヤーイベントには Player オブジェクトが直接渡され、外側に `player` プロパティはありません。

```ts
// 'player:join'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'connected', joinedAt: 1730000000000 }
// 'player:update'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'connected', joinedAt: 1730000000000, isPrimary: true }
// 'player:leave'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'disconnected', joinedAt: 1730000000000 }
// 'connection:overlay'
{ available: true, visible: true, canJoin: true, qrPayload: 'session-join-data' }
```

`getPlayers()` で既存のプレイヤーを設定し、参加・更新イベントで新規参加や再接続の人を現在のラウンドに合わせて設定します。切断時には長押しなどの継続入力を解除してください。

## ゲーム設定：pl.game

### pl.game.getLocale()

引数なし。現在のロケール文字列を返します。ゲーム自身の文言切り替えに使用できます。

```ts
const locale = pl.game.getLocale(); // 'en-US'
```

### pl.game.getVolumeSettings()

引数なし。`VolumeSettings`：`{ music: number; effects: number }` を返します。各値は 0..1 です。

```ts
const settings = pl.game.getVolumeSettings(); // { music: 0.5, effects: 0.5 }
```

### pl.game.subscribeVolumeSettings(callback)

引数：コールバック `(settings: VolumeSettings) => void`。戻り値：`Unsubscribe`。購読直後には初期値を通知しません。

```ts
const initial = pl.game.getVolumeSettings();
const off = pl.game.subscribeVolumeSettings((settings) => {
  console.log(settings.effects); // 0.7 after a matching change
});
```

### pl.game.requestClose()

PartyLink に現在のゲームを閉じるよう要求します。引数なし。戻り値：`Promise<void>`。

```ts
await pl.game.requestClose(); // undefined
```

### pl.game.on(event, callback)

引数：`event: 'locale:change' | 'game:control'` と、対応する payload のコールバック。戻り値：`Unsubscribe`。

```ts
const off = pl.game.on('locale:change', ({ locale }) => {
  document.documentElement.lang = locale;
});
// 'locale:change' payload: { locale: 'en-US' }
// 'game:control' payload: { playerId: 'p1', action: 'pause' }
// Resume payload: { playerId: 'p1', action: 'resume' }
```

`game:control` は一時停止・再開の要求です。ゲームのシミュレーション、タイマー、音声に反映し、一時停止時に継続入力を解除します。

### pl.game.audio

パソコンのゲームページで再生する `AudioAPI` インスタンスです。全メソッドは後述します。プラットフォームの effects 音量に従い、SDK クライアントと一緒に破棄されます。

```ts
const played = pl.game.audio.confirm(); // true if a sound was created
```

## スマホ操作とフィードバック：pl.app

### pl.app.setController(name, playerId?, layout?)

スマホのコントローラーを設定します。引数：`name: string`（preset、コンポーネントの組み合わせ、manifest のカスタムコントローラー key）、任意の `playerId: string` と `layout: ControllerLayoutInput`。戻り値：`Promise<void>`。playerId を省略すると現在のプレイヤーが対象で、後からの参加者は別途設定します。全員に layout を渡す場合、第 2 引数を `undefined` にします。

```ts
await pl.app.setController('joystick-action', 'p1'); // undefined
await pl.app.setController('custom-buttons', undefined, {
  orientation: 'landscape',
  components: [{ type: 'custom-buttons', buttons: [
    { controlId: 'jump', label: 'Jump', gridX: 0, gridY: 0, spanX: 2 },
  ] }],
}); // undefined
```

### pl.app.setControllersEnabled(enabled, playerId?)

レイアウトを変えずにゲーム入力を許可・停止します。引数：`enabled: boolean`、任意の `playerId: string`。戻り値：`Promise<void>`。ID 省略時は継続的な全体設定となり、新規参加や再接続にも適用され、個人設定をリセットします。個人を指定した場合、その設定と全体設定の両方が許可した場合のみ入力できます。無効なカスタムコントローラーからは業務メッセージも送れません。無効にするときはローカルの継続入力も解除します。

```ts
await pl.app.setControllersEnabled(false); // undefined; pause all input
await pl.app.setControllersEnabled(true); // undefined; allow all input again
await pl.app.setControllersEnabled(false, 'p1'); // undefined; block this player
```

### pl.app.showToast(options, playerId?)

スマホにプレーンテキストの通知を表示し、現在の通知を置き換えます。引数：`{ text: string; type?: 'text' | 'success' | 'error'; position?: 'top' | 'center' | 'bottom'; duration?: number }`、任意のプレイヤー ID。戻り値：`Promise<void>`。ID 省略時は現在のプレイヤーが対象。前後の空白を除いた text は 1..200 UTF-16 文字、duration は 1000..10000 ミリ秒の整数。既定値は `text`、`center`、3000。装飾された内容やダイアログはゲーム画面で実装できます。

```ts
await pl.app.showToast({ text: 'Your turn!', type: 'success', duration: 2000 }, 'p1');
// undefined
```

### pl.app.sendMessage(payload, playerId?)

カスタムスマホページへ業務データを送ります。引数：JSON 化できる `payload: unknown`、任意のプレイヤー ID。戻り値：`Promise<void>`。ID 省略時は現在のプレイヤーが対象。業務処理の完了確認が必要なら応答メッセージを設計します。

```ts
await pl.app.sendMessage({ type: 'round', roundId: 'r1', score: 3 }, 'p1');
// undefined; phone.game.on('message') receives that payload directly
```

### pl.app.audio.play(kind, playerId?, options?)

スマホで効果音を再生します。引数：`kind: SfxKind`、任意の ID、第 3 引数に任意の `{ theme?: AudioTheme }`。戻り値：`Promise<AudioPlaybackResult[]>`。1 人でも配列です。ID 省略時は現在のプレイヤーが対象。ブラウザーで音声が未解放の場合もあるため、再生結果を確認します。

```ts
const results = await pl.app.audio.play('success', 'p1', { theme: 'arcade' });
// [{ playerId: 'p1', played: true, state: 'running' }]
// A failure might be [{ playerId: 'p1', played: false, state: 'suspended',
//   reason: 'AUDIO_USER_GESTURE_REQUIRED' }]
```

結果：`playerId: string`、`played: boolean`、`state: AudioState`、任意の `reason: string`。AudioState は `idle`、`running`、`suspended`、`closed`、`error`、`unsupported`。

### pl.app.on(event, callback)

引数：`input`、`remote:action`、`message`、`selector:submit`、`draw:path`、`draw:frame` のいずれかと、対応する payload のコールバック。戻り値：`Unsubscribe`。各 payload に送信者の `playerId` が含まれます。

```ts
const off = pl.app.on('input', (input) => {
  if (input.type === 'button' && input.action === 'click' && !input.synthetic) {
    console.log(input.playerId, input.controlId); // 'p1', 'a'
  }
});
```

入力 payload の例：

```ts
// Button: type 'button', action 'down' | 'up' | 'click'
{ protocolVersion: 1, sessionId: 's1', playerId: 'p1', sequence: 1,
  timestamp: 1730000000000, controlId: 'a', synthetic: false,
  type: 'button', action: 'down' }
// Axis: x and y in -1..1
{ protocolVersion: 1, sessionId: 's1', playerId: 'p1', sequence: 2,
  timestamp: 1730000000001, controlId: 'left_stick', synthetic: false,
  type: 'axis', x: 0.5, y: -0.2 }
```

共通フィールド：`protocolVersion: 1`、string の `sessionId` と `playerId`、非負の安全な整数 `sequence`、非負整数 `timestamp`、1..64 文字の英数字・アンダースコア・ハイフンによる `controlId`、boolean の `synthetic`。1 回のタップで down/up/click が発生するため、単発の得点には 1 段階だけを使います。長押しは down/up で状態を管理します。synthetic は入力状態を復元するイベントです。解放や軸の中央復帰は処理し、新しい操作として得点には加えません。

その他のイベント payload の例：

```ts
// 'remote:action': action is up/down/left/right/confirm/cancel/back
{ playerId: 'p1', action: 'confirm' }
// 'message': custom phone data; validate shape, ranges, round, and frequency
{ playerId: 'p1', payload: { type: 'jump', roundId: 'r1' } }
// 'selector:submit'
{ playerId: 'p1', controlId: 'vote', requestId: 'r1', values: ['cat'] }
// 'draw:path'
{ playerId: 'p1', kind: 'path', action: 'move', controlId: 'sketch',
  requestId: 'r1', width: 1024, height: 768, backgroundColor: '#FFFFFF',
  strokeId: 'stroke-1', tool: 'pen', color: '#111111', strokeWidth: 0.01,
  points: [{ x: 0.2, y: 0.3 }, { x: 0.25, y: 0.35 }] }
// 'draw:frame': dataUrl contains a complete reassembled WebP image
{ playerId: 'p1', kind: 'frame', action: 'submit', controlId: 'sketch',
  requestId: 'r1', width: 1024, height: 768, backgroundColor: '#FFFFFF',
  frameId: 'frame-1', dataUrl: 'data:image/webp;base64,UklGR...' }
```

省略した data URL はフィールドの説明用で、有効な画像ではありません。requestId が現在のラウンドと一致するか確認し、重複した送信は無視します。

## コントローラー名とレイアウト

組み込み preset：`dpad-abxy`、`joystick-action`、`custom-buttons`、`multi-row-buttons`、`remote`、`selector`、`draw`。`joystick+dual-buttons` のように名前と順序で組み合わせることもできます。コンポーネント名：`joystick`、`dual-buttons`、`quad-buttons`、`dpad`、`menu-keys`、`custom-buttons`、`multi-row-buttons`、`selector`、`draw`。

`ControllerLayoutInput` は任意の `orientation: 'auto' | 'portrait' | 'landscape'` と、必須の `components`（1..4 個）を持ちます。型と順序を組み合わせ名に一致させてください。既定の向きは `auto`、selector 単独は `portrait`。control ID はレイアウト内で一意です。draw は単独で使用し、remote は固定の横向き dpad + menu-keys です。

- スティック：`{ type: 'joystick', controlId?: string, deadZone?: number }`。既定値は `left_stick`、0.12。deadZone は 0..0.9。
- 2 ボタン：`{ type: 'dual-buttons' }`。ID は `a`、`b`。
- 4 ボタン：`{ type: 'quad-buttons' }`。ID は `a`、`b`、`x`、`y`。
- 方向キー：`{ type: 'dpad' }`。ID は `up`、`down`、`left`、`right`。
- メニューキー：`{ type: 'menu-keys' }`。ID は `menu_back`、`menu_cancel`、`menu_confirm`。
- カスタムボタン：`{ type: 'custom-buttons', buttons: ButtonDefinition[] }`、1..12 個。各ボタンは `controlId`、`label`、整数の `gridX/gridY`（0..3）、任意の整数 `spanX/spanY`（1..2、既定値 1）、任意の `backgroundColor/textColor` を持ちます。4×4 のグリッドに重ならず、はみ出さず配置します。
- 複数行ボタン：`{ type: 'multi-row-buttons', buttons: [{ code, label, backgroundColor?, textColor? }] }`、1..4 個。`code` が control ID です。

ID は 1..64 文字の英数字・アンダースコア・ハイフン。ボタン label は 1..16 文字、色は `#RGB` または `#RRGGBB`。カスタムボタン preset では layout を明示すると、用途に合った ID を指定できます。

### 選択画面の設定

```ts
await pl.app.setController('selector', 'p1', {
  components: [{ type: 'selector', controlId: 'vote', requestId: 'r1',
    title: 'Choose an animal', mode: 'single',
    options: [{ id: 'cat', label: 'Cat' }, { id: 'dog', label: 'Dog' }],
  }],
}); // undefined
```

フィールド：`type: 'selector'`。任意の `controlId`（既定値 `selector`）、`requestId`（1..128 文字、既定値はランダム UUID。ラウンドごとの値を推奨）、`title`（最大 120 文字、既定値は空）、`mode`（既定値 `single`、または `multiple`）。必須の `options` は 1..100 個で ID は一意。選択肢 ID は control ID と同じ形式、label は 1..120 文字。任意の `submittedValues: string[]` で送信済みの選択を復元できます。空でなく重複のない選択肢 ID を指定し、single は 1 個、multiple は最大 100 個。結果は `selector:submit` で受信します。

### お絵描き画面の設定

```ts
await pl.app.setController('draw', 'p1', {
  components: [{ type: 'draw', controlId: 'sketch', requestId: 'r1',
    title: 'Draw a cat', width: 1024, height: 768,
    backgroundColor: '#FFFFFF', output: 'path', fps: 5, showSubmit: true,
  }],
}); // undefined
```

任意のフィールドと既定値：`controlId: 'draw'`、`requestId` はランダム UUID（1..128 文字）、`title` は最大 120 文字、`width: 1024` と `height: 768`（各 64..2048 の整数）、`backgroundColor: '#FFFFFF'`（6 桁の16進数）、`output` は既定値 `path` または `frame`、`fps: 5`（1..10）、`showSubmit: true`。`initialImage` は最大 48000 文字の WebP base64 data URL です。任意の画像 URL は使えません。

`DrawPath`：`kind: 'path'`、action は `start`、`move`、`end`、`clear`、`submit`。キャンバス情報は `controlId`、`requestId`、`width`、`height`、`backgroundColor`。`strokeId` は 1..128 文字、`tool: 'pen' | 'eraser'`、`color` は 6 桁の16進数、`strokeWidth` はキャンバスに対する相対値 0.0001..1。`points: { x: number; y: number }[]` は 0..1 に正規化した最大 64 点です。イベントには `playerId` も含まれます。

`DrawFrame` は上記キャンバス情報、`playerId`、`kind: 'frame'`、action（`frame`、`submit`、`clear`）、string の `frameId`、完全な WebP `dataUrl` を持ちます。イベントの前にフレームは再構成されています。画像文字列は最大 524288 文字、最大 32 分割、1 分割 16384 文字で、5 秒以内に完了します。フレームレートは控えめに設定してください。

エクスポートされる `DrawPacket` 型は、パスまたはフレームの断片を表します。断片は `dataUrl` の代わりに `index`、`length`、`data` を持ちます。通常のゲームでは再構成済みの `DrawFrame` を受け取ります。

### renderDrawPath(context, path)

正規化された描画操作を自分の Canvas に描画します。引数：`CanvasRenderingContext2D`、`DrawPath`。戻り値：`void`。寸法を画板設定と合わせ、プレイヤーごとに別の Canvas を使います。submit はゲーム側で処理します。

```ts
const canvases = new Map<string, HTMLCanvasElement>();
pl.app.on('draw:path', (path) => {
  let canvas = canvases.get(path.playerId);
  if (!canvas) {
    canvas = document.createElement('canvas');
    canvas.width = path.width; canvas.height = path.height;
    canvases.set(path.playerId, canvas);
    document.body.append(canvas);
  }
  renderDrawPath(canvas.getContext('2d')!, path); // undefined
});
```

## AudioAPI

`pl.game.audio`、`phone.app.audio`、`createAudioAPI()` は以下のメソッドを共有します。テーマ：`default`、`retro8bit`、`arcade`、`glass`、`cyber`。効果音：`click`、`focus`、`back`、`confirm`、`cancel`、`success`、`error`、`unlock`、`coin`、`notify`、`join`、`leave`、`countdown`。`AUDIO_THEMES` と `SFX_KINDS` は各文字列の readonly 配列です。

ブラウザーによっては、そのページでの実際のユーザー操作が音声再生に必要です。スマホの操作ではパソコンページの音声は解放されません。必要に応じてパソコン側に音声ボタンを用意します。以下では `const audio = pl.game.audio` を使います。

### audio.play(kind, options?)

引数：`kind: SfxKind`、任意の `{ theme?: AudioTheme }` で今回のテーマを上書きできます。戻り値は boolean で、音声が作成されたかを示し、聞こえたことは保証しません。false は静音、停止中、破棄済み、未対応、不正な音名、同時発音数の上限などで発生します。必要に応じて状態とエラーを確認します。

```ts
const played = audio.play('coin', { theme: 'retro8bit' }); // true or false
```

### audio.click()

現在のテーマで `click` を再生します。引数なし。boolean を返し、意味は `play` と同じです。

```ts
const played = audio.click(); // true or false
```

### audio.focus()

現在のテーマで `focus` を再生します。引数なし。boolean を返し、意味は `play` と同じです。

```ts
const played = audio.focus(); // true or false
```

### audio.back()

現在のテーマで `back` を再生します。引数なし。boolean を返し、意味は `play` と同じです。

```ts
const played = audio.back(); // true or false
```

### audio.confirm()

現在のテーマで `confirm` を再生します。引数なし。boolean を返し、意味は `play` と同じです。

```ts
const played = audio.confirm(); // true or false
```

### audio.cancel()

現在のテーマで `cancel` を再生します。引数なし。boolean を返し、意味は `play` と同じです。

```ts
const played = audio.cancel(); // true or false
```

### audio.success()

現在のテーマで `success` を再生します。引数なし。boolean を返し、意味は `play` と同じです。

```ts
const played = audio.success(); // true or false
```

### audio.error()

現在のテーマで `error` を再生します。引数なし。boolean を返し、意味は `play` と同じです。

```ts
const played = audio.error(); // true or false
```

### audio.unlock()

現在のテーマで `unlock` を再生します。引数なし。boolean を返し、意味は `play` と同じです。

```ts
const played = audio.unlock(); // true or false
```

### audio.coin()

現在のテーマで `coin` を再生します。引数なし。boolean を返し、意味は `play` と同じです。

```ts
const played = audio.coin(); // true or false
```

### audio.notify()

現在のテーマで `notify` を再生します。引数なし。boolean を返し、意味は `play` と同じです。

```ts
const played = audio.notify(); // true or false
```

### audio.join()

現在のテーマで `join` を再生します。引数なし。boolean を返し、意味は `play` と同じです。

```ts
const played = audio.join(); // true or false
```

### audio.leave()

現在のテーマで `leave` を再生します。引数なし。boolean を返し、意味は `play` と同じです。

```ts
const played = audio.leave(); // true or false
```

### audio.countdown()

現在のテーマで `countdown` を再生します。引数なし。boolean を返し、意味は `play` と同じです。

```ts
const played = audio.countdown(); // true or false
```

### audio.resume()

音声を初期化・再開します。引数なし。戻り値：`Promise<void>`。ページでのユーザー操作が必要な場合や音声利用不可の場合は reject されることがあります。`unlock()` は効果音のショートカットで、この再開処理とは別です。

```ts
soundButton.addEventListener('click', async () => {
  try { await audio.resume(); audio.confirm(); }
  catch (error) { console.error(error); }
}); // resume resolves to undefined
```

### audio.isSupported()

引数なし。AudioContext が利用可能かを boolean で返します。

```ts
const supported = audio.isSupported(); // true or false
```

### audio.getState()

引数なし。`AudioState`：idle/running/suspended/closed/error/unsupported を返します。

```ts
const state = audio.getState(); // 'running'
```

### audio.getLastError()

引数なし。最後に記録した再生・再開エラーを `string | undefined` で返します。

```ts
const error = audio.getLastError(); // undefined or 'AUDIO_USER_GESTURE_REQUIRED'
```

### audio.setTheme(theme)

引数：`theme: AudioTheme`。戻り値：`void`。以後の効果音の既定テーマを設定します。

```ts
audio.setTheme('glass'); // undefined
```

### audio.getTheme()

引数なし。`AudioTheme` を返します。初期値は `default`。

```ts
const theme = audio.getTheme(); // 'glass'
```

### audio.setVolume(volume)

引数：ローカル音量 `volume: number`。値は 0..1 に制限されます。戻り値：`void`。音量追従が有効な場合はプラットフォームの effects 音量と掛け合わせます。

```ts
audio.setVolume(0.8); // undefined
```

### audio.getVolume()

引数なし。プラットフォーム音量を掛ける前のローカル音量を返します。初期値は 1。

```ts
const volume = audio.getVolume(); // 0.8
```

### audio.mute()

引数なし。戻り値：`void`。ミュートし、再生中の音声を止めます。

```ts
audio.mute(); // undefined
```

### audio.unmute()

引数なし。戻り値：`void`。以後の音声をローカル音量で再生できるようにします。

```ts
audio.unmute(); // undefined
```

### audio.isMuted()

引数なし。ローカルのミュート状態を boolean で返します。

```ts
const muted = audio.isMuted(); // false
```

### audio.dispose()

引数なし。戻り値：`void`。音声、購読、音声コンテキストを解放します。繰り返し呼び出せます。SDK の音声はクライアントと共に破棄され、別途作成したインスタンスは自分で破棄します。

```ts
audio.dispose(); // undefined
audio.getState(); // 'closed'
```

### createAudioAPI(options?)

独立した AudioAPI を作成します。引数：任意の `{ AudioContextImpl?: typeof AudioContext; autoUnlock?: boolean; followPlatformVolume?: boolean }`。既定ではブラウザーの AudioContext、実際のローカル操作による自動解放、現在のページの effects 音量への追従を使用します。戻り値：`AudioAPI`。

```ts
const extraAudio = createAudioAPI({ autoUnlock: true, followPlatformVolume: true });
extraAudio.getTheme(); // 'default'
extraAudio.dispose();
```

### getVolumeSettings()

`pl.game.getVolumeSettings()` と同等のトップレベル関数。引数なし。現在のページの `VolumeSettings` のコピーを返します。

```ts
const settings = getVolumeSettings(); // { music: 0.5, effects: 0.5 }
```

### subscribeVolumeSettings(callback)

ゲームの音量購読と同等のトップレベル関数。引数：`(settings: VolumeSettings) => void`。戻り値：`Unsubscribe`。初期値は別途取得します。

```ts
const off = subscribeVolumeSettings((settings) => console.log(settings.music));
// A later callback might receive { music: 0.7, effects: 0.5 }
off(); // undefined
```

### bindMediaVolume(media, channel)

既存メディアの音量をプラットフォームの music/effects 音量と連動させます。引数：`media: { volume: number }`（通常は HTMLAudioElement）、`channel: 'music' | 'effects'`。戻り値：`Unsubscribe`。解除すると元の音量動作に戻ります。再生音量は基準音量と指定チャンネルの積です。連動中に `media.volume` を書き換えると基準音量が変わります。

```ts
const music = new Audio('./assets/music.ogg');
music.volume = 0.8;
const off = bindMediaVolume(music, 'music');
// At platform music 0.5, effective playback volume is 0.4.
pl.onDispose(() => { off(); music.pause(); });
```

自分の WebAudio グラフでは、音量を取得・購読して固定の基準値から GainNode を更新します。直前の値に繰り返し掛けると意図せず音が小さくなるので注意してください。

## カスタムスマホページ

manifest に `customControllers: { steering: 'controllers/steering.html' }` を宣言し、layout なしの `pl.app.setController('steering', 'p1')` で有効にします。key は 1..64 文字の英数字・アンダースコア・ハイフンで、組み込み preset/コンポーネント名（`custom` を含む）と異なる名前です。コントローラー HTML をビルド入口に指定し、関連リソースも含めます。

```ts
const phone = await PartyLink.init({ mode: 'controller' });
```

このページは専用のコントローラークライアントを受け取ります。`phone.state` は `ready` または `disposed`。

### phone.app.isEnabled()

引数なし。現在入力が許可されているかを boolean で返します。送信前に確認し、無効時や非表示時には独自の長押し状態などを解除します。

```ts
if (phone.app.isEnabled()) await phone.game.sendMessage({ type: 'jump' });
// true allows sending; false means input is blocked
```

### phone.app.requestOrientation(orientation)

引数：`orientation: 'auto' | 'portrait' | 'landscape'`。戻り値：`void`。表示方向を要求しますが、OS の物理的な画面方向ロックは保証しません。

```ts
phone.app.requestOrientation('landscape'); // undefined
```

### phone.app.audio

上記の全メソッドを使えるローカル AudioAPI。このページには独立した音量状態があり、ローカル音声や音量ヘルパーはプラットフォームの変更を自動では受信しません。スマホの効果音をプラットフォーム音量に合わせるには、業務メッセージを送ってゲームに `pl.app.audio.play` を呼び出してもらいます。

```ts
phone.app.audio.getState(); // 'idle', for example
```

### phone.game.sendMessage(payload)

引数：JSON 化できる `payload: unknown`。playerId で包む必要はありません。スマホが送信を受け付けると `Promise<void>` が解決し、ゲーム処理の完了確認は含みません。タイムアウトは 5 秒。無効時は `INPUT_BLOCKED` で reject されます。ゲームには payload と一緒にプラットフォームが確認した送信者 ID が届きます。

```ts
await phone.game.sendMessage({ type: 'jump', roundId: 'r1' }); // undefined
// Game 'message' payload: { playerId: 'p1', payload: { type: 'jump', roundId: 'r1' } }
```

### phone.game.on('message', callback)

引数：文字列 `message` とコールバック `(payload: unknown) => void`。戻り値：`Unsubscribe`。ゲームが送信した payload を直接受け取ります。

```ts
const off = phone.game.on('message', (payload) => console.log(payload));
// Example callback payload: { type: 'round', roundId: 'r1', score: 3 }
off(); // undefined
```

### phone.dispose()

引数なし。戻り値：`void`。コントローラーと音声を解放し、保留中の送信を reject します。繰り返し呼び出せます。pagehide でも自動破棄します。自分の DOM リスナー、タイマー、アニメーションは別途解除してください。

```ts
phone.dispose(); // undefined
console.log(phone.state); // 'disposed'
```

## ゲームのライフサイクル

### pl.state

読み取り専用プロパティ。`ready` または `disposed`。

```ts
console.log(pl.state); // 'ready'
```

### pl.on('close', callback)

引数：文字列 `close` とコールバック `(payload: { code: string }) => void`。戻り値：`Unsubscribe`。

```ts
const off = pl.on('close', ({ code }) => console.log(code));
// Example callback payload: { code: 'HOST_CLOSED' }
```

### pl.onDispose(callback)

引数：`callback: () => void`。戻り値：`Unsubscribe`。破棄時に呼ばれ、破棄済みなら即座に呼ばれます。ゲームのリソース解放に利用できます。

```ts
const timer = window.setInterval(() => {}, 1000);
const off = pl.onDispose(() => window.clearInterval(timer));
// Callback receives no arguments; off() returns undefined.
```

### pl.dispose()

引数なし。戻り値：`void`。SDK クライアントを解放し、繰り返し呼び出せます。自分の RAF、イベント、タイマー、購読、メディアも解放します。

```ts
pl.dispose(); // undefined
console.log(pl.state); // 'disposed'
```

## ビルドと ZIP の形式

Vite では `base: './'` と `build: { target: 'es2022' }` を使用し、相対リソースとトップレベル await に対応します。スクリプト、スタイル、フォント、画像、音声を相対パスでパッケージに含めます。実行時 CDN やサーバー専用ルーティングがなくても動くゲームにします。`npm run package` でビルドし `release/game.zip` を生成できるようにします。開発用 starter にはこの手順が用意されています。

ZIP の直下に `manifest.json`、入口 HTML、参照先のカバー画像やリソースを置きます。出力フォルダーの中身を圧縮し、外側のフォルダーを含めないでください。

```json
{
  "schemaVersion": 1,
  "id": "living-room-quiz",
  "name": "Living Room Quiz",
  "version": "1.0.0",
  "description": "A quick quiz for friends and family using phone controls.",
  "players": { "min": 2, "max": 8 },
  "categories": ["party", "trivia"],
  "entry": "index.html",
  "cover": "cover.png",
  "sdkProtocolVersion": 1,
  "launch": { "mode": "iframe" }
}
```

必須フィールドは上記のとおり。`id` は `[a-z0-9][a-z0-9-]{0,63}`、name は 1..100 文字、description は 1..500 文字、version は数値 3 段。players min/max は 1..1000 の整数で min <= max（実際の同時接続は最大 12 人）。categories は重複のない 1..5 個で、party、puzzle、action、arcade、strategy、sports、racing、trivia、music、casual、developer-tools から選びます。entry はパッケージ内 HTML、cover は実際の webp/png/jpg/jpeg/gif 画像。launch mode は iframe または popup。

任意の `locales` は BCP47 タグから `{ name?: string; description?: string }` への対応です。既定の文言は英語にします。各フィールドは完全一致のロケール、基本言語、既定値の順で探します。任意の `customControllers` は上記のように key と HTML パスを対応させます。定義外の manifest フィールドは受け付けません。公開する更新には新しい version を使います。ローカル開発では同じゲーム ID の ZIP を読み込むとローカルのコピーを置き換え、バージョンが同じでも更新できます。

リソースパスは ZIP 直下からの相対パスで、大文字と小文字を区別します。絶対パス、URL、空の区間、`.`/`..`、バックスラッシュ、`%`、`?`、`#`、`:`、制御文字は使えません。ZIP 上限：圧縮後 50 MiB、展開後 200 MiB、1 ファイル 50 MiB、2000 エントリー、1 パス 240 文字、圧縮率 100:1。暗号化されていない通常の ZIP で、パスが重複しない通常ファイルと正常な CRC を使用します。

## メッセージの上限とエラー

通常の業務メッセージは、プロトコル情報を含む全体で 4096 UTF-8 バイトまでです。payload は十分に小さくします。JSON 互換のデータを使用し、関数、DOM、循環オブジェクト、BigInt は送信できません。コントローラー設定と選択結果は最大 65536 バイト。描画には専用の上限があるため、大きな画像を業務メッセージで送らず描画機能を利用します。

失敗を処理し、状況に応じて再試行や起動方法を案内します。代表的なコード：`HOST_NOT_FOUND` または起動環境エラー、`HOST_BRIDGE_TIMEOUT`、`APP_BRIDGE_TIMEOUT`、`GAME_DISPOSED`、`CONTROLLER_DISPOSED`、`MESSAGE_TIMEOUT`、`MESSAGE_TOO_LARGE`、`INPUT_BLOCKED`、`CUSTOM_CONTROLLER_NOT_FOUND`、`CONTROLLER_COMPONENT_UNKNOWN`、`CONTROLLER_LAYOUT_CONFLICT`。実際のコードは失敗箇所によって異なります。初期化を無限に再試行しないでください。