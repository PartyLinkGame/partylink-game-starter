# 平台公开API与能力

SDK 版本：`@partylink/game-sdk@0.1.2`，协议版本：`1`。本页提供完整的开发契约，AI 可据此实现并打包游戏。

## 安装与初始化

```sh
npm install --save-exact @partylink/game-sdk@0.1.2
```

```ts
import {
  PartyLink, createAudioAPI, getVolumeSettings, subscribeVolumeSettings,
  bindMediaVolume, renderDrawPath, AUDIO_THEMES, SFX_KINDS,
} from '@partylink/game-sdk';
import type { PlatformClient, Player, DrawPath } from '@partylink/game-sdk';
```

`PartyLink` 和上述工具函数是运行时导出，`PlatformClient` 等接口是类型。通过 `PartyLink.init` 获取客户端。

### PartyLink.init(options)

连接从 PartyLink Library 启动的游戏，或由 PartyLink 打开的自定义手机控制器。

参数：游戏使用 `{ mode: 'iframe' | 'popup'; timeoutMs?: number; allowedHostOrigins?: readonly string[]; allowInsecureDevelopment?: boolean }`。mode 与启动环境一致。`timeoutMs` 默认 10000 毫秒；`allowedHostOrigins` 可限定接受的精确 origin；`allowInsecureDevelopment` 是可选开发设置，仍需有效启动环境。手机页面只使用 `{ mode: 'controller' }`。

返回：游戏为 `Promise<PlatformClient>`，手机为 `Promise<CustomControllerClient>`。缺少启动环境、环境无效或超时时拒绝。直接打开游戏页面时，应提示从 Library 启动。

```ts
const mode = new URLSearchParams(location.search).get('plMode');
if (mode !== 'iframe' && mode !== 'popup') {
  document.body.textContent = 'Launch this game from PartyLink Library.';
  throw new Error('Launch context required');
}
const pl = await PartyLink.init({ mode });
console.log(pl.state); // 'ready'
// In a custom controller page instead:
// const phone = await PartyLink.init({ mode: 'controller' });
```

游戏初始化时，若没有已连接玩家、允许加入且连接界面可用，会自动打开一次加入界面。此后每次断线不会自动重新打开。

## 公共数据与行为

所有 `on` 和订阅方法返回 `Unsubscribe`，即 `() => void`；调用后停止回调。订阅只接收后续变化，有快照方法时先读取初值。异步调用需处理失败。`Promise<void>` 表示请求的操作已完成、不返回值，不代表另一台设备的游戏逻辑已处理业务消息。销毁后的客户端调用可能失败。

`playerId` 始终指 `Player.id`；昵称和数组位置不能稳定标识玩家。当前会话最多支持 12 位玩家，快照可能包含已断线玩家。

```ts
const player: Player = {
  id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '',
  gender: 'none', state: 'connected', joinedAt: 1730000000000,
  controllerType: 'dpad-abxy', isPrimary: true, controlMode: 'game',
};
```

Player 必填字段：`id`、`sessionId`、`nickname`（1..64 字符）、`avatar`（空字符串、JPEG data URL 或临时 blob URL）、`gender`（`none`、`male`、`female`）、`state`（`connecting`、`connected`、`disconnected`）、`joinedAt`（number）。可选 `controllerType` 为内置 preset ID 或 `custom`；`isPrimary` 为 boolean；`controlMode` 为 `game`、`remote` 或 `waiting`。临时头像 blob URL 仅适合当前会话。

`ConnectionOverlayState` 包含必填布尔值 `available`、`visible`、`canJoin` 和可选字符串 `qrPayload`、`overlayUrl`。加入数据对应当前会话。

## 玩家与加入：pl.host

### pl.host.getPlayers()

无参数。返回 `Player[]`，为本地快照副本。

```ts
const players = pl.host.getPlayers();
// [{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '',
//    gender: 'none', state: 'connected', joinedAt: 1730000000000 }]
```

### pl.host.getPlayer(id)

参数：`id: string`。返回 `Player` 副本，不存在时为 `undefined`。

```ts
const player = pl.host.getPlayer('p1'); // Player or undefined
```

### pl.host.removePlayer(id?)

断开连接并移除玩家。参数：可选 `id: string`，省略时移除全部玩家。返回 `Promise<void>`。

```ts
await pl.host.removePlayer('p1'); // undefined
```

### pl.host.getLobbyState()

无参数。返回 `Promise<{ enabled: boolean; primaryPlayerId?: string }>`。

```ts
const lobby = await pl.host.getLobbyState();
// { enabled: true, primaryPlayerId: 'p1' }
```

### pl.host.setPrimaryPlayer(id)

指定负责大厅导航的主控玩家。参数：`id: string`。返回 `Promise<void>`。

```ts
await pl.host.setPrimaryPlayer('p1'); // undefined
```

### pl.host.setLobbyMode(enabled)

在大厅遥控导航（`true`）与游戏输入（`false`）之间切换，不会开始或暂停游戏逻辑。参数：`enabled: boolean`。返回 `Promise<void>`。

```ts
await pl.host.setLobbyMode(false); // undefined
```

### pl.host.getConnectionOverlay()

无参数。返回 `Promise<ConnectionOverlayState>`。

```ts
const overlay = await pl.host.getConnectionOverlay();
// { available: true, visible: false, canJoin: true, qrPayload: 'session-join-data' }
```

### pl.host.setConnectionOverlay(visible)

显示或隐藏平台加入界面。参数：`visible: boolean`。返回 `Promise<void>`。显示界面不会暂停正在进行的游戏。

```ts
await pl.host.setConnectionOverlay(true); // undefined
```

### pl.host.on(event, callback)

参数：以下事件之一，以及接收其 payload 的回调。返回 `Unsubscribe`。

```ts
const off = pl.host.on('player:join', async (player) => {
  await pl.app.setController('dpad-abxy', player.id);
});
off(); // undefined; stop this listener
```

玩家事件直接传入 Player 对象，不会再包一层 `player` 属性：

```ts
// 'player:join'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'connected', joinedAt: 1730000000000 }
// 'player:update'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'connected', joinedAt: 1730000000000, isPrimary: true }
// 'player:leave'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'disconnected', joinedAt: 1730000000000 }
// 'connection:overlay'
{ available: true, visible: true, canJoin: true, qrPayload: 'session-join-data' }
```

先用 `getPlayers()` 配置已有玩家，再根据当前回合规则，在加入或更新事件中配置新玩家和重连玩家。玩家断线时清空其持续输入状态。

## 游戏设置：pl.game

### pl.game.getLocale()

无参数。返回当前语言字符串，游戏可据此切换自己的文案。

```ts
const locale = pl.game.getLocale(); // 'en-US'
```

### pl.game.getVolumeSettings()

无参数。返回 `VolumeSettings`：`{ music: number; effects: number }`，两个值均为 0..1。

```ts
const settings = pl.game.getVolumeSettings(); // { music: 0.5, effects: 0.5 }
```

### pl.game.subscribeVolumeSettings(callback)

参数：回调 `(settings: VolumeSettings) => void`。返回 `Unsubscribe`，订阅时不会立即发送初值。

```ts
const initial = pl.game.getVolumeSettings();
const off = pl.game.subscribeVolumeSettings((settings) => {
  console.log(settings.effects); // 0.7 after a matching change
});
```

### pl.game.requestClose()

请求 PartyLink 关闭当前游戏。无参数。返回 `Promise<void>`。

```ts
await pl.game.requestClose(); // undefined
```

### pl.game.on(event, callback)

参数：`event: 'locale:change' | 'game:control'`，以及对应 payload 的回调。返回 `Unsubscribe`。

```ts
const off = pl.game.on('locale:change', ({ locale }) => {
  document.documentElement.lang = locale;
});
// 'locale:change' payload: { locale: 'en-US' }
// 'game:control' payload: { playerId: 'p1', action: 'pause' }
// Resume payload: { playerId: 'p1', action: 'resume' }
```

`game:control` 发出暂停或继续请求。游戏须相应处理模拟、计时和音频，并在暂停时清空持续输入。

### pl.game.audio

在电脑游戏页面播放的 `AudioAPI` 实例，下文列出全部方法。其音量跟随平台 effects 通道，随 SDK 客户端一起释放。

```ts
const played = pl.game.audio.confirm(); // true if a sound was created
```

## 手机控制与反馈：pl.app

### pl.app.setController(name, playerId?, layout?)

配置手机控制器。参数：`name: string`（preset、组件组合或 manifest 自定义控制器 key），可选 `playerId: string` 和 `layout: ControllerLayoutInput`。返回 `Promise<void>`。省略 playerId 仅设置当前玩家，后来加入的玩家需另行配置。为所有玩家传布局时，第二个参数传 `undefined`。

```ts
await pl.app.setController('joystick-action', 'p1'); // undefined
await pl.app.setController('custom-buttons', undefined, {
  orientation: 'landscape',
  components: [{ type: 'custom-buttons', buttons: [
    { controlId: 'jump', label: 'Jump', gridX: 0, gridY: 0, spanX: 2 },
  ] }],
}); // undefined
```

### pl.app.setControllersEnabled(enabled, playerId?)

启用或阻止游戏输入，保留当前布局。参数：`enabled: boolean`，可选 `playerId: string`。返回 `Promise<void>`。省略 ID 设置持续生效的全局开关，影响后来加入和重连玩家，并重置玩家独立开关。指定玩家时，玩家与全局开关须同时允许才可输入。禁用的自定义控制器不能发送业务消息。禁用输入时应清空本地持续操作状态。

```ts
await pl.app.setControllersEnabled(false); // undefined; pause all input
await pl.app.setControllersEnabled(true); // undefined; allow all input again
await pl.app.setControllersEnabled(false, 'p1'); // undefined; block this player
```

### pl.app.showToast(options, playerId?)

在手机显示纯文本提示，新提示会替换当前提示。参数：`{ text: string; type?: 'text' | 'success' | 'error'; position?: 'top' | 'center' | 'bottom'; duration?: number }`，可选玩家 ID。返回 `Promise<void>`。省略 ID 发给当前玩家。去除首尾空白后 text 为 1..200 UTF-16 字符；duration 为 1000..10000 毫秒的整数。默认 type 为 `text`、position 为 `center`、duration 为 3000。富文本和对话框可在游戏页面实现。

```ts
await pl.app.showToast({ text: 'Your turn!', type: 'success', duration: 2000 }, 'p1');
// undefined
```

### pl.app.sendMessage(payload, playerId?)

向自定义手机页面发送业务数据。参数：可 JSON 序列化的 `payload: unknown`，可选玩家 ID。返回 `Promise<void>`。省略 ID 发给当前玩家。如需确认业务处理完成，可设计回执消息。

```ts
await pl.app.sendMessage({ type: 'round', roundId: 'r1', score: 3 }, 'p1');
// undefined; phone.game.on('message') receives that payload directly
```

### pl.app.audio.play(kind, playerId?, options?)

播放手机音效。参数：`kind: SfxKind`、可选玩家 ID、第三位置可选 `{ theme?: AudioTheme }`。返回 `Promise<AudioPlaybackResult[]>`，单个玩家也返回数组。省略 ID 面向当前玩家。浏览器可能尚未解锁音频，需检查播放结果。

```ts
const results = await pl.app.audio.play('success', 'p1', { theme: 'arcade' });
// [{ playerId: 'p1', played: true, state: 'running' }]
// A failure might be [{ playerId: 'p1', played: false, state: 'suspended',
//   reason: 'AUDIO_USER_GESTURE_REQUIRED' }]
```

结果字段：`playerId: string`、`played: boolean`、`state: AudioState`、可选 `reason: string`。AudioState 为 `idle`、`running`、`suspended`、`closed`、`error` 或 `unsupported`。

### pl.app.on(event, callback)

参数：`input`、`remote:action`、`message`、`selector:submit`、`draw:path` 或 `draw:frame`，以及对应 payload 的回调。返回 `Unsubscribe`。每个 payload 都带有发送方的 `playerId`。

```ts
const off = pl.app.on('input', (input) => {
  if (input.type === 'button' && input.action === 'click' && !input.synthetic) {
    console.log(input.playerId, input.controlId); // 'p1', 'a'
  }
});
```

输入 payload 示例：

```ts
// Button: type 'button', action 'down' | 'up' | 'click'
{ protocolVersion: 1, sessionId: 's1', playerId: 'p1', sequence: 1,
  timestamp: 1730000000000, controlId: 'a', synthetic: false,
  type: 'button', action: 'down' }
// Axis: x and y in -1..1
{ protocolVersion: 1, sessionId: 's1', playerId: 'p1', sequence: 2,
  timestamp: 1730000000001, controlId: 'left_stick', synthetic: false,
  type: 'axis', x: 0.5, y: -0.2 }
```

公共字段：`protocolVersion: 1`；字符串 `sessionId`、`playerId`；非负安全整数 `sequence`；非负整数 `timestamp`；由 1..64 个字母、数字、下划线或短横线组成的 `controlId`；布尔值 `synthetic`。一次点击可能触发 down/up/click，一次性计分只选其中一个阶段。持续动作使用 down/up 保存状态。synthetic 事件用于恢复输入状态，应处理释放和轴归零，但不作为玩家新动作计分。

其他事件 payload 示例：

```ts
// 'remote:action': action is up/down/left/right/confirm/cancel/back
{ playerId: 'p1', action: 'confirm' }
// 'message': custom phone data; validate shape, ranges, round, and frequency
{ playerId: 'p1', payload: { type: 'jump', roundId: 'r1' } }
// 'selector:submit'
{ playerId: 'p1', controlId: 'vote', requestId: 'r1', values: ['cat'] }
// 'draw:path'
{ playerId: 'p1', kind: 'path', action: 'move', controlId: 'sketch',
  requestId: 'r1', width: 1024, height: 768, backgroundColor: '#FFFFFF',
  strokeId: 'stroke-1', tool: 'pen', color: '#111111', strokeWidth: 0.01,
  points: [{ x: 0.2, y: 0.3 }, { x: 0.25, y: 0.35 }] }
// 'draw:frame': dataUrl contains a complete reassembled WebP image
{ playerId: 'p1', kind: 'frame', action: 'submit', controlId: 'sketch',
  requestId: 'r1', width: 1024, height: 768, backgroundColor: '#FFFFFF',
  frameId: 'frame-1', dataUrl: 'data:image/webp;base64,UklGR...' }
```

上面缩略的 data URL 仅展示字段形态，不是可用图片。提交时核对 requestId 与当前回合，并忽略重复提交。

## 控制器名称与布局字段

内置 preset：`dpad-abxy`、`joystick-action`、`custom-buttons`、`multi-row-buttons`、`remote`、`selector`、`draw`。组件也可按名称和顺序组合，例如 `joystick+dual-buttons`。可用组件名：`joystick`、`dual-buttons`、`quad-buttons`、`dpad`、`menu-keys`、`custom-buttons`、`multi-row-buttons`、`selector`、`draw`。

`ControllerLayoutInput` 包含可选 `orientation: 'auto' | 'portrait' | 'landscape'` 和必填 `components`（1..4 个）。组件类型和顺序须匹配组合名称。默认方向为 `auto`，单独 selector 默认 `portrait`。布局内 control ID 唯一。draw 单独使用；remote 使用固定横屏 dpad + menu-keys 布局。

- 摇杆：`{ type: 'joystick', controlId?: string, deadZone?: number }`；默认 `left_stick`、0.12，deadZone 为 0..0.9。
- 双按钮：`{ type: 'dual-buttons' }`；ID 为 `a`、`b`。
- 四按钮：`{ type: 'quad-buttons' }`；ID 为 `a`、`b`、`x`、`y`。
- 方向键：`{ type: 'dpad' }`；ID 为 `up`、`down`、`left`、`right`。
- 菜单键：`{ type: 'menu-keys' }`；ID 为 `menu_back`、`menu_cancel`、`menu_confirm`。
- 自定义按钮：`{ type: 'custom-buttons', buttons: ButtonDefinition[] }`，1..12 个按钮。各包含 `controlId`、`label`、整数 `gridX/gridY`（0..3）、可选整数 `spanX/spanY`（1..2，默认 1）、可选 `backgroundColor/textColor`。按钮在 4×4 网格内排列，位置不重叠、不超出边界。
- 多行按钮：`{ type: 'multi-row-buttons', buttons: [{ code, label, backgroundColor?, textColor? }] }`，1..4 个按钮，`code` 即 control ID。

ID 由 1..64 个字母、数字、下划线或短横线组成。按钮 label 为 1..16 字符，颜色为 `#RGB` 或 `#RRGGBB`。自定义按钮 preset 建议显式传入布局，以使用有意义的 ID。

### 选择器配置

```ts
await pl.app.setController('selector', 'p1', {
  components: [{ type: 'selector', controlId: 'vote', requestId: 'r1',
    title: 'Choose an animal', mode: 'single',
    options: [{ id: 'cat', label: 'Cat' }, { id: 'dog', label: 'Dog' }],
  }],
}); // undefined
```

字段：`type: 'selector'`；可选 `controlId`（默认 `selector`）；可选 `requestId`（1..128 字符，默认随机 UUID，建议使用回合标识）；可选 `title`（最多 120 字符，默认空）；可选 `mode`（默认 `single`，也可 `multiple`）；必填 `options`（1..100 个，ID 唯一）。选项 ID 格式与 control ID 相同，label 为 1..120 字符。可选 `submittedValues: string[]` 可恢复已提交选择，数组非空且选项 ID 不重复；single 为 1 项，multiple 最多 100 项。提交通过 `selector:submit` 接收。

### 画板配置

```ts
await pl.app.setController('draw', 'p1', {
  components: [{ type: 'draw', controlId: 'sketch', requestId: 'r1',
    title: 'Draw a cat', width: 1024, height: 768,
    backgroundColor: '#FFFFFF', output: 'path', fps: 5, showSubmit: true,
  }],
}); // undefined
```

可选字段及默认值：`controlId: 'draw'`；`requestId` 默认随机 UUID，1..128 字符；`title` 最多 120 字符；`width: 1024`、`height: 768`，两者为 64..2048 的整数；`backgroundColor: '#FFFFFF'`（六位十六进制）；`output` 默认 `path`，也可 `frame`；`fps: 5`（1..10）；`showSubmit: true`；`initialImage` 为 WebP base64 data URL，最多 48000 字符，不接受任意图片 URL。

`DrawPath`：`kind: 'path'`；action 为 `start`、`move`、`end`、`clear` 或 `submit`；画布字段 `controlId`、`requestId`、`width`、`height`、`backgroundColor`；`strokeId`（1..128 字符）；`tool: 'pen' | 'eraser'`；六位十六进制 `color`；相对画布大小的 `strokeWidth`（0.0001..1）；`points: { x: number; y: number }[]`，最多 64 个归一化到 0..1 的坐标点。事件额外包含 `playerId`。

`DrawFrame` 包含上述画布字段、`playerId`、`kind: 'frame'`、action（`frame`、`submit` 或 `clear`）、字符串 `frameId` 和完整 WebP `dataUrl`。帧在触发事件前已重组。图片字符串最多 524288 字符，最多 32 段、每段 16384 字符，5 秒内完成。使用时选择适中的帧率。

导出的 `DrawPacket` 类型表示路径或帧分段；帧分段使用 `index`、`length`、`data`，而非 `dataUrl`。普通游戏监听器接收重组后的 `DrawFrame`。

### renderDrawPath(context, path)

将归一化绘图操作渲染到自己的 Canvas。参数：`CanvasRenderingContext2D`、`DrawPath`。返回 `void`。Canvas 尺寸与画板配置一致，各玩家使用独立画布，提交动作由游戏逻辑处理。

```ts
const canvases = new Map<string, HTMLCanvasElement>();
pl.app.on('draw:path', (path) => {
  let canvas = canvases.get(path.playerId);
  if (!canvas) {
    canvas = document.createElement('canvas');
    canvas.width = path.width; canvas.height = path.height;
    canvases.set(path.playerId, canvas);
    document.body.append(canvas);
  }
  renderDrawPath(canvas.getContext('2d')!, path); // undefined
});
```

## AudioAPI

`pl.game.audio`、`phone.app.audio` 和 `createAudioAPI()` 共享以下方法。主题：`default`、`retro8bit`、`arcade`、`glass`、`cyber`。音效：`click`、`focus`、`back`、`confirm`、`cancel`、`success`、`error`、`unlock`、`coin`、`notify`、`join`、`leave`、`countdown`。`AUDIO_THEMES`、`SFX_KINDS` 导出对应字符串的只读数组。

浏览器可能需要页面上的真实用户操作才能发声，手机操作不会解锁电脑页面音频。需要时可提供电脑端声音按钮。以下示例使用 `const audio = pl.game.audio`。

### audio.play(kind, options?)

参数：`kind: SfxKind`，可选 `{ theme?: AudioTheme }` 可为本次音效覆盖当前主题。返回 boolean，表示是否创建声音，不保证实际听到。返回 false 可能因为静音、挂起、已销毁、不支持、音效名无效或同时发声数量已满。需要时检查状态和错误。

```ts
const played = audio.play('coin', { theme: 'retro8bit' }); // true or false
```

### audio.click()

使用当前主题播放 `click` 音效。无参数。返回 boolean，含义与 `play` 一致。

```ts
const played = audio.click(); // true or false
```

### audio.focus()

使用当前主题播放 `focus` 音效。无参数。返回 boolean，含义与 `play` 一致。

```ts
const played = audio.focus(); // true or false
```

### audio.back()

使用当前主题播放 `back` 音效。无参数。返回 boolean，含义与 `play` 一致。

```ts
const played = audio.back(); // true or false
```

### audio.confirm()

使用当前主题播放 `confirm` 音效。无参数。返回 boolean，含义与 `play` 一致。

```ts
const played = audio.confirm(); // true or false
```

### audio.cancel()

使用当前主题播放 `cancel` 音效。无参数。返回 boolean，含义与 `play` 一致。

```ts
const played = audio.cancel(); // true or false
```

### audio.success()

使用当前主题播放 `success` 音效。无参数。返回 boolean，含义与 `play` 一致。

```ts
const played = audio.success(); // true or false
```

### audio.error()

使用当前主题播放 `error` 音效。无参数。返回 boolean，含义与 `play` 一致。

```ts
const played = audio.error(); // true or false
```

### audio.unlock()

使用当前主题播放 `unlock` 音效。无参数。返回 boolean，含义与 `play` 一致。

```ts
const played = audio.unlock(); // true or false
```

### audio.coin()

使用当前主题播放 `coin` 音效。无参数。返回 boolean，含义与 `play` 一致。

```ts
const played = audio.coin(); // true or false
```

### audio.notify()

使用当前主题播放 `notify` 音效。无参数。返回 boolean，含义与 `play` 一致。

```ts
const played = audio.notify(); // true or false
```

### audio.join()

使用当前主题播放 `join` 音效。无参数。返回 boolean，含义与 `play` 一致。

```ts
const played = audio.join(); // true or false
```

### audio.leave()

使用当前主题播放 `leave` 音效。无参数。返回 boolean，含义与 `play` 一致。

```ts
const played = audio.leave(); // true or false
```

### audio.countdown()

使用当前主题播放 `countdown` 音效。无参数。返回 boolean，含义与 `play` 一致。

```ts
const played = audio.countdown(); // true or false
```

### audio.resume()

初始化或恢复音频。无参数。返回 `Promise<void>`，需要本地用户操作或音频不可用时可能拒绝。`unlock()` 是音效快捷方法，并非恢复音频操作。

```ts
soundButton.addEventListener('click', async () => {
  try { await audio.resume(); audio.confirm(); }
  catch (error) { console.error(error); }
}); // resume resolves to undefined
```

### audio.isSupported()

无参数。返回 boolean，表示是否支持 AudioContext。

```ts
const supported = audio.isSupported(); // true or false
```

### audio.getState()

无参数。返回 `AudioState`：idle/running/suspended/closed/error/unsupported。

```ts
const state = audio.getState(); // 'running'
```

### audio.getLastError()

无参数。返回 `string | undefined`，表示最近记录的播放或恢复错误。

```ts
const error = audio.getLastError(); // undefined or 'AUDIO_USER_GESTURE_REQUIRED'
```

### audio.setTheme(theme)

参数：`theme: AudioTheme`。返回 `void`，设置后续音效的默认主题。

```ts
audio.setTheme('glass'); // undefined
```

### audio.getTheme()

无参数。返回 `AudioTheme`，初值为 `default`。

```ts
const theme = audio.getTheme(); // 'glass'
```

### audio.setVolume(volume)

参数：本地混音量 `volume: number`，会限制在 0..1。返回 `void`。启用平台音量跟随后，与平台 effects 通道共同决定音量。

```ts
audio.setVolume(0.8); // undefined
```

### audio.getVolume()

无参数。返回本地混音量（初值 1），不是乘入平台通道后的最终音量。

```ts
const volume = audio.getVolume(); // 0.8
```

### audio.mute()

无参数。返回 `void`，静音并停止当前声音。

```ts
audio.mute(); // undefined
```

### audio.unmute()

无参数。返回 `void`，恢复后续音效的本地混音。

```ts
audio.unmute(); // undefined
```

### audio.isMuted()

无参数。返回 boolean，表示本地静音状态。

```ts
const muted = audio.isMuted(); // false
```

### audio.dispose()

无参数。返回 `void`，幂等释放声音、订阅和音频上下文。SDK 创建的音频随客户端释放，独立创建的实例由调用方释放。

```ts
audio.dispose(); // undefined
audio.getState(); // 'closed'
```

### createAudioAPI(options?)

创建独立 AudioAPI。参数：可选 `{ AudioContextImpl?: typeof AudioContext; autoUnlock?: boolean; followPlatformVolume?: boolean }`。默认使用浏览器 AudioContext、在真实用户操作时自动尝试解锁，并跟随当前页面 effects 设置。返回 `AudioAPI`。

```ts
const extraAudio = createAudioAPI({ autoUnlock: true, followPlatformVolume: true });
extraAudio.getTheme(); // 'default'
extraAudio.dispose();
```

### getVolumeSettings()

顶层方法，与 `pl.game.getVolumeSettings()` 等价。无参数。返回当前页面的 `VolumeSettings` 副本。

```ts
const settings = getVolumeSettings(); // { music: 0.5, effects: 0.5 }
```

### subscribeVolumeSettings(callback)

顶层方法，与游戏音量订阅等价。参数：`(settings: VolumeSettings) => void`。返回 `Unsubscribe`，初值需单独读取。

```ts
const off = subscribeVolumeSettings((settings) => console.log(settings.music));
// A later callback might receive { music: 0.7, effects: 0.5 }
off(); // undefined
```

### bindMediaVolume(media, channel)

将已有媒体的混音量绑定到平台 music/effects 音量。参数：`media: { volume: number }`（通常是 HTMLAudioElement）、`channel: 'music' | 'effects'`。返回 `Unsubscribe`，用于恢复原有媒体音量行为。播放音量为基础混音量乘以所选通道；绑定期间写入 `media.volume` 会更新基础混音量。

```ts
const music = new Audio('./assets/music.ogg');
music.volume = 0.8;
const off = bindMediaVolume(music, 'music');
// At platform music 0.5, effective playback volume is 0.4.
pl.onDispose(() => { off(); music.pause(); });
```

使用自己的 WebAudio 音频图时，读取并订阅音量设置，以固定基础音量更新 GainNode，避免反复乘以上一次的值。

## 自定义手机页面

在 manifest 声明 `customControllers: { steering: 'controllers/steering.html' }`，调用 `pl.app.setController('steering', 'p1')` 激活，不传 layout。key 由 1..64 个字母、数字、下划线或短横线组成，与内置 preset/组件名称（包括 `custom`）不同。将控制器 HTML 作为构建入口，并打包其资源。

```ts
const phone = await PartyLink.init({ mode: 'controller' });
```

这些页面使用专属控制器客户端。`phone.state` 为 `ready` 或 `disposed`。

### phone.app.isEnabled()

无参数。返回 boolean，表示当前是否允许输入。发送前先检查；禁用或页面隐藏时，清空自定义持续输入状态。

```ts
if (phone.app.isEnabled()) await phone.game.sendMessage({ type: 'jump' });
// true allows sending; false means input is blocked
```

### phone.app.requestOrientation(orientation)

参数：`orientation: 'auto' | 'portrait' | 'landscape'`。返回 `void`。请求显示方向，不保证操作系统实际锁定屏幕方向。

```ts
phone.app.requestOrientation('landscape'); // undefined
```

### phone.app.audio

本地 AudioAPI，支持上面列出的全部方法。控制器页面有独立音量状态，本地音频及音量工具不会自动接收平台音量变化。需要跟随平台音量的手机提示音，可先发送业务消息，再由游戏调用 `pl.app.audio.play`。

```ts
phone.app.audio.getState(); // 'idle', for example
```

### phone.game.sendMessage(payload)

参数：可 JSON 序列化的 `payload: unknown`，不包裹 playerId。手机接受发送后返回 `Promise<void>`，不代表游戏业务确认；5 秒超时。禁用时以 `INPUT_BLOCKED` 拒绝。游戏收到 payload 时，也会收到平台确认的发送方 ID。

```ts
await phone.game.sendMessage({ type: 'jump', roundId: 'r1' }); // undefined
// Game 'message' payload: { playerId: 'p1', payload: { type: 'jump', roundId: 'r1' } }
```

### phone.game.on('message', callback)

参数：字面量 `message` 和回调 `(payload: unknown) => void`。返回 `Unsubscribe`，回调直接收到游戏发送的 payload。

```ts
const off = phone.game.on('message', (payload) => console.log(payload));
// Example callback payload: { type: 'round', roundId: 'r1', score: 3 }
off(); // undefined
```

### phone.dispose()

无参数。返回 `void`，幂等释放控制器客户端与音频，尚未完成的发送会拒绝。客户端也会在 pagehide 时销毁。自行清理 DOM 监听器、计时器和动画。

```ts
phone.dispose(); // undefined
console.log(phone.state); // 'disposed'
```

## 游戏生命周期

### pl.state

只读属性，值为 `ready` 或 `disposed`。

```ts
console.log(pl.state); // 'ready'
```

### pl.on('close', callback)

参数：字面量 `close` 和回调 `(payload: { code: string }) => void`。返回 `Unsubscribe`。

```ts
const off = pl.on('close', ({ code }) => console.log(code));
// Example callback payload: { code: 'HOST_CLOSED' }
```

### pl.onDispose(callback)

参数：`callback: () => void`。返回 `Unsubscribe`。销毁时执行，已销毁时立即执行，可用于清理游戏资源。

```ts
const timer = window.setInterval(() => {}, 1000);
const off = pl.onDispose(() => window.clearInterval(timer));
// Callback receives no arguments; off() returns undefined.
```

### pl.dispose()

无参数。返回 `void`，幂等释放 SDK 客户端。游戏自己的 RAF、事件、计时器、订阅和媒体也需清理。

```ts
pl.dispose(); // undefined
console.log(pl.state); // 'disposed'
```

## 构建与 ZIP 格式

Vite 使用 `base: './'` 和 `build: { target: 'es2022' }`，以支持包内相对资源路径和顶层 await。脚本、样式、字体、图片和音频一并放入游戏包，并使用相对路径。游戏包应无需运行时 CDN 或服务端路由即可运行。提供 `npm run package`，构建并生成 `release/game.zip`；开发包的 starter 已提供该流程。

ZIP 根目录直接放置 `manifest.json`、入口 HTML 和引用的封面/资源。压缩输出文件夹里的内容，不要连同外层目录一起压缩。

```json
{
  "schemaVersion": 1,
  "id": "living-room-quiz",
  "name": "Living Room Quiz",
  "version": "1.0.0",
  "description": "A quick quiz for friends and family using phone controls.",
  "players": { "min": 2, "max": 8 },
  "categories": ["party", "trivia"],
  "entry": "index.html",
  "cover": "cover.png",
  "sdkProtocolVersion": 1,
  "launch": { "mode": "iframe" }
}
```

必填字段如上例。`id` 匹配 `[a-z0-9][a-z0-9-]{0,63}`；name 为 1..100 字符；description 为 1..500；version 为三段数字；players min/max 为 1..1000 的整数，min <= max（实际同时连接仍最多 12 位）；categories 为 1..5 个不重复值。可用分类：party、puzzle、action、arcade、strategy、sports、racing、trivia、music、casual、developer-tools。entry 指向包内 HTML，cover 为真实 webp/png/jpg/jpeg/gif 图片，launch mode 为 iframe 或 popup。

可选 `locales` 将 BCP47 标签映射到 `{ name?: string; description?: string }`，默认文案使用英文。查询按字段从精确语言回退到基础语言，再回退到默认值。可选 `customControllers` 按上文将 key 映射到 HTML 路径。manifest 额外字段会被拒绝。公开发布更新时使用新 version。本地开发时，导入相同游戏 ID 的 ZIP 会替换本地副本，即使版本号相同也可以。

资源路径相对 ZIP 根目录，区分大小写，不包含绝对路径、URL、空路径段、`.`/`..`、反斜杠、`%`、`?`、`#`、`:` 或控制字符。ZIP 上限：压缩后 50 MiB、解压后 200 MiB、单文件 50 MiB、2000 个条目、每条路径 240 字符、压缩比最多 100:1。使用未加密的普通 ZIP，包含路径各异的常规文件，CRC 正确。

## 消息大小与失败处理

普通业务消息的完整封包（含协议字段）上限为 4096 UTF-8 字节，payload 应留出足够余量。使用 JSON 兼容数据；函数、DOM、循环对象和 BigInt 无法发送。控制器配置与选择器提交上限为 65536 字节，画板使用自己的限额。绘图图片使用画板能力传递，避免在业务消息中传大图。

处理调用失败，并按情况显示重试或启动提示。常见代码：`HOST_NOT_FOUND` 或启动环境错误；`HOST_BRIDGE_TIMEOUT`、`APP_BRIDGE_TIMEOUT`；`GAME_DISPOSED`、`CONTROLLER_DISPOSED`；`MESSAGE_TIMEOUT`、`MESSAGE_TOO_LARGE`；`INPUT_BLOCKED`；`CUSTOM_CONTROLLER_NOT_FOUND`、`CONTROLLER_COMPONENT_UNKNOWN`、`CONTROLLER_LAYOUT_CONFLICT`。具体错误码可能取决于失败步骤。初始化失败时避免无限循环重试。