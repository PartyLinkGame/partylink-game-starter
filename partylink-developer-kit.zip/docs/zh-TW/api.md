# 平台公開API與能力

SDK 版本：`@partylink/game-sdk@0.1.2`，協定版本：`1`。本頁提供完整的開發規格，AI 可據此實作並打包遊戲。

## 安裝與初始化

```sh
npm install --save-exact @partylink/game-sdk@0.1.2
```

```ts
import {
  PartyLink, createAudioAPI, getVolumeSettings, subscribeVolumeSettings,
  bindMediaVolume, renderDrawPath, AUDIO_THEMES, SFX_KINDS,
} from '@partylink/game-sdk';
import type { PlatformClient, Player, DrawPath } from '@partylink/game-sdk';
```

`PartyLink` 和上述工具函式是執行階段匯出，`PlatformClient` 等介面是型別。透過 `PartyLink.init` 取得用戶端。

### PartyLink.init(options)

連線從 PartyLink Library 啟動的遊戲，或由 PartyLink 開啟的自訂手機控制器。

參數：遊戲使用 `{ mode: 'iframe' | 'popup'; timeoutMs?: number; allowedHostOrigins?: readonly string[]; allowInsecureDevelopment?: boolean }`。mode 與啟動環境一致。`timeoutMs` 預設 10000 毫秒；`allowedHostOrigins` 可限定接受的精確 origin；`allowInsecureDevelopment` 是可選開發設定，仍需有效啟動環境。手機頁面只使用 `{ mode: 'controller' }`。

回傳：遊戲為 `Promise<PlatformClient>`，手機為 `Promise<CustomControllerClient>`。缺少啟動環境、環境無效或逾時時拒絕。直接開啟遊戲頁面時，應提示從 Library 啟動。

```ts
const mode = new URLSearchParams(location.search).get('plMode');
if (mode !== 'iframe' && mode !== 'popup') {
  document.body.textContent = 'Launch this game from PartyLink Library.';
  throw new Error('Launch context required');
}
const pl = await PartyLink.init({ mode });
console.log(pl.state); // 'ready'
// In a custom controller page instead:
// const phone = await PartyLink.init({ mode: 'controller' });
```

遊戲初始化時，若沒有已連線玩家、允許加入且連線介面可用，會自動開啟一次加入介面。此後每次斷線不會自動重新開啟。

## 共用資料與行為

所有 `on` 和訂閱方法回傳 `Unsubscribe`，即 `() => void`；呼叫後停止回呼。訂閱只接收後續變化，有快照方法時先讀取初值。非同步呼叫需處理失敗。`Promise<void>` 表示請求的操作已完成、不回傳值，不代表另一台裝置的遊戲邏輯已處理應用訊息。釋放後的用戶端呼叫可能失敗。

`playerId` 一律指 `Player.id`；暱稱和陣列位置不能穩定識別玩家。目前連線階段最多支援 12 位玩家，快照可能包含已斷線玩家。

```ts
const player: Player = {
  id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '',
  gender: 'none', state: 'connected', joinedAt: 1730000000000,
  controllerType: 'dpad-abxy', isPrimary: true, controlMode: 'game',
};
```

Player 必填欄位：`id`、`sessionId`、`nickname`（1..64 字元）、`avatar`（空字串、JPEG data URL 或暫存 blob URL）、`gender`（`none`、`male`、`female`）、`state`（`connecting`、`connected`、`disconnected`）、`joinedAt`（number）。可選 `controllerType` 為內建 preset ID 或 `custom`；`isPrimary` 為 boolean；`controlMode` 為 `game`、`remote` 或 `waiting`。暫存大頭貼 blob URL 僅適合目前連線階段。

`ConnectionOverlayState` 包含必填布林值 `available`、`visible`、`canJoin` 和可選字串 `qrPayload`、`overlayUrl`。加入資料對應目前連線階段。

## 玩家與加入：pl.host

### pl.host.getPlayers()

無參數。回傳 `Player[]`，為本機快照副本。

```ts
const players = pl.host.getPlayers();
// [{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '',
//    gender: 'none', state: 'connected', joinedAt: 1730000000000 }]
```

### pl.host.getPlayer(id)

參數：`id: string`。回傳 `Player` 副本，不存在時為 `undefined`。

```ts
const player = pl.host.getPlayer('p1'); // Player or undefined
```

### pl.host.removePlayer(id?)

斷開連線並移除玩家。參數：可選 `id: string`，省略時移除全部玩家。回傳 `Promise<void>`。

```ts
await pl.host.removePlayer('p1'); // undefined
```

### pl.host.getLobbyState()

無參數。回傳 `Promise<{ enabled: boolean; primaryPlayerId?: string }>`。

```ts
const lobby = await pl.host.getLobbyState();
// { enabled: true, primaryPlayerId: 'p1' }
```

### pl.host.setPrimaryPlayer(id)

指定負責大廳導航的主控玩家。參數：`id: string`。回傳 `Promise<void>`。

```ts
await pl.host.setPrimaryPlayer('p1'); // undefined
```

### pl.host.setLobbyMode(enabled)

在大廳遙控導航（`true`）與遊戲輸入（`false`）之間切換，不會開始或暫停遊戲邏輯。參數：`enabled: boolean`。回傳 `Promise<void>`。

```ts
await pl.host.setLobbyMode(false); // undefined
```

### pl.host.getConnectionOverlay()

無參數。回傳 `Promise<ConnectionOverlayState>`。

```ts
const overlay = await pl.host.getConnectionOverlay();
// { available: true, visible: false, canJoin: true, qrPayload: 'session-join-data' }
```

### pl.host.setConnectionOverlay(visible)

顯示或隱藏平台加入介面。參數：`visible: boolean`。回傳 `Promise<void>`。顯示介面不會暫停正在進行的遊戲。

```ts
await pl.host.setConnectionOverlay(true); // undefined
```

### pl.host.on(event, callback)

參數：以下事件之一，以及接收其 payload 的回呼。回傳 `Unsubscribe`。

```ts
const off = pl.host.on('player:join', async (player) => {
  await pl.app.setController('dpad-abxy', player.id);
});
off(); // undefined; stop this listener
```

玩家事件直接傳入 Player 物件，不會再包一層 `player` 屬性：

```ts
// 'player:join'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'connected', joinedAt: 1730000000000 }
// 'player:update'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'connected', joinedAt: 1730000000000, isPrimary: true }
// 'player:leave'
{ id: 'p1', sessionId: 's1', nickname: 'Alex', avatar: '', gender: 'none',
  state: 'disconnected', joinedAt: 1730000000000 }
// 'connection:overlay'
{ available: true, visible: true, canJoin: true, qrPayload: 'session-join-data' }
```

先用 `getPlayers()` 設定已有玩家，再根據目前回合規則，在加入或更新事件中設定新玩家和重連玩家。玩家斷線時清除其持續輸入狀態。

## 遊戲設定：pl.game

### pl.game.getLocale()

無參數。回傳目前語言字串，遊戲可據此切換自己的文案。

```ts
const locale = pl.game.getLocale(); // 'en-US'
```

### pl.game.getVolumeSettings()

無參數。回傳 `VolumeSettings`：`{ music: number; effects: number }`，兩個值均為 0..1。

```ts
const settings = pl.game.getVolumeSettings(); // { music: 0.5, effects: 0.5 }
```

### pl.game.subscribeVolumeSettings(callback)

參數：回呼 `(settings: VolumeSettings) => void`。回傳 `Unsubscribe`，訂閱時不會立即傳送初值。

```ts
const initial = pl.game.getVolumeSettings();
const off = pl.game.subscribeVolumeSettings((settings) => {
  console.log(settings.effects); // 0.7 after a matching change
});
```

### pl.game.requestClose()

請求 PartyLink 關閉目前遊戲。無參數。回傳 `Promise<void>`。

```ts
await pl.game.requestClose(); // undefined
```

### pl.game.on(event, callback)

參數：`event: 'locale:change' | 'game:control'`，以及對應 payload 的回呼。回傳 `Unsubscribe`。

```ts
const off = pl.game.on('locale:change', ({ locale }) => {
  document.documentElement.lang = locale;
});
// 'locale:change' payload: { locale: 'en-US' }
// 'game:control' payload: { playerId: 'p1', action: 'pause' }
// Resume payload: { playerId: 'p1', action: 'resume' }
```

`game:control` 發出暫停或繼續請求。遊戲須相應處理模擬、計時和音訊，並在暫停時清除持續輸入。

### pl.game.audio

在電腦遊戲頁面播放的 `AudioAPI` 實例，下文列出全部方法。其音量跟隨平台 effects 通道，隨 SDK 用戶端一起釋放。

```ts
const played = pl.game.audio.confirm(); // true if a sound was created
```

## 手機控制與反饋：pl.app

### pl.app.setController(name, playerId?, layout?)

設定手機控制器。參數：`name: string`（preset、元件組合或 manifest 自訂控制器 key），可選 `playerId: string` 和 `layout: ControllerLayoutInput`。回傳 `Promise<void>`。省略 playerId 僅設定目前玩家，後來加入的玩家需另行設定。為所有玩家傳版面配置時，第二個參數傳 `undefined`。

```ts
await pl.app.setController('joystick-action', 'p1'); // undefined
await pl.app.setController('custom-buttons', undefined, {
  orientation: 'landscape',
  components: [{ type: 'custom-buttons', buttons: [
    { controlId: 'jump', label: 'Jump', gridX: 0, gridY: 0, spanX: 2 },
  ] }],
}); // undefined
```

### pl.app.setControllersEnabled(enabled, playerId?)

啟用或阻止遊戲輸入，保留目前版面配置。參數：`enabled: boolean`，可選 `playerId: string`。回傳 `Promise<void>`。省略 ID 設定持續生效的全局開關，影響後來加入和重連玩家，並重設玩家獨立開關。指定玩家時，玩家與全局開關須同時允許才可輸入。禁用的自訂控制器不能傳送應用訊息。禁用輸入時應清除本機持續操作狀態。

```ts
await pl.app.setControllersEnabled(false); // undefined; pause all input
await pl.app.setControllersEnabled(true); // undefined; allow all input again
await pl.app.setControllersEnabled(false, 'p1'); // undefined; block this player
```

### pl.app.showToast(options, playerId?)

在手機顯示純文本提示，新提示會替換目前提示。參數：`{ text: string; type?: 'text' | 'success' | 'error'; position?: 'top' | 'center' | 'bottom'; duration?: number }`，可選玩家 ID。回傳 `Promise<void>`。省略 ID 發給目前玩家。去除前後空白後 text 為 1..200 UTF-16 字元；duration 為 1000..10000 毫秒的整數。預設 type 為 `text`、position 為 `center`、duration 為 3000。富文本和對話框可在遊戲頁面實作。

```ts
await pl.app.showToast({ text: 'Your turn!', type: 'success', duration: 2000 }, 'p1');
// undefined
```

### pl.app.sendMessage(payload, playerId?)

向自訂手機頁面傳送應用資料。參數：可 JSON 序列化的 `payload: unknown`，可選玩家 ID。回傳 `Promise<void>`。省略 ID 發給目前玩家。如需確認應用處理完成，可設計回執訊息。

```ts
await pl.app.sendMessage({ type: 'round', roundId: 'r1', score: 3 }, 'p1');
// undefined; phone.game.on('message') receives that payload directly
```

### pl.app.audio.play(kind, playerId?, options?)

播放手機音效。參數：`kind: SfxKind`、可選玩家 ID、第三位置可選 `{ theme?: AudioTheme }`。回傳 `Promise<AudioPlaybackResult[]>`，單個玩家也回傳陣列。省略 ID 面向目前玩家。瀏覽器可能尚未解鎖音訊，需檢查播放結果。

```ts
const results = await pl.app.audio.play('success', 'p1', { theme: 'arcade' });
// [{ playerId: 'p1', played: true, state: 'running' }]
// A failure might be [{ playerId: 'p1', played: false, state: 'suspended',
//   reason: 'AUDIO_USER_GESTURE_REQUIRED' }]
```

結果欄位：`playerId: string`、`played: boolean`、`state: AudioState`、可選 `reason: string`。AudioState 為 `idle`、`running`、`suspended`、`closed`、`error` 或 `unsupported`。

### pl.app.on(event, callback)

參數：`input`、`remote:action`、`message`、`selector:submit`、`draw:path` 或 `draw:frame`，以及對應 payload 的回呼。回傳 `Unsubscribe`。每個 payload 都帶有傳送方的 `playerId`。

```ts
const off = pl.app.on('input', (input) => {
  if (input.type === 'button' && input.action === 'click' && !input.synthetic) {
    console.log(input.playerId, input.controlId); // 'p1', 'a'
  }
});
```

輸入 payload 示例：

```ts
// Button: type 'button', action 'down' | 'up' | 'click'
{ protocolVersion: 1, sessionId: 's1', playerId: 'p1', sequence: 1,
  timestamp: 1730000000000, controlId: 'a', synthetic: false,
  type: 'button', action: 'down' }
// Axis: x and y in -1..1
{ protocolVersion: 1, sessionId: 's1', playerId: 'p1', sequence: 2,
  timestamp: 1730000000001, controlId: 'left_stick', synthetic: false,
  type: 'axis', x: 0.5, y: -0.2 }
```

共用欄位：`protocolVersion: 1`；字串 `sessionId`、`playerId`；非負安全整數 `sequence`；非負整數 `timestamp`；由 1..64 個字母、數字、下划線或短橫線組成的 `controlId`；布林值 `synthetic`。一次點擊可能觸發 down/up/click，一次性計分只選其中一個階段。持續動作使用 down/up 保存狀態。synthetic 事件用於還原輸入狀態，應處理釋放和軸歸零，但不作為玩家新動作計分。

其他事件 payload 示例：

```ts
// 'remote:action': action is up/down/left/right/confirm/cancel/back
{ playerId: 'p1', action: 'confirm' }
// 'message': custom phone data; validate shape, ranges, round, and frequency
{ playerId: 'p1', payload: { type: 'jump', roundId: 'r1' } }
// 'selector:submit'
{ playerId: 'p1', controlId: 'vote', requestId: 'r1', values: ['cat'] }
// 'draw:path'
{ playerId: 'p1', kind: 'path', action: 'move', controlId: 'sketch',
  requestId: 'r1', width: 1024, height: 768, backgroundColor: '#FFFFFF',
  strokeId: 'stroke-1', tool: 'pen', color: '#111111', strokeWidth: 0.01,
  points: [{ x: 0.2, y: 0.3 }, { x: 0.25, y: 0.35 }] }
// 'draw:frame': dataUrl contains a complete reassembled WebP image
{ playerId: 'p1', kind: 'frame', action: 'submit', controlId: 'sketch',
  requestId: 'r1', width: 1024, height: 768, backgroundColor: '#FFFFFF',
  frameId: 'frame-1', dataUrl: 'data:image/webp;base64,UklGR...' }
```

上面縮略的 data URL 僅展示欄位形態，不是可用圖片。提交時核對 requestId 與目前回合，並忽略重複提交。

## 控制器名稱與版面配置欄位

內建 preset：`dpad-abxy`、`joystick-action`、`custom-buttons`、`multi-row-buttons`、`remote`、`selector`、`draw`。元件也可按名稱和順序組合，例如 `joystick+dual-buttons`。可用元件名：`joystick`、`dual-buttons`、`quad-buttons`、`dpad`、`menu-keys`、`custom-buttons`、`multi-row-buttons`、`selector`、`draw`。

`ControllerLayoutInput` 包含可選 `orientation: 'auto' | 'portrait' | 'landscape'` 和必填 `components`（1..4 個）。元件型別和順序須匹配組合名稱。預設方向為 `auto`，單獨 selector 預設 `portrait`。版面配置內 control ID 唯一。draw 單獨使用；remote 使用固定橫向 dpad + menu-keys 版面配置。

- 搖桿：`{ type: 'joystick', controlId?: string, deadZone?: number }`；預設 `left_stick`、0.12，deadZone 為 0..0.9。
- 雙按鈕：`{ type: 'dual-buttons' }`；ID 為 `a`、`b`。
- 四按鈕：`{ type: 'quad-buttons' }`；ID 為 `a`、`b`、`x`、`y`。
- 方向鍵：`{ type: 'dpad' }`；ID 為 `up`、`down`、`left`、`right`。
- 菜單鍵：`{ type: 'menu-keys' }`；ID 為 `menu_back`、`menu_cancel`、`menu_confirm`。
- 自訂按鈕：`{ type: 'custom-buttons', buttons: ButtonDefinition[] }`，1..12 個按鈕。各包含 `controlId`、`label`、整數 `gridX/gridY`（0..3）、可選整數 `spanX/spanY`（1..2，預設 1）、可選 `backgroundColor/textColor`。按鈕在 4×4 格線內排列，位置不重疊、不超出邊界。
- 多行按鈕：`{ type: 'multi-row-buttons', buttons: [{ code, label, backgroundColor?, textColor? }] }`，1..4 個按鈕，`code` 即 control ID。

ID 由 1..64 個字母、數字、下划線或短橫線組成。按鈕 label 為 1..16 字元，顏色為 `#RGB` 或 `#RRGGBB`。自訂按鈕 preset 建議顯式傳入版面配置，以使用有意義的 ID。

### 選擇器設定

```ts
await pl.app.setController('selector', 'p1', {
  components: [{ type: 'selector', controlId: 'vote', requestId: 'r1',
    title: 'Choose an animal', mode: 'single',
    options: [{ id: 'cat', label: 'Cat' }, { id: 'dog', label: 'Dog' }],
  }],
}); // undefined
```

欄位：`type: 'selector'`；可選 `controlId`（預設 `selector`）；可選 `requestId`（1..128 字元，預設隨機 UUID，建議使用回合識別）；可選 `title`（最多 120 字元，預設空）；可選 `mode`（預設 `single`，也可 `multiple`）；必填 `options`（1..100 個，ID 唯一）。選項 ID 格式與 control ID 相同，label 為 1..120 字元。可選 `submittedValues: string[]` 可還原已提交選擇，陣列非空且選項 ID 不重複；single 為 1 項，multiple 最多 100 項。提交透過 `selector:submit` 接收。

### 畫板設定

```ts
await pl.app.setController('draw', 'p1', {
  components: [{ type: 'draw', controlId: 'sketch', requestId: 'r1',
    title: 'Draw a cat', width: 1024, height: 768,
    backgroundColor: '#FFFFFF', output: 'path', fps: 5, showSubmit: true,
  }],
}); // undefined
```

可選欄位及預設值：`controlId: 'draw'`；`requestId` 預設隨機 UUID，1..128 字元；`title` 最多 120 字元；`width: 1024`、`height: 768`，兩者為 64..2048 的整數；`backgroundColor: '#FFFFFF'`（六位十六進位）；`output` 預設 `path`，也可 `frame`；`fps: 5`（1..10）；`showSubmit: true`；`initialImage` 為 WebP base64 data URL，最多 48000 字元，不接受任意圖片 URL。

`DrawPath`：`kind: 'path'`；action 為 `start`、`move`、`end`、`clear` 或 `submit`；畫布欄位 `controlId`、`requestId`、`width`、`height`、`backgroundColor`；`strokeId`（1..128 字元）；`tool: 'pen' | 'eraser'`；六位十六進位 `color`；相對畫布大小的 `strokeWidth`（0.0001..1）；`points: { x: number; y: number }[]`，最多 64 個正規化到 0..1 的座標點。事件額外包含 `playerId`。

`DrawFrame` 包含上述畫布欄位、`playerId`、`kind: 'frame'`、action（`frame`、`submit` 或 `clear`）、字串 `frameId` 和完整 WebP `dataUrl`。影格在觸發事件前已重組。圖片字串最多 524288 字元，最多 32 段、每段 16384 字元，5 秒內完成。使用時選擇適中的影格率。

匯出的 `DrawPacket` 型別表示路徑或影格分段；影格分段使用 `index`、`length`、`data`，而非 `dataUrl`。一般遊戲監聽器接收重組後的 `DrawFrame`。

### renderDrawPath(context, path)

將正規化繪圖操作繪製到自己的 Canvas。參數：`CanvasRenderingContext2D`、`DrawPath`。回傳 `void`。Canvas 尺寸與畫板設定一致，各玩家使用獨立畫布，提交動作由遊戲邏輯處理。

```ts
const canvases = new Map<string, HTMLCanvasElement>();
pl.app.on('draw:path', (path) => {
  let canvas = canvases.get(path.playerId);
  if (!canvas) {
    canvas = document.createElement('canvas');
    canvas.width = path.width; canvas.height = path.height;
    canvases.set(path.playerId, canvas);
    document.body.append(canvas);
  }
  renderDrawPath(canvas.getContext('2d')!, path); // undefined
});
```

## AudioAPI

`pl.game.audio`、`phone.app.audio` 和 `createAudioAPI()` 共享以下方法。主題：`default`、`retro8bit`、`arcade`、`glass`、`cyber`。音效：`click`、`focus`、`back`、`confirm`、`cancel`、`success`、`error`、`unlock`、`coin`、`notify`、`join`、`leave`、`countdown`。`AUDIO_THEMES`、`SFX_KINDS` 匯出對應字串的唯讀陣列。

瀏覽器可能需要頁面上的真實用戶操作才能發聲，手機操作不會解鎖電腦頁面音訊。需要時可提供電腦端聲音按鈕。以下示例使用 `const audio = pl.game.audio`。

### audio.play(kind, options?)

參數：`kind: SfxKind`，可選 `{ theme?: AudioTheme }` 可為本次音效覆蓋目前主題。回傳 boolean，表示是否創建聲音，不保證實際聽到。回傳 false 可能因為靜音、暫停、已釋放、不支援、音效名無效或同時發聲數量已滿。需要時檢查狀態和錯誤。

```ts
const played = audio.play('coin', { theme: 'retro8bit' }); // true or false
```

### audio.click()

使用目前主題播放 `click` 音效。無參數。回傳 boolean，含義與 `play` 一致。

```ts
const played = audio.click(); // true or false
```

### audio.focus()

使用目前主題播放 `focus` 音效。無參數。回傳 boolean，含義與 `play` 一致。

```ts
const played = audio.focus(); // true or false
```

### audio.back()

使用目前主題播放 `back` 音效。無參數。回傳 boolean，含義與 `play` 一致。

```ts
const played = audio.back(); // true or false
```

### audio.confirm()

使用目前主題播放 `confirm` 音效。無參數。回傳 boolean，含義與 `play` 一致。

```ts
const played = audio.confirm(); // true or false
```

### audio.cancel()

使用目前主題播放 `cancel` 音效。無參數。回傳 boolean，含義與 `play` 一致。

```ts
const played = audio.cancel(); // true or false
```

### audio.success()

使用目前主題播放 `success` 音效。無參數。回傳 boolean，含義與 `play` 一致。

```ts
const played = audio.success(); // true or false
```

### audio.error()

使用目前主題播放 `error` 音效。無參數。回傳 boolean，含義與 `play` 一致。

```ts
const played = audio.error(); // true or false
```

### audio.unlock()

使用目前主題播放 `unlock` 音效。無參數。回傳 boolean，含義與 `play` 一致。

```ts
const played = audio.unlock(); // true or false
```

### audio.coin()

使用目前主題播放 `coin` 音效。無參數。回傳 boolean，含義與 `play` 一致。

```ts
const played = audio.coin(); // true or false
```

### audio.notify()

使用目前主題播放 `notify` 音效。無參數。回傳 boolean，含義與 `play` 一致。

```ts
const played = audio.notify(); // true or false
```

### audio.join()

使用目前主題播放 `join` 音效。無參數。回傳 boolean，含義與 `play` 一致。

```ts
const played = audio.join(); // true or false
```

### audio.leave()

使用目前主題播放 `leave` 音效。無參數。回傳 boolean，含義與 `play` 一致。

```ts
const played = audio.leave(); // true or false
```

### audio.countdown()

使用目前主題播放 `countdown` 音效。無參數。回傳 boolean，含義與 `play` 一致。

```ts
const played = audio.countdown(); // true or false
```

### audio.resume()

初始化或還原音訊。無參數。回傳 `Promise<void>`，需要本機用戶操作或音訊不可用時可能拒絕。`unlock()` 是音效快捷方法，並非還原音訊操作。

```ts
soundButton.addEventListener('click', async () => {
  try { await audio.resume(); audio.confirm(); }
  catch (error) { console.error(error); }
}); // resume resolves to undefined
```

### audio.isSupported()

無參數。回傳 boolean，表示是否支援 AudioContext。

```ts
const supported = audio.isSupported(); // true or false
```

### audio.getState()

無參數。回傳 `AudioState`：idle/running/suspended/closed/error/unsupported。

```ts
const state = audio.getState(); // 'running'
```

### audio.getLastError()

無參數。回傳 `string | undefined`，表示最近記錄的播放或還原錯誤。

```ts
const error = audio.getLastError(); // undefined or 'AUDIO_USER_GESTURE_REQUIRED'
```

### audio.setTheme(theme)

參數：`theme: AudioTheme`。回傳 `void`，設定後續音效的預設主題。

```ts
audio.setTheme('glass'); // undefined
```

### audio.getTheme()

無參數。回傳 `AudioTheme`，初值為 `default`。

```ts
const theme = audio.getTheme(); // 'glass'
```

### audio.setVolume(volume)

參數：本機混音音量 `volume: number`，會限制在 0..1。回傳 `void`。啟用平台音量跟隨後，與平台 effects 通道共同決定音量。

```ts
audio.setVolume(0.8); // undefined
```

### audio.getVolume()

無參數。回傳本機混音音量（初值 1），不是乘入平台通道後的最終音量。

```ts
const volume = audio.getVolume(); // 0.8
```

### audio.mute()

無參數。回傳 `void`，靜音並停止目前聲音。

```ts
audio.mute(); // undefined
```

### audio.unmute()

無參數。回傳 `void`，還原後續音效的本機混音。

```ts
audio.unmute(); // undefined
```

### audio.isMuted()

無參數。回傳 boolean，表示本機靜音狀態。

```ts
const muted = audio.isMuted(); // false
```

### audio.dispose()

無參數。回傳 `void`，冪等釋放聲音、訂閱和音訊上下文。SDK 創建的音訊隨用戶端釋放，獨立創建的實例由呼叫方釋放。

```ts
audio.dispose(); // undefined
audio.getState(); // 'closed'
```

### createAudioAPI(options?)

創建獨立 AudioAPI。參數：可選 `{ AudioContextImpl?: typeof AudioContext; autoUnlock?: boolean; followPlatformVolume?: boolean }`。預設使用瀏覽器 AudioContext、在真實用戶操作時自動嘗試解鎖，並跟隨目前頁面 effects 設定。回傳 `AudioAPI`。

```ts
const extraAudio = createAudioAPI({ autoUnlock: true, followPlatformVolume: true });
extraAudio.getTheme(); // 'default'
extraAudio.dispose();
```

### getVolumeSettings()

頂層方法，與 `pl.game.getVolumeSettings()` 等價。無參數。回傳目前頁面的 `VolumeSettings` 副本。

```ts
const settings = getVolumeSettings(); // { music: 0.5, effects: 0.5 }
```

### subscribeVolumeSettings(callback)

頂層方法，與遊戲音量訂閱等價。參數：`(settings: VolumeSettings) => void`。回傳 `Unsubscribe`，初值需單獨讀取。

```ts
const off = subscribeVolumeSettings((settings) => console.log(settings.music));
// A later callback might receive { music: 0.7, effects: 0.5 }
off(); // undefined
```

### bindMediaVolume(media, channel)

將已有媒體的混音音量綁定到平台 music/effects 音量。參數：`media: { volume: number }`（通常是 HTMLAudioElement）、`channel: 'music' | 'effects'`。回傳 `Unsubscribe`，用於還原原有媒體音量行為。播放音量為基礎混音音量乘以所選通道；綁定期間寫入 `media.volume` 會更新基礎混音音量。

```ts
const music = new Audio('./assets/music.ogg');
music.volume = 0.8;
const off = bindMediaVolume(music, 'music');
// At platform music 0.5, effective playback volume is 0.4.
pl.onDispose(() => { off(); music.pause(); });
```

使用自己的 WebAudio 音訊圖時，讀取並訂閱音量設定，以固定基礎音量更新 GainNode，避免反復乘以上一次的值。

## 自訂手機頁面

在 manifest 聲明 `customControllers: { steering: 'controllers/steering.html' }`，呼叫 `pl.app.setController('steering', 'p1')` 啟用，不傳 layout。key 由 1..64 個字母、數字、下划線或短橫線組成，與內建 preset/元件名稱（包括 `custom`）不同。將控制器 HTML 作為構建入口，並打包其資源。

```ts
const phone = await PartyLink.init({ mode: 'controller' });
```

這些頁面使用專屬控制器用戶端。`phone.state` 為 `ready` 或 `disposed`。

### phone.app.isEnabled()

無參數。回傳 boolean，表示目前是否允許輸入。傳送前先檢查；禁用或頁面隱藏時，清除自訂持續輸入狀態。

```ts
if (phone.app.isEnabled()) await phone.game.sendMessage({ type: 'jump' });
// true allows sending; false means input is blocked
```

### phone.app.requestOrientation(orientation)

參數：`orientation: 'auto' | 'portrait' | 'landscape'`。回傳 `void`。請求顯示方向，不保證作業系統實際鎖定螢幕方向。

```ts
phone.app.requestOrientation('landscape'); // undefined
```

### phone.app.audio

本機 AudioAPI，支援上面列出的全部方法。控制器頁面有獨立音量狀態，本機音訊及音量工具不會自動接收平台音量變化。需要跟隨平台音量的手機提示音，可先傳送應用訊息，再由遊戲呼叫 `pl.app.audio.play`。

```ts
phone.app.audio.getState(); // 'idle', for example
```

### phone.game.sendMessage(payload)

參數：可 JSON 序列化的 `payload: unknown`，不包覆 playerId。手機接受傳送後回傳 `Promise<void>`，不代表遊戲應用確認；5 秒逾時。禁用時以 `INPUT_BLOCKED` 拒絕。遊戲收到 payload 時，也會收到平台確認的傳送方 ID。

```ts
await phone.game.sendMessage({ type: 'jump', roundId: 'r1' }); // undefined
// Game 'message' payload: { playerId: 'p1', payload: { type: 'jump', roundId: 'r1' } }
```

### phone.game.on('message', callback)

參數：字面量 `message` 和回呼 `(payload: unknown) => void`。回傳 `Unsubscribe`，回呼直接收到遊戲傳送的 payload。

```ts
const off = phone.game.on('message', (payload) => console.log(payload));
// Example callback payload: { type: 'round', roundId: 'r1', score: 3 }
off(); // undefined
```

### phone.dispose()

無參數。回傳 `void`，冪等釋放控制器用戶端與音訊，尚未完成的傳送會拒絕。用戶端也會在 pagehide 時釋放。自行清理 DOM 監聽器、計時器和動畫。

```ts
phone.dispose(); // undefined
console.log(phone.state); // 'disposed'
```

## 遊戲生命週期

### pl.state

唯讀屬性，值為 `ready` 或 `disposed`。

```ts
console.log(pl.state); // 'ready'
```

### pl.on('close', callback)

參數：字面量 `close` 和回呼 `(payload: { code: string }) => void`。回傳 `Unsubscribe`。

```ts
const off = pl.on('close', ({ code }) => console.log(code));
// Example callback payload: { code: 'HOST_CLOSED' }
```

### pl.onDispose(callback)

參數：`callback: () => void`。回傳 `Unsubscribe`。釋放時執行，已釋放時立即執行，可用於清理遊戲資源。

```ts
const timer = window.setInterval(() => {}, 1000);
const off = pl.onDispose(() => window.clearInterval(timer));
// Callback receives no arguments; off() returns undefined.
```

### pl.dispose()

無參數。回傳 `void`，冪等釋放 SDK 用戶端。遊戲自己的 RAF、事件、計時器、訂閱和媒體也需清理。

```ts
pl.dispose(); // undefined
console.log(pl.state); // 'disposed'
```

## 構建與 ZIP 格式

Vite 使用 `base: './'` 和 `build: { target: 'es2022' }`，以支援套件內相對資源路徑和頂層 await。腳本、樣式、字體、圖片和音訊一並放入遊戲套件，並使用相對路徑。遊戲套件應無需執行階段 CDN 或伺服器端路由即可運行。提供 `npm run package`，構建並生成 `release/game.zip`；開發套件的 starter 已提供該流程。

ZIP 根目錄直接放置 `manifest.json`、入口 HTML 和引用的封面/資源。壓縮輸出資料夾里的內容，不要連同外層目錄一起壓縮。

```json
{
  "schemaVersion": 1,
  "id": "living-room-quiz",
  "name": "Living Room Quiz",
  "version": "1.0.0",
  "description": "A quick quiz for friends and family using phone controls.",
  "players": { "min": 2, "max": 8 },
  "categories": ["party", "trivia"],
  "entry": "index.html",
  "cover": "cover.png",
  "sdkProtocolVersion": 1,
  "launch": { "mode": "iframe" }
}
```

必填欄位如上例。`id` 匹配 `[a-z0-9][a-z0-9-]{0,63}`；name 為 1..100 字元；description 為 1..500；version 為三段數字；players min/max 為 1..1000 的整數，min <= max（實際同時連線仍最多 12 位）；categories 為 1..5 個不重複值。可用分類：party、puzzle、action、arcade、strategy、sports、racing、trivia、music、casual、developer-tools。entry 指向套件內 HTML，cover 為真實 webp/png/jpg/jpeg/gif 圖片，launch mode 為 iframe 或 popup。

可選 `locales` 將 BCP47 標籤對應到 `{ name?: string; description?: string }`，預設文案使用英文。查詢按欄位從精確語言回退到基礎語言，再回退到預設值。可選 `customControllers` 按上文將 key 對應到 HTML 路徑。manifest 額外欄位會被拒絕。公開發佈更新時使用新 version。本機開發時，匯入相同遊戲 ID 的 ZIP 會取代本機副本，即使版本號相同也可以。

資源路徑相對 ZIP 根目錄，區分大小寫，不包含絕對路徑、URL、空路徑段、`.`/`..`、反斜槓、`%`、`?`、`#`、`:` 或控制字元。ZIP 上限：壓縮後 50 MiB、解壓縮後 200 MiB、單一檔案 50 MiB、2000 個項目、每條路徑 240 字元、壓縮比最多 100:1。使用未加密的一般 ZIP，包含路徑各異的一般檔案，CRC 正確。

## 訊息大小與失敗處理

一般應用訊息的完整封包（含協定欄位）上限為 4096 UTF-8 位元組，payload 應留出足夠餘量。使用 JSON 相容資料；函式、DOM、迴圈物件和 BigInt 無法傳送。控制器設定與選擇器提交上限為 65536 位元組，畫板使用自己的限額。繪圖圖片使用畫板能力傳遞，避免在應用訊息中傳大圖。

處理呼叫失敗，並按情況顯示重試或啟動提示。常見錯誤碼：`HOST_NOT_FOUND` 或啟動環境錯誤；`HOST_BRIDGE_TIMEOUT`、`APP_BRIDGE_TIMEOUT`；`GAME_DISPOSED`、`CONTROLLER_DISPOSED`；`MESSAGE_TIMEOUT`、`MESSAGE_TOO_LARGE`；`INPUT_BLOCKED`；`CUSTOM_CONTROLLER_NOT_FOUND`、`CONTROLLER_COMPONENT_UNKNOWN`、`CONTROLLER_LAYOUT_CONFLICT`。具體錯誤碼可能取決於失敗步驟。初始化失敗時避免無限迴圈重試。