Build a complete PartyLink game from this idea: [game idea].

Audience and mood: [family, friends, party, or other audience].
Player count: [minimum and maximum players, up to 12 connected phones].
Round length: [preferred length].
Visual direction and language: [preferences].

Before implementing, fetch and read the latest official English API reference: https://doc.partylink.cc/en/api.md

Use that reference as the SDK and package contract. Use the SDK version documented there. If you cannot access the reference, ask the user to provide it rather than guessing the API. Work in the current project and implement the game rather than only proposing a plan. Make reasonable decisions for unspecified details and briefly explain the resulting game.

Design an easy-to-learn multiplayer experience with a shared PC/TV screen and phone controls. Make game rules, joining, turn ownership, scores, results, and replay clear. Keep text readable from across a room and phone interactions comfortable for casual players.

Install @partylink/game-sdk at the documented version and implement using PartyLink.init and the public SDK. Choose appropriate built-in controls or package a custom phone page when the game needs one. Configure both current players and later joiners, handle disconnect/reconnect, prevent stuck input, and implement pause/resume and cleanup. Follow the documented input phases, message limits, audio gestures, and volume behavior.

Create a complete valid manifest, a real cover image, and all required packaged assets. Configure a repeatable build and packaging command. Deliver release/game.zip with manifest.json and entry HTML directly at the ZIP root. Verify the built entry, relative asset paths, manifest, controller pages when used, and ZIP contents. Run relevant available checks; clearly distinguish completed checks from interactions that still need phones in PartyLink.

When finished, report the ZIP path, a short description of the game and phone controls, and concise Library testing instructions. For later revisions, fix the observed issue, rebuild the ZIP, and use a new version for published updates; local ZIP imports may replace the same version.

