Integrate this existing browser game with PartyLink: [game name or project].

Current gameplay: [brief description].
Desired player count: [minimum and maximum players, up to 12 connected phones].
Phone actions: [actions to control on phones].
Shared PC/TV screen behavior: [what everyone sees].
Gameplay and visual elements to preserve: [preferences].

Before implementing, fetch and read the latest official English API reference: https://doc.partylink.cc/en/api.md

Use that reference as the SDK and package contract. Use the SDK version documented there. If you cannot access the reference, ask the user to provide it rather than guessing the API. Inspect the existing project, identify the game loop, input handling, player state, build configuration, and assets, then implement the integration. Preserve the game's intended mechanics while making joining and phone controls easy to understand. Make reasonable decisions where the description is incomplete.

Install @partylink/game-sdk at the documented version. Initialize from the PartyLink launch context, map existing actions to appropriate built-in controllers or a packaged custom phone page, and keep the PC/TV view focused on shared gameplay. Configure current players and later joiners; handle disconnect/reconnect, held input release, round transitions, pause/resume, settings, and cleanup. Follow documented input phases and validate custom business messages against current game state.

Adapt assets and build output to the documented package format. Add a complete valid manifest and real cover image, include all needed assets and custom controller HTML entries, and provide a repeatable packaging command producing release/game.zip. Put manifest.json and entry HTML directly at the ZIP root. Verify the build, relative asset paths, controller output when used, and ZIP contents. Run relevant available checks and identify any phone interactions that still need testing in PartyLink.

Deliver the ZIP path, a concise account of the integration, the phone control mapping, and Library testing instructions. For subsequent fixes, rebuild the ZIP and use a new version for published updates; local ZIP imports may replace the same version.

